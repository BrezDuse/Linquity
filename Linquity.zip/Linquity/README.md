# Linquity - LinkedIn Content Editor

## Overview

Linquity is an AI-powered platform for creating and optimizing LinkedIn content. This repository contains both the web application and Chrome extension for seamless content creation.

## Repository Structure

This repository is organized into two main components:

1. **Web Application**: The main Linquity platform
2. **Chrome Extension**: Browser extension for direct LinkedIn integration

## Chrome Extension

The `/chrome-extension` directory contains all code for the Linquity Chrome Extension, which allows you to:

- Enhance LinkedIn posts directly from the LinkedIn editor
- Format content for maximum engagement
- Analyze post readability
- Customize content based on goals and tone

### Installation

To install the Chrome Extension for development:

1. Navigate to the chrome-extension directory
   ```
   cd chrome-extension
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Build the extension
   ```
   npm run build
   ```

4. Load in Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the `chrome-extension` folder

### Deployment

To create a production build for the Chrome Web Store:

```
npm run deploy
```

This creates a zip file in the `dist` directory that's ready for submission to the Chrome Web Store.

## Web Application

For details on setting up and running the web application, refer to the main application documentation.

## GitHub Actions

This repo uses GitHub Actions for CI/CD. When you push a tag (vX.X.X), it automatically:

1. Builds the Chrome extension
2. Creates a new GitHub release
3. Attaches the extension ZIP file to the release

### Creating a Release

To create a new release:

```bash
git tag v1.0.0
git push origin v1.0.0
```

The GitHub Actions workflow will handle the rest!

## Contributing

1. Fork the repository
2. Create your feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add some amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.