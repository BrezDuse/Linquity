// Content script for Linquity Chrome Extension
console.log('Linquity Content Script loaded on LinkedIn');

// Wait for the page to fully load
window.addEventListener('load', () => {
  initializeExtension();
});

function initializeExtension() {
  // Check if we're on LinkedIn
  if (window.location.hostname.includes('linkedin.com')) {
    // Look for the post editor
    const observer = new MutationObserver((mutations) => {
      const postEditor = document.querySelector('.ql-editor');
      if (postEditor && !document.getElementById('linquity-toolbar')) {
        injectLinquityTools(postEditor);
        observer.disconnect();
      }
    });
    
    observer.observe(document.body, { 
      childList: true,
      subtree: true
    });
  }
}

function injectLinquityTools(postEditor) {
  // Create our custom toolbar
  const toolbar = document.createElement('div');
  toolbar.id = 'linquity-toolbar';
  toolbar.className = 'linquity-toolbar';
  
  toolbar.innerHTML = `
    <div class="linquity-tools">
      <button id="linquity-enhance" class="linquity-button">Enhance Post</button>
      <button id="linquity-format" class="linquity-button">Format</button>
      <button id="linquity-analyze" class="linquity-button">Readability</button>
      <div class="linquity-separator"></div>
      <select id="linquity-goal" class="linquity-select">
        <option value="engage">Engagement</option>
        <option value="inform">Informative</option>
        <option value="professional">Professional</option>
        <option value="thoughtLeadership">Thought Leadership</option>
      </select>
      <select id="linquity-tone" class="linquity-select">
        <option value="professional">Professional</option>
        <option value="conversational">Conversational</option>
        <option value="persuasive">Persuasive</option>
        <option value="inspirational">Inspirational</option>
      </select>
    </div>
  `;
  
  // Insert the toolbar before the post editor
  postEditor.parentNode.insertBefore(toolbar, postEditor);
  
  // Add event listeners
  document.getElementById('linquity-enhance').addEventListener('click', () => {
    enhancePost(postEditor);
  });
  
  document.getElementById('linquity-format').addEventListener('click', () => {
    formatPost(postEditor);
  });
  
  document.getElementById('linquity-analyze').addEventListener('click', () => {
    analyzeReadability(postEditor);
  });
}

function enhancePost(editor) {
  const text = editor.textContent;
  const goal = document.getElementById('linquity-goal').value;
  const tone = document.getElementById('linquity-tone').value;
  
  // Show loading state
  editor.parentNode.classList.add('linquity-loading');
  
  // Send message to background script
  chrome.runtime.sendMessage({
    action: 'enhancePost',
    text,
    goal,
    tone
  }, response => {
    editor.parentNode.classList.remove('linquity-loading');
    
    if (response && response.success && response.data) {
      editor.innerHTML = response.data.enhancedText;
      
      // Show success message
      showNotification('Post enhanced successfully!', 'success');
    } else {
      showNotification('Failed to enhance post. Please try again.', 'error');
    }
  });
}

function formatPost(editor) {
  // Implement formatting logic here
  showNotification('Post formatted!', 'success');
}

function analyzeReadability(editor) {
  // Implement readability analysis here
  showNotification('Analyzing readability...', 'info');
}

function showNotification(message, type) {
  const notification = document.createElement('div');
  notification.className = `linquity-notification linquity-${type}`;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Auto-remove after 3 seconds
  setTimeout(() => {
    notification.classList.add('linquity-fade-out');
    setTimeout(() => {
      notification.remove();
    }, 500);
  }, 3000);
}