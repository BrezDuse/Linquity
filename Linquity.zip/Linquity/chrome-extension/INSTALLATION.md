# Linquity Chrome Extension Installation Guide

This guide provides step-by-step instructions for installing and using the Linquity Chrome Extension for LinkedIn content optimization.

## Installation Methods

### Method 1: Developer Mode (Quick Install)

1. **Download the extension**:
   - Download the latest release from the [Releases page](https://github.com/BrezDuse/Linquity/releases)
   - Unzip the file to a location on your computer

2. **Install in Chrome**:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" using the toggle in the top-right corner
   - Click "Load unpacked"
   - Select the folder containing the unzipped extension files
   - The Linquity extension icon should appear in your browser toolbar

### Method 2: Chrome Web Store (Coming Soon)

The Linquity Chrome Extension will be available in the Chrome Web Store soon. Once published, you'll be able to install it with a single click.

## Using the Extension

1. **Navigate to LinkedIn**:
   - Go to [linkedin.com](https://www.linkedin.com) and log in to your account

2. **Create a post**:
   - Click on "Start a post" to begin creating content
   - The Linquity toolbar will automatically appear above the post editor

3. **Using Linquity tools**:
   - **Enhance Post**: Improve your content with AI assistance
   - **Format**: Apply professional formatting to your text
   - **Readability**: Analyze your content's clarity and engagement potential
   - **Goal & Tone**: Select your post objectives and preferred tone

## Configuration

1. **Access Options**:
   - Right-click the Linquity icon in your browser toolbar
   - Select "Options" from the menu

2. **Customize Settings**:
   - Enable/disable various features
   - Set default goals and tone preferences
   - Connect your Linquity account (optional)

## Troubleshooting

If the extension doesn't appear on LinkedIn:
1. Ensure you're on [linkedin.com](https://www.linkedin.com)
2. Refresh the page
3. Check if the extension is enabled in `chrome://extensions/`
4. Try restarting your browser

## Updating

When using Developer mode, to update to a new version:
1. Download the latest release
2. Go to `chrome://extensions/`
3. Remove the existing Linquity extension
4. Follow the installation steps again with the new version

## Support

If you encounter any issues:
1. Check our [FAQ](https://github.com/BrezDuse/Linquity/wiki/FAQ)
2. Submit an issue on our [GitHub page](https://github.com/BrezDuse/Linquity/issues)
3. Contact us at support@linquity.app