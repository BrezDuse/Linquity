// Save options to chrome.storage
function saveOptions() {
  const enableAI = document.getElementById('enable-ai').checked;
  const enableFormatting = document.getElementById('enable-formatting').checked;
  const enableAnalytics = document.getElementById('enable-analytics').checked;
  const autoSuggest = document.getElementById('auto-suggest').checked;
  const defaultGoal = document.getElementById('default-goal').value;
  const defaultTone = document.getElementById('default-tone').value;
  const apiKey = document.getElementById('api-key').value;
  
  chrome.storage.sync.set(
    {
      enableAIAssistant: enableAI,
      enableFormatting: enableFormatting,
      enableAnalytics: enableAnalytics,
      userPreferences: {
        defaultGoal: defaultGoal,
        defaultTone: defaultTone,
        autoSuggest: autoSuggest
      },
      apiKey: apiKey
    },
    () => {
      // Update status to let user know options were saved
      const status = document.getElementById('status-message');
      status.textContent = 'Options saved!';
      status.className = 'status success';
      
      setTimeout(() => {
        status.textContent = '';
        status.className = 'status';
      }, 2000);
    }
  );
}

// Restore options from chrome.storage
function restoreOptions() {
  chrome.storage.sync.get(
    {
      enableAIAssistant: true,
      enableFormatting: true,
      enableAnalytics: true,
      userPreferences: {
        defaultGoal: 'engage',
        defaultTone: 'professional',
        autoSuggest: true
      },
      apiKey: ''
    },
    (items) => {
      document.getElementById('enable-ai').checked = items.enableAIAssistant;
      document.getElementById('enable-formatting').checked = items.enableFormatting;
      document.getElementById('enable-analytics').checked = items.enableAnalytics;
      document.getElementById('auto-suggest').checked = items.userPreferences.autoSuggest;
      document.getElementById('default-goal').value = items.userPreferences.defaultGoal;
      document.getElementById('default-tone').value = items.userPreferences.defaultTone;
      document.getElementById('api-key').value = items.apiKey;
    }
  );
}

// Restore default options
function restoreDefaults() {
  document.getElementById('enable-ai').checked = true;
  document.getElementById('enable-formatting').checked = true;
  document.getElementById('enable-analytics').checked = true;
  document.getElementById('auto-suggest').checked = true;
  document.getElementById('default-goal').value = 'engage';
  document.getElementById('default-tone').value = 'professional';
  document.getElementById('api-key').value = '';
  
  // Show status message
  const status = document.getElementById('status-message');
  status.textContent = 'Default options restored. Click Save to apply changes.';
  status.className = 'status info';
}

// Validate API key
function validateApiKey() {
  const apiKey = document.getElementById('api-key').value.trim();
  const status = document.getElementById('status-message');
  
  if (apiKey === '') {
    status.textContent = 'Please enter an API key to validate.';
    status.className = 'status error';
    return;
  }
  
  status.textContent = 'Validating API key...';
  status.className = 'status info';
  
  // In a real extension, this would make an API call to validate the key
  // For demo purposes, we'll simulate validation with a timeout
  setTimeout(() => {
    // Mock validation result (in production, this would be a real API call)
    const isValid = apiKey.length > 10; // Simple mock validation
    
    if (isValid) {
      status.textContent = 'API key is valid!';
      status.className = 'status success';
    } else {
      status.textContent = 'Invalid API key. Please check and try again.';
      status.className = 'status error';
    }
  }, 1000);
}

// Event listeners
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save-options').addEventListener('click', saveOptions);
document.getElementById('restore-defaults').addEventListener('click', restoreDefaults);
document.getElementById('validate-key').addEventListener('click', validateApiKey);