# Linquity Chrome Extension Screenshots

This directory contains screenshots showing the Linquity Chrome Extension in action.

## Screenshot Guide

- **extension-in-action.png**: Shows the Linquity toolbar integrated with LinkedIn's post editor
- **readability-analysis.png**: Displays the readability analysis panel with suggestions
- **options-page.png**: The extension's options page for customization
- **enhancement-demo.png**: Before/after comparison of content enhancement

## Adding Screenshots

When you install the extension and begin using it, consider capturing screenshots of your experience to add to this directory. These screenshots help with:

1. Documentation
2. Marketing materials
3. User guides
4. Bug reports

## Guidelines for Screenshots

When taking screenshots for the project:

1. Ensure no personal or sensitive information is visible
2. Capture the full context (show where the extension appears in LinkedIn)
3. Use a clean, professional LinkedIn account
4. Consider highlighting key features with annotations
5. Use a resolution of at least 1280x800 for clarity

## Using These Screenshots

These screenshots can be used in:

- GitHub repository documentation
- Chrome Web Store listing
- Website and marketing materials
- User guides and tutorials

All screenshots are provided under the same license as the project itself.