// Content script (advanced version) for Linquity Chrome Extension
console.log('Linquity Advanced Content Script loaded on LinkedIn');

// Configuration
const API_ENDPOINT = 'https://api.linquity.com';
const DEFAULT_SETTINGS = {
  enableAIAssistant: true,
  enableFormatting: true,
  enableAnalytics: true,
  linkedInProfile: null,
  userPreferences: {
    defaultGoal: 'engage',
    defaultTone: 'professional',
    autoSuggest: true
  }
};

// Initialize the extension when the page is fully loaded
window.addEventListener('load', () => {
  initializeExtension();
});

// Main initialization function
function initializeExtension() {
  // Check if we're on LinkedIn
  if (window.location.hostname.includes('linkedin.com')) {
    // Load user settings
    chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
      // Set up the observer to detect when the post editor appears
      const observer = new MutationObserver((mutations) => {
        // Look for the LinkedIn post editor
        const postEditor = document.querySelector('.ql-editor');
        if (postEditor && !document.getElementById('linquity-toolbar')) {
          // LinkedIn post editor found - inject our tools
          injectLinquityTools(postEditor, settings);
          
          // Stop observing once we've injected our tools
          observer.disconnect();
          
          // Set up analytics if enabled
          if (settings.enableAnalytics) {
            setupAnalytics();
          }
        }
        
        // Also check for profile sections that could be enhanced
        const profileSection = document.querySelector('.pv-about-section');
        if (profileSection && !profileSection.classList.contains('linquity-enhanced')) {
          injectProfileTools(profileSection, settings);
        }
      });
      
      // Start observing the page for the editor to appear
      observer.observe(document.body, { 
        childList: true,
        subtree: true
      });
    });
  }
}

// Inject tools into the LinkedIn post editor
function injectLinquityTools(postEditor, settings) {
  // Create our custom toolbar
  const toolbar = document.createElement('div');
  toolbar.id = 'linquity-toolbar';
  toolbar.className = 'linquity-toolbar';
  
  // Build the toolbar HTML
  toolbar.innerHTML = `
    <div class="linquity-tools">
      <button id="linquity-enhance" class="linquity-button">Enhance Post</button>
      <button id="linquity-format" class="linquity-button">Format</button>
      <button id="linquity-analyze" class="linquity-button">Readability</button>
      <div class="linquity-separator"></div>
      <select id="linquity-goal" class="linquity-select">
        <option value="engage" ${settings.userPreferences.defaultGoal === 'engage' ? 'selected' : ''}>Engagement</option>
        <option value="inform" ${settings.userPreferences.defaultGoal === 'inform' ? 'selected' : ''}>Informative</option>
        <option value="professional" ${settings.userPreferences.defaultGoal === 'professional' ? 'selected' : ''}>Professional</option>
        <option value="thoughtLeadership" ${settings.userPreferences.defaultGoal === 'thoughtLeadership' ? 'selected' : ''}>Thought Leadership</option>
      </select>
      <select id="linquity-tone" class="linquity-select">
        <option value="professional" ${settings.userPreferences.defaultTone === 'professional' ? 'selected' : ''}>Professional</option>
        <option value="conversational" ${settings.userPreferences.defaultTone === 'conversational' ? 'selected' : ''}>Conversational</option>
        <option value="persuasive" ${settings.userPreferences.defaultTone === 'persuasive' ? 'selected' : ''}>Persuasive</option>
        <option value="inspirational" ${settings.userPreferences.defaultTone === 'inspirational' ? 'selected' : ''}>Inspirational</option>
      </select>
    </div>
    
    <div id="linquity-readability-panel" class="linquity-panel" style="display: none;">
      <div class="linquity-panel-header">
        <h3>Readability Analysis</h3>
        <button class="linquity-close-panel">×</button>
      </div>
      <div class="linquity-panel-content">
        <div class="linquity-score-container">
          <div class="linquity-score" id="linquity-readability-score">0</div>
          <div class="linquity-score-label">Readability Score</div>
        </div>
        <div class="linquity-stats">
          <div class="linquity-stat">
            <span class="stat-label">Word Count:</span>
            <span class="stat-value" id="linquity-word-count">0</span>
          </div>
          <div class="linquity-stat">
            <span class="stat-label">Reading Time:</span>
            <span class="stat-value" id="linquity-reading-time">0 min</span>
          </div>
        </div>
        <div id="linquity-suggestions-container" class="linquity-suggestions">
          <h4>Suggestions</h4>
          <ul id="linquity-suggestions-list"></ul>
        </div>
      </div>
    </div>
  `;
  
  // Insert the toolbar before the post editor
  postEditor.parentNode.insertBefore(toolbar, postEditor);
  
  // Add event listeners
  document.getElementById('linquity-enhance').addEventListener('click', () => {
    enhancePost(postEditor, settings);
  });
  
  document.getElementById('linquity-format').addEventListener('click', () => {
    formatPost(postEditor, settings);
  });
  
  document.getElementById('linquity-analyze').addEventListener('click', () => {
    analyzeReadability(postEditor, settings);
  });
  
  // Panel close button
  const closeButtons = document.querySelectorAll('.linquity-close-panel');
  closeButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      const panel = e.target.closest('.linquity-panel');
      if (panel) {
        panel.style.display = 'none';
      }
    });
  });
  
  // Auto-suggest feature
  if (settings.userPreferences.autoSuggest) {
    let typingTimer;
    postEditor.addEventListener('input', () => {
      clearTimeout(typingTimer);
      typingTimer = setTimeout(() => {
        const text = postEditor.textContent;
        if (text && text.length > 100) {
          provideSuggestions(text, postEditor);
        }
      }, 2000);
    });
  }
}

// Enhance post with AI assistance
function enhancePost(editor, settings) {
  const text = editor.textContent;
  const goal = document.getElementById('linquity-goal').value;
  const tone = document.getElementById('linquity-tone').value;
  
  // Show loading state
  editor.parentNode.classList.add('linquity-loading');
  
  // Save preferences
  chrome.storage.sync.set({
    userPreferences: {
      defaultGoal: goal,
      defaultTone: tone,
      autoSuggest: settings.userPreferences.autoSuggest
    }
  });
  
  // Send message to background script
  chrome.runtime.sendMessage({
    action: 'enhancePost',
    text,
    goal,
    tone
  }, response => {
    editor.parentNode.classList.remove('linquity-loading');
    
    if (response && response.success && response.data) {
      editor.innerHTML = response.data.enhancedText;
      
      // Show success message
      showNotification('Post enhanced successfully!', 'success');
      
      // Analyze readability of the enhanced content
      analyzeReadability(editor, settings, true); // silent mode
    } else {
      showNotification('Failed to enhance post. Please try again.', 'error');
    }
  });
}

// Format post for better readability
function formatPost(editor, settings) {
  const text = editor.textContent;
  
  // Basic formatting logic - this could be expanded
  let formattedText = text
    // Add line breaks after punctuation
    .replace(/\.\s+/g, '.\n\n')
    .replace(/\?\s+/g, '?\n\n')
    .replace(/!\s+/g, '!\n\n')
    // Format lists with bullets
    .replace(/(\d+\.\s+[^\n]+)/g, '• $1')
    // Add emphasis to key phrases
    .replace(/(important|key|critical|essential|significant)/gi, '<strong>$1</strong>');
  
  // Update editor content
  editor.innerHTML = formattedText;
  
  // Show notification
  showNotification('Post formatted for better readability!', 'success');
}

// Analyze content readability
function analyzeReadability(editor, settings, silent = false) {
  const text = editor.textContent;
  
  // Skip if text is too short
  if (text.length < 10) {
    if (!silent) {
      showNotification('Please add more content to analyze readability.', 'warning');
    }
    return;
  }
  
  // Basic readability metrics calculation
  const words = text.split(/\s+/).filter(word => word.length > 0);
  const sentences = text.split(/[.!?]+/).filter(sentence => sentence.length > 0);
  const paragraphs = text.split(/\n\s*\n/).filter(p => p.length > 0);
  
  const wordCount = words.length;
  const sentenceCount = sentences.length;
  const avgWordsPerSentence = wordCount / sentenceCount;
  const readingTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));
  
  // Calculate a readability score (simplified)
  let readabilityScore = 100;
  
  // Reduce score for very long sentences
  if (avgWordsPerSentence > 20) {
    readabilityScore -= (avgWordsPerSentence - 20) * 2;
  }
  
  // Reduce score for very short content
  if (wordCount < 50) {
    readabilityScore -= (50 - wordCount) / 2;
  }
  
  // Reduce score for very long words
  const longWords = words.filter(word => word.length > 6).length;
  const longWordPercentage = (longWords / wordCount) * 100;
  if (longWordPercentage > 30) {
    readabilityScore -= (longWordPercentage - 30) * 0.5;
  }
  
  // Cap score between 0-100
  readabilityScore = Math.max(0, Math.min(100, Math.round(readabilityScore)));
  
  // Generate suggestions
  const suggestions = [];
  
  if (avgWordsPerSentence > 20) {
    suggestions.push({
      text: 'Long sentences detected',
      improvement: 'Consider breaking down sentences that are longer than 20 words for better readability.'
    });
  }
  
  if (paragraphs.length === 1 && wordCount > 80) {
    suggestions.push({
      text: 'Wall of text',
      improvement: 'Break your content into smaller paragraphs to make it more scannable.'
    });
  }
  
  if (longWordPercentage > 30) {
    suggestions.push({
      text: 'Complex vocabulary',
      improvement: 'Use simpler words when possible to improve readability.'
    });
  }
  
  if (wordCount < 50) {
    suggestions.push({
      text: 'Short content',
      improvement: 'Consider adding more content to fully develop your ideas.'
    });
  }
  
  // If not in silent mode, show readability panel
  if (!silent) {
    const readabilityPanel = document.getElementById('linquity-readability-panel');
    const scoreElement = document.getElementById('linquity-readability-score');
    const wordCountElement = document.getElementById('linquity-word-count');
    const readingTimeElement = document.getElementById('linquity-reading-time');
    const suggestionsList = document.getElementById('linquity-suggestions-list');
    
    // Update panel with data
    scoreElement.textContent = readabilityScore;
    wordCountElement.textContent = wordCount;
    readingTimeElement.textContent = `${readingTimeMinutes} min`;
    
    // Set score color based on value
    if (readabilityScore >= 80) {
      scoreElement.style.color = '#4caf50'; // Green
    } else if (readabilityScore >= 60) {
      scoreElement.style.color = '#ff9800'; // Orange
    } else {
      scoreElement.style.color = '#f44336'; // Red
    }
    
    // Clear previous suggestions
    suggestionsList.innerHTML = '';
    
    // Add suggestions
    if (suggestions.length > 0) {
      suggestions.forEach(suggestion => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${suggestion.text}:</strong> ${suggestion.improvement}`;
        suggestionsList.appendChild(li);
      });
    } else {
      const li = document.createElement('li');
      li.textContent = 'Great job! No improvements needed.';
      suggestionsList.appendChild(li);
    }
    
    // Show the panel
    readabilityPanel.style.display = 'block';
  }
}

// Inject tools for LinkedIn profile enhancement
function injectProfileTools(profileSection, settings) {
  if (!settings.enableAIAssistant) return;
  
  // Mark section as enhanced
  profileSection.classList.add('linquity-enhanced');
  
  // Create enhance button
  const enhanceButton = document.createElement('button');
  enhanceButton.className = 'linquity-profile-enhance';
  enhanceButton.textContent = 'Enhance with AI';
  
  // Add button to section
  profileSection.appendChild(enhanceButton);
  
  // Add click event
  enhanceButton.addEventListener('click', () => {
    enhanceProfileSection(profileSection);
  });
}

// Enhance LinkedIn profile section
function enhanceProfileSection(section) {
  // Get the profile content
  const textContent = section.textContent.trim();
  
  // Show loading state
  section.classList.add('linquity-loading');
  
  // Send message to background script
  chrome.runtime.sendMessage({
    action: 'enhanceProfile',
    text: textContent
  }, response => {
    section.classList.remove('linquity-loading');
    
    if (response && response.success && response.data) {
      // Implementation would depend on LinkedIn's specific DOM structure
      // This is a simplified example
      const contentElement = section.querySelector('.pv-about__summary-text');
      if (contentElement) {
        contentElement.textContent = response.data.enhancedText;
      }
      
      showNotification('Profile section enhanced!', 'success');
    } else {
      showNotification('Failed to enhance profile. Please try again.', 'error');
    }
  });
}

// Provide real-time suggestions
function provideSuggestions(text, editor) {
  // Only suggest occasionally to avoid being intrusive
  const shouldSuggest = Math.random() > 0.7;
  if (!shouldSuggest) return;
  
  // Simple suggestion logic - this would be more sophisticated in production
  const suggestions = [
    'Adding a question at the end could increase engagement',
    'Consider including a specific call to action',
    'Adding numbers or statistics could strengthen your point',
    'Breaking text into smaller paragraphs improves readability'
  ];
  
  const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
  
  // Show suggestion notification
  showNotification(`Suggestion: ${randomSuggestion}`, 'suggestion', 5000);
}

// Set up analytics tracking
function setupAnalytics() {
  // This would connect to a proper analytics service in production
  console.log('Linquity analytics initialized');
  
  // Track post submission
  document.addEventListener('click', event => {
    const postButton = event.target.closest('button[type="submit"]');
    if (postButton && postButton.textContent.includes('Post')) {
      // Post being submitted - track the event
      logEvent('post_submitted', {
        hasLinquityEnhancements: document.getElementById('linquity-toolbar') !== null
      });
    }
  });
}

// Log analytics event
function logEvent(eventName, eventParams = {}) {
  // In production, this would send data to a proper analytics service
  console.log(`Linquity Analytics Event: ${eventName}`, eventParams);
  
  chrome.runtime.sendMessage({
    action: 'trackEvent',
    eventName,
    eventParams
  });
}

// Show notification
function showNotification(message, type, duration = 3000) {
  const notification = document.createElement('div');
  notification.className = `linquity-notification linquity-${type}`;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Auto-remove after specified duration
  setTimeout(() => {
    notification.classList.add('linquity-fade-out');
    setTimeout(() => {
      notification.remove();
    }, 500);
  }, duration);
}