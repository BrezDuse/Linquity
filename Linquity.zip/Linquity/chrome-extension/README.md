# Linquity Chrome Extension

A Chrome extension that enhances LinkedIn content creation with AI-powered tools.

## Features

- **AI-Powered Content Enhancement**: Optimize your LinkedIn posts with a single click
- **Smart Formatting**: Format your posts for maximum engagement and readability
- **Readability Analysis**: Get instant feedback on how clear and engaging your content is
- **Goal & Tone Selection**: Customize content optimization based on your specific goals and preferred tone
- **Seamless Integration**: Works directly within the LinkedIn post editor

## Installation

### From Chrome Web Store (Coming Soon)

1. Visit the Chrome Web Store (link will be available once published)
2. Click "Add to Chrome"
3. Grant the required permissions

### Manual Installation (Developer Mode)

1. Download the latest release from the Releases page
2. Unzip the file to a location on your computer
3. Open Chrome and go to `chrome://extensions/`
4. Enable "Developer mode" using the toggle in the top-right corner
5. Click "Load unpacked"
6. Select the folder containing the unzipped extension files
7. The extension should now appear in your extensions list and browser toolbar

## How to Use

1. Log in to LinkedIn
2. Start creating a post
3. The Linquity toolbar will appear above the post editor
4. Select your goal and tone from the dropdown menus
5. Write your post content
6. Click "Enhance Post" to improve your content with AI assistance
7. Use "Format" to apply professional formatting
8. Check "Readability" for analysis and suggestions

## Development Setup

If you want to contribute to the development of this extension:

1. Clone this repository
   ```
   git clone https://github.com/yourusername/linquity-chrome-extension.git
   ```

2. Install dependencies
   ```
   cd linquity-chrome-extension
   npm install
   ```

3. Make your changes to the code

4. Load the extension in Chrome using Developer mode as described above

## Building for Production

To create a production build:

```
npm run build:extension
```

This will create a zip file in the `dist` directory that can be submitted to the Chrome Web Store.

## Privacy

Linquity values your privacy. The extension only accesses content when you're actively using LinkedIn's post editor. Your data is processed securely and is never stored permanently without your explicit consent.

## Support

If you encounter any issues or have feature requests, please:

1. Check our [FAQ](https://linquity.com/faq)
2. Submit an issue on GitHub
3. Contact support at support@linquity.com

## License

This project is licensed under the MIT License - see the LICENSE file for details.