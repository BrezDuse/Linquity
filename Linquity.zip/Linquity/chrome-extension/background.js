// Background script for Linquity Chrome Extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('Linquity Chrome Extension installed');
  
  // Initialize default settings
  chrome.storage.sync.set({
    enableAIAssistant: true,
    enableFormatting: true,
    enableAnalytics: true
  });
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'enhancePost') {
    // Example of how we could call our API
    fetch('https://api.linquity.com/enhance-post', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: request.text,
        goal: request.goal,
        tone: request.tone
      })
    })
    .then(response => response.json())
    .then(data => {
      sendResponse({ success: true, data });
    })
    .catch(error => {
      console.error('Error enhancing post:', error);
      sendResponse({ success: false, error: error.message });
    });
    
    return true; // Keeps the message channel open for async response
  }
});