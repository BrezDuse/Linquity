// Popup script for Linquity Chrome Extension
document.addEventListener('DOMContentLoaded', () => {
  // Load saved settings
  chrome.storage.sync.get(
    {
      enableAIAssistant: true,
      enableFormatting: true,
      enableAnalytics: true
    },
    (items) => {
      document.getElementById('enable-ai').checked = items.enableAIAssistant;
      document.getElementById('enable-formatting').checked = items.enableFormatting;
      document.getElementById('enable-analytics').checked = items.enableAnalytics;
    }
  );
  
  // Save settings when changed
  document.getElementById('enable-ai').addEventListener('change', (e) => {
    chrome.storage.sync.set({ enableAIAssistant: e.target.checked });
  });
  
  document.getElementById('enable-formatting').addEventListener('change', (e) => {
    chrome.storage.sync.set({ enableFormatting: e.target.checked });
  });
  
  document.getElementById('enable-analytics').addEventListener('change', (e) => {
    chrome.storage.sync.set({ enableAnalytics: e.target.checked });
  });
  
  // Button actions
  document.getElementById('open-dashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://linquity.com/dashboard' });
  });
  
  document.getElementById('login').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://linquity.com/login' });
  });
});