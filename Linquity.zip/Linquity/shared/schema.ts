import { pgTable, text, serial, integer, timestamp, varchar, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const drafts = pgTable("drafts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Foreign key to link drafts to users
  rawText: text("raw_text").notNull(),
  formattedText: text("formatted_text").notNull(),
  goal: varchar("goal", { length: 50 }),
  tone: varchar("tone", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertDraftSchema = createInsertSchema(drafts).omit({
  id: true,
  createdAt: true
});

export type InsertDraft = z.infer<typeof insertDraftSchema>;
export type Draft = typeof drafts.$inferSelect;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  isVerified: boolean("is_verified").default(false),
  mailchimpId: text("mailchimp_id"),
  password: text("password").notNull(),
  accessToken: text("access_token"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLoginAt: timestamp("last_login_at")
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  isVerified: true,
  mailchimpId: true,
  createdAt: true,
  lastLoginAt: true
}).extend({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters long")
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Mailchimp subscriber schema
export const emailSubscribers = pgTable("email_subscribers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  email: text("email").notNull().unique(),
  status: varchar("status", { length: 20 }).default("pending"),
  subscribeDate: timestamp("subscribe_date").defaultNow().notNull(),
  lastCampaignSent: timestamp("last_campaign_sent")
});

export const insertSubscriberSchema = createInsertSchema(emailSubscribers).omit({
  id: true,
  subscribeDate: true,
  lastCampaignSent: true
});

export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;
export type EmailSubscriber = typeof emailSubscribers.$inferSelect;
