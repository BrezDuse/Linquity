import { 
  users, type User, type InsertUser, 
  drafts, type Draft, type InsertDraft,
  emailSubscribers, type EmailSubscriber, type InsertSubscriber
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Draft related methods
  getAllDrafts(userId?: number): Promise<Draft[]>;
  getDraft(id: number): Promise<Draft | undefined>;
  createDraft(draft: InsertDraft): Promise<Draft>;
  updateDraft(id: number, draft: Partial<InsertDraft>): Promise<Draft | undefined>;
  deleteDraft(id: number): Promise<boolean>;
  
  // Email subscriber related methods
  getSubscriberByEmail(email: string): Promise<EmailSubscriber | undefined>;
  createSubscriber(subscriber: InsertSubscriber): Promise<EmailSubscriber>;
  updateSubscriberStatus(id: number, status: string): Promise<EmailSubscriber | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private draftStore: Map<number, Draft>;
  private subscriberStore: Map<number, EmailSubscriber>;
  userCurrentId: number;
  draftCurrentId: number;
  subscriberCurrentId: number;

  constructor() {
    this.users = new Map();
    this.draftStore = new Map();
    this.subscriberStore = new Map();
    this.userCurrentId = 1;
    this.draftCurrentId = 1;
    this.subscriberCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      isVerified: false,
      mailchimpId: null,
      accessToken: null,
      createdAt: now,
      lastLoginAt: null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...updates
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Draft methods
  async getAllDrafts(userId?: number): Promise<Draft[]> {
    let drafts = Array.from(this.draftStore.values());
    
    // Filter by userId if provided
    if (userId) {
      drafts = drafts.filter(draft => draft.userId === userId);
    }
    
    return drafts.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async getDraft(id: number): Promise<Draft | undefined> {
    return this.draftStore.get(id);
  }
  
  async createDraft(insertDraft: InsertDraft): Promise<Draft> {
    const id = this.draftCurrentId++;
    const now = new Date();
    const draft: Draft = { 
      id,
      userId: insertDraft.userId,
      rawText: insertDraft.rawText,
      formattedText: insertDraft.formattedText,
      goal: insertDraft.goal || null,
      tone: insertDraft.tone || null,
      createdAt: now
    };
    this.draftStore.set(id, draft);
    return draft;
  }
  
  async updateDraft(id: number, update: Partial<InsertDraft>): Promise<Draft | undefined> {
    const draft = this.draftStore.get(id);
    if (!draft) return undefined;
    
    const updatedDraft: Draft = {
      ...draft,
      ...update
    };
    
    this.draftStore.set(id, updatedDraft);
    return updatedDraft;
  }
  
  async deleteDraft(id: number): Promise<boolean> {
    return this.draftStore.delete(id);
  }
  
  // Email subscriber methods
  async getSubscriberByEmail(email: string): Promise<EmailSubscriber | undefined> {
    return Array.from(this.subscriberStore.values()).find(
      (subscriber) => subscriber.email === email
    );
  }
  
  async createSubscriber(insertSubscriber: InsertSubscriber): Promise<EmailSubscriber> {
    const id = this.subscriberCurrentId++;
    const now = new Date();
    const subscriber: EmailSubscriber = {
      id,
      userId: insertSubscriber.userId,
      email: insertSubscriber.email,
      status: insertSubscriber.status || 'pending',
      subscribeDate: now,
      lastCampaignSent: null
    };
    
    this.subscriberStore.set(id, subscriber);
    return subscriber;
  }
  
  async updateSubscriberStatus(id: number, status: string): Promise<EmailSubscriber | undefined> {
    const subscriber = this.subscriberStore.get(id);
    if (!subscriber) return undefined;
    
    const updatedSubscriber: EmailSubscriber = {
      ...subscriber,
      status
    };
    
    this.subscriberStore.set(id, updatedSubscriber);
    return updatedSubscriber;
  }
}

// For a real database implementation, you would use the following:
// export class DatabaseStorage implements IStorage {
//   // ... implement all the methods using the db connection
// }

// Use memory storage for development
export const storage = new MemStorage();
