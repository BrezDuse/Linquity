import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "your-api-key"
});

export interface EnhancePostParams {
  text: string;
  goal?: string;
  tone?: string;
}

export interface EnhancePostResult {
  enhancedText: string;
  readability: {
    score: number;
    rating: string;
    wordCount: number;
    readingTime: number;
    suggestions: Array<{
      text: string;
      improvement: string;
    }>;
  };
  preview: {
    hookStrength: string;
    hookMessage: string;
    formattingTips: string[];
  };
}

export async function enhanceLinkedInPost({ 
  text, 
  goal, 
  tone 
}: EnhancePostParams): Promise<EnhancePostResult> {
  try {
    const goalPart = goal ? `Goal: ${goal}` : '';
    const tonePart = tone ? `Tone: ${tone}` : '';
    
    const prompt = `
You are a professional LinkedIn content editor. Your job is to help users present their ideas clearly, engagingly, and consistently across devices.

Based on the user's draft, provide the following:

1. Enhanced Version (with Formatting)
   - Apply rich formatting: use bold (for important phrases), bullet points, and spacing to improve flow and engagement.
   - Use emojis when appropriate to add personality.

2. Readability Feedback
   - Rate the text's readability from 0-100 (Flesch Reading Ease score).
   - Show estimated reading time and word count.
   - Identify any long or complex sentences and suggest simpler alternatives.

3. Platform-Consistent Preview Advice
   - Mention if the post might be truncated on mobile (e.g. hook isn't strong enough in the first 2-3 lines).
   - Advise on line breaks and visual spacing for LinkedIn's post feed.
   - Suggest improvements to make it visually appealing on desktop vs. mobile.

Raw Text: ${text}
${goalPart}
${tonePart}

Respond with JSON in this format:
{
  "enhancedText": "formatted post with line breaks, emojis, etc.",
  "readability": {
    "score": number,
    "rating": "Good/Moderate/etc.",
    "wordCount": number,
    "readingTime": number,
    "suggestions": [
      {
        "text": "original text",
        "improvement": "improved text"
      }
    ]
  },
  "preview": {
    "hookStrength": "Good/Moderate/Needs Improvement",
    "hookMessage": "feedback about the hook",
    "formattingTips": ["tip 1", "tip 2", "tip 3"]
  }
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert LinkedIn content editor that helps improve posts."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content) as EnhancePostResult;
    return result;
  } catch (error) {
    console.error("Error enhancing post with OpenAI:", error);
    throw new Error("Failed to enhance post content");
  }
}
