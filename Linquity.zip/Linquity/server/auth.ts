import { Request, Response, NextFunction } from 'express';
import { storage } from './storage';
import { hasEmailAccess } from './mailchimp';
import { z } from 'zod';
import { insertUserSchema } from '@shared/schema';
import crypto from 'crypto';

// Authentication utility functions
const generateToken = (): string => {
  return crypto.randomBytes(32).toString('hex');
};

const hashPassword = (password: string): string => {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
};

const verifyPassword = (password: string, hashedPassword: string): boolean => {
  const [salt, hash] = hashedPassword.split(':');
  const computedHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === computedHash;
};

// Login schema
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required")
});

// Register schema
export const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(8, "Confirm password must be at least 8 characters")
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

// Authentication middleware
export const isAuthenticated = async (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: No token provided' });
  }
  
  try {
    // Find user by access token
    const user = Array.from((storage as any).users.values()).find(
      (u: any) => u.accessToken === token
    );
    
    if (!user) {
      return res.status(401).json({ message: 'Unauthorized: Invalid token' });
    }
    
    // Check if email access is verified (only in production with Mailchimp configured)
    if (process.env.NODE_ENV === 'production' && process.env.MAILCHIMP_API_KEY) {
      const hasAccess = await hasEmailAccess(user.email);
      if (!hasAccess) {
        return res.status(403).json({ message: 'Your email requires verification to access this feature' });
      }
    }
    
    // Add user to request
    req.user = user;
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(500).json({ message: 'Internal server error during authentication' });
  }
};

// For routes that should check email verification but not hard block
export const checkEmailVerification = async (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (token) {
    try {
      // Find user by access token
      const user = Array.from((storage as any).users.values()).find(
        (u: any) => u.accessToken === token
      );
      
      if (user) {
        // Add verification status to request
        const isVerified = process.env.NODE_ENV === 'production' && process.env.MAILCHIMP_API_KEY 
          ? await hasEmailAccess(user.email)
          : true;
        
        req.user = user;
        req.isEmailVerified = isVerified;
      }
    } catch (error) {
      console.error('Email verification check error:', error);
    }
  }
  
  next();
};