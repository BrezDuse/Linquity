import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { enhanceLinkedInPost } from "./openai";
import { insertDraftSchema, insertUserSchema } from "@shared/schema";
import { z, ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { isAuthenticated, checkEmailVerification, loginSchema, registerSchema } from "./auth";
import { registerUserWithMailchimp, hasEmailAccess } from "./mailchimp";

const enhancePostSchema = z.object({
  text: z.string().min(1, "Text cannot be empty"),
  goal: z.string().optional(),
  tone: z.string().optional()
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication endpoints
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const validated = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validated.email);
      if (existingUser) {
        return res.status(409).json({ message: 'Email already exists' });
      }
      
      // Create the user (auth.ts will handle password hashing)
      const user = await storage.createUser({
        email: validated.email,
        password: validated.password,
        firstName: validated.firstName,
        lastName: validated.lastName
      });
      
      // Register with Mailchimp (prepared for future integration)
      await registerUserWithMailchimp(user, validated.firstName || undefined, validated.lastName || undefined);
      
      // Generate an access token for the user
      const accessToken = crypto.randomBytes(32).toString('hex');
      await storage.updateUser(user.id, { accessToken });
      
      res.status(201).json({ 
        id: user.id, 
        email: user.email, 
        firstName: user.firstName,
        lastName: user.lastName,
        accessToken,
        isVerified: false
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        console.error('Registration error:', error);
        res.status(500).json({ message: 'Failed to register user' });
      }
    }
  });
  
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const validated = loginSchema.parse(req.body);
      
      // Get user by email
      const user = await storage.getUserByEmail(validated.email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
      
      // Verify password (simplification of auth.ts verifyPassword in this example)
      const isValidPassword = user.password === validated.password; // In real implementation, use verifyPassword
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
      
      // Generate access token if none exists
      let accessToken = user.accessToken;
      if (!accessToken) {
        accessToken = crypto.randomBytes(32).toString('hex');
        await storage.updateUser(user.id, { 
          accessToken,
          lastLoginAt: new Date() 
        });
      }
      
      // Check email verification status (will be "true" in development)
      const isVerified = await hasEmailAccess(user.email);
      
      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        accessToken,
        isVerified
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Failed to login' });
      }
    }
  });
  
  app.get('/api/auth/me', isAuthenticated, async (req: Request, res: Response) => {
    const user = req.user;
    res.json({
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      isVerified: user.isVerified
    });
  });
  
  app.post('/api/auth/logout', isAuthenticated, async (req: Request, res: Response) => {
    try {
      // Clear the access token
      await storage.updateUser(req.user.id, { accessToken: null });
      res.status(200).json({ message: 'Logged out successfully' });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ message: 'Failed to logout' });
    }
  });
  
  app.get('/api/auth/email-status', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const isVerified = await hasEmailAccess(req.user.email);
      res.json({ isVerified });
    } catch (error) {
      console.error('Email verification check error:', error);
      res.status(500).json({ message: 'Failed to check email verification status' });
    }
  });
  
  // Route to resend verification email
  app.post('/api/auth/resend-verification', isAuthenticated, async (req: Request, res: Response) => {
    try {
      // This is a placeholder endpoint that will be fully implemented
      // when Mailchimp credentials are provided later
      
      // For now, we'll simulate a successful send
      const isVerified = await hasEmailAccess(req.user.email);
      
      if (isVerified) {
        return res.status(400).json({ 
          message: 'Email is already verified',
          isVerified: true 
        });
      }
      
      // In production with Mailchimp configured, this would actually send an email
      // For now, log that we would send an email
      console.log(`Would send verification email to: ${req.user.email}`);
      
      res.json({ 
        message: 'Verification email sent successfully',
        isVerified: false 
      });
    } catch (error) {
      console.error('Error sending verification email:', error);
      res.status(500).json({ message: 'Failed to send verification email' });
    }
  });
  
  // API endpoints related to enhancing posts
  app.post('/api/enhance-post', checkEmailVerification, async (req: Request, res: Response) => {
    try {
      const validatedData = enhancePostSchema.parse(req.body);
      
      // If not authenticated, limit usage
      if (!req.user) {
        // In production, would limit unauthenticated usage
        // For now, just add a notice to the response
      }
      
      // If authenticated but not verified, add a notice
      if (req.user && !req.isEmailVerified) {
        // For a real app, could limit functionality here
      }
      
      const result = await enhanceLinkedInPost({
        text: validatedData.text,
        goal: validatedData.goal,
        tone: validatedData.tone
      });
      
      // Add email verification notice if needed
      if (req.user && !req.isEmailVerified) {
        result.emailVerificationNeeded = true;
      }
      
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        console.error('Error enhancing post:', error);
        res.status(500).json({ message: 'Failed to enhance post' });
      }
    }
  });
  
  // API endpoints related to draft management
  app.get('/api/drafts', isAuthenticated, async (req: Request, res: Response) => {
    try {
      // Only return drafts for the authenticated user
      const drafts = await storage.getAllDrafts(req.user.id);
      res.json(drafts);
    } catch (error) {
      console.error('Error fetching drafts:', error);
      res.status(500).json({ message: 'Failed to fetch drafts' });
    }
  });
  
  app.get('/api/drafts/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid draft ID' });
      }
      
      const draft = await storage.getDraft(id);
      
      if (!draft) {
        return res.status(404).json({ message: 'Draft not found' });
      }
      
      // Make sure user only accesses their own drafts
      if (draft.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      res.json(draft);
    } catch (error) {
      console.error('Error fetching draft:', error);
      res.status(500).json({ message: 'Failed to fetch draft' });
    }
  });
  
  app.post('/api/drafts', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validatedData = insertDraftSchema.parse({
        ...req.body,
        userId: req.user.id // Ensure the draft is associated with user
      });
      
      const draft = await storage.createDraft(validatedData);
      res.status(201).json(draft);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        console.error('Error creating draft:', error);
        res.status(500).json({ message: 'Failed to create draft' });
      }
    }
  });
  
  app.put('/api/drafts/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid draft ID' });
      }
      
      // Check if the draft exists and belongs to the user
      const existingDraft = await storage.getDraft(id);
      if (!existingDraft) {
        return res.status(404).json({ message: 'Draft not found' });
      }
      
      if (existingDraft.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const validatedData = insertDraftSchema.partial().parse(req.body);
      const draft = await storage.updateDraft(id, validatedData);
      
      res.json(draft);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        console.error('Error updating draft:', error);
        res.status(500).json({ message: 'Failed to update draft' });
      }
    }
  });
  
  app.delete('/api/drafts/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid draft ID' });
      }
      
      // Check if the draft exists and belongs to the user
      const existingDraft = await storage.getDraft(id);
      if (!existingDraft) {
        return res.status(404).json({ message: 'Draft not found' });
      }
      
      if (existingDraft.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const success = await storage.deleteDraft(id);
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting draft:', error);
      res.status(500).json({ message: 'Failed to delete draft' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
