import mailchimp from '@mailchimp/mailchimp_marketing';
import crypto from 'crypto';
import { storage } from './storage';
import { type InsertSubscriber, type User } from '@shared/schema';

// Mailchimp will be configured with your credentials when you're ready
const initMailchimp = () => {
  // This ensures the service won't break if credentials aren't provided yet
  if (!process.env.MAILCHIMP_API_KEY || !process.env.MAILCHIMP_SERVER_PREFIX) {
    console.warn('Mailchimp credentials not configured - running in development mode');
    return null;
  }

  mailchimp.setConfig({
    apiKey: process.env.MAILCHIMP_API_KEY,
    server: process.env.MAILCHIMP_SERVER_PREFIX
  });

  return mailchimp;
};

// Generate a subscriber hash (MD5) for Mailchimp API
const getSubscriberHash = (email: string): string => {
  return crypto.createHash('md5').update(email.toLowerCase()).digest('hex');
};

// Add a subscriber to Mailchimp
export const addSubscriberToMailchimp = async (user: User, firstName?: string, lastName?: string): Promise<string | null> => {
  try {
    const client = initMailchimp();
    if (!client || !process.env.MAILCHIMP_LIST_ID) {
      // Return a mock id for development
      return `dev-mode-${Date.now()}`;
    }

    const result = await client.lists.addListMember(process.env.MAILCHIMP_LIST_ID, {
      email_address: user.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: firstName || '',
        LNAME: lastName || '',
      }
    });

    return result.id || null;
  } catch (error) {
    console.error('Failed to add subscriber to Mailchimp:', error);
    return null;
  }
};

// Check subscriber status in Mailchimp
export const checkSubscriberStatus = async (email: string): Promise<'subscribed' | 'unsubscribed' | 'pending' | 'not_found'> => {
  try {
    const client = initMailchimp();
    if (!client || !process.env.MAILCHIMP_LIST_ID) {
      // For development, pretend all emails are subscribed
      return 'subscribed';
    }

    const subscriberHash = getSubscriberHash(email);
    
    const response = await client.lists.getListMember(
      process.env.MAILCHIMP_LIST_ID,
      subscriberHash
    );
    
    return response.status;
  } catch (error: any) {
    if (error.status === 404) {
      return 'not_found';
    }
    console.error('Failed to check subscriber status:', error);
    return 'not_found';
  }
};

// Add user to local subscribers database
export const addSubscriberToDatabase = async (
  user: User, 
  status: 'pending' | 'subscribed' = 'pending'
): Promise<boolean> => {
  try {
    const subscriberData: InsertSubscriber = {
      userId: user.id,
      email: user.email,
      status
    };
    
    await storage.createSubscriber(subscriberData);
    return true;
  } catch (error) {
    console.error('Failed to add subscriber to database:', error);
    return false;
  }
};

// Main function to handle new user registration with Mailchimp
export const registerUserWithMailchimp = async (
  user: User,
  firstName?: string,
  lastName?: string
): Promise<boolean> => {
  try {
    // Add to Mailchimp (when credentials are provided)
    const mailchimpId = await addSubscriberToMailchimp(user, firstName, lastName);
    
    // Update user record with Mailchimp ID
    if (mailchimpId) {
      await storage.updateUser(user.id, { mailchimpId });
    }
    
    // Add to local subscribers database
    await addSubscriberToDatabase(user, 'pending');
    
    return true;
  } catch (error) {
    console.error('Failed to register user with Mailchimp:', error);
    return false;
  }
};

// Check if user has verified email access
export const hasEmailAccess = async (email: string): Promise<boolean> => {
  try {
    // First check if credentials are configured
    if (!process.env.MAILCHIMP_API_KEY || !process.env.MAILCHIMP_SERVER_PREFIX) {
      // In development mode, always grant access
      return true;
    }
    
    const status = await checkSubscriberStatus(email);
    return status === 'subscribed';
  } catch (error) {
    console.error('Failed to check email access:', error);
    return false;
  }
};