# Contributing to Linquity

Thank you for your interest in contributing to Linquity! This document provides guidelines and instructions for contributing to this project.

## Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally
3. **Set up the development environment** by following the instructions in the README.md

## Development Process

### Web Application

1. **Create a feature branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**, following our code style and organization
   - Keep components modular and reusable
   - Document your code with clear comments
   - Write tests for new functionality

3. **Run the application locally** to test your changes:
   ```bash
   npm run dev
   ```

### Chrome Extension

If you're working on the Chrome extension:

1. Navigate to the chrome-extension directory:
   ```bash
   cd chrome-extension
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Build the extension for testing:
   ```bash
   npm run build
   ```

4. Test in Chrome by loading the unpacked extension from the chrome-extension directory

## Pull Request Process

1. **Update documentation** to reflect any changes
2. **Ensure all tests pass**
3. **Create a pull request** from your fork to the main repository
4. **Describe your changes** in detail in the pull request description
5. **Link any related issues** by mentioning them in the description

## Code Style Guidelines

- Use consistent indentation (2 spaces)
- Follow React best practices for components
- Use TypeScript for type safety
- Use ESLint and Prettier for code formatting

## Commit Message Guidelines

- Use clear and descriptive commit messages
- Start with a verb in the present tense (e.g., "Add feature" not "Added feature")
- Reference issue numbers when applicable

Example: `Add LinkedIn profile integration (fixes #42)`

## Reporting Bugs

When reporting bugs, please include:

- A clear, descriptive title
- Steps to reproduce the issue
- Expected behavior
- Actual behavior
- Screenshots if applicable
- Your environment details (browser, OS, etc.)

## Feature Requests

When suggesting features:

- Explain the problem the feature would solve
- Describe the desired functionality
- Provide examples of how users would interact with the feature
- Note if you're willing to help implement the feature

## Questions?

If you have any questions about contributing, please open an issue with your question or reach out to the maintainers directly.

Thank you for contributing to Linquity!