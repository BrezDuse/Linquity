import { CreativityScore } from './lib/creativityScoring';

export interface PostContent {
  rawText: string;
  formattedText: string;
  goal: string;
  tone: string;
  imageAttachment?: string; // URL or base64 data for an attached image
  creativityScore?: CreativityScore; // Added creativity score
}

export interface ReadabilityFeedback {
  score: number;
  rating: string;
  wordCount: number;
  readingTime: number;
  suggestions: Array<{
    text: string;
    improvement: string;
  }>;
}

export interface PreviewTips {
  hookStrength: string;
  hookMessage: string;
  formattingTips: string[];
}

export interface Draft {
  id: number;
  rawText: string;
  formattedText: string;
  goal: string;
  tone: string;
  createdAt: string;
}

export interface EnhancePostResponse {
  enhancedText: string;
  readability: ReadabilityFeedback;
  preview: PreviewTips;
}
