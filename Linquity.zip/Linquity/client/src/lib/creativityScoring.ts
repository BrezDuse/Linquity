/**
 * Creativity Scoring System for LinkedIn Posts
 * 
 * This module provides functions to analyze and score content creativity.
 * The creativity score is based on multiple factors including:
 * - Linguistic variety (diverse vocabulary)
 * - Storytelling elements
 * - Unique phrasing and hooks
 * - Engagement techniques
 * - Original metaphors and analogies
 */

/**
 * Creativity score breakdown with individual component scores
 */
export interface CreativityScore {
  total: number; // 0-100 overall score
  vocabulary: number; // 0-20 score for vocabulary diversity
  engagement: number; // 0-20 score for engagement techniques
  originality: number; // 0-20 score for original ideas/phrasing
  storytelling: number; // 0-20 score for narrative elements
  visualLanguage: number; // 0-20 score for descriptive/visual language
  feedback: string[]; // Array of specific feedback points
  level: 'Novice' | 'Apprentice' | 'Professional' | 'Expert' | 'Master'; // Level based on score
  badges: string[]; // Earned badges
}

/**
 * Patterns that indicate engagement techniques
 */
const ENGAGEMENT_PATTERNS = [
  /\?(?:\s|$)/, // Questions
  /imagine/i, // Asking to imagine scenarios
  /what if/i, // Hypotheticals
  /have you ever/i, // Personal appeal
  /did you know/i, // Information hooks
  /fun fact/i, // Fun facts
  /^\d+\s+/, // Numbered lists
  /firstly|secondly|finally/i, // Structured points
  /today I/i, // Personal experiences
  /you won't believe/i, // Curiosity
  /the secret to/i, // Secrets
  /how to/i, // Instructional
];

/**
 * Patterns that indicate storytelling elements
 */
const STORYTELLING_PATTERNS = [
  /recently|yesterday|last week|last month|last year/i, // Time indicators
  /I learned|I discovered|I realized/i, // Personal insights
  /at first|then|finally/i, // Progression
  /challenge|obstacle|problem/i, // Challenges
  /solved|achieved|accomplished/i, // Resolutions
  /changed|transformed|improved/i, // Transformations
  /the lesson|what I learned|takeaway/i, // Lessons
  /started with|began with|ended with/i, // Story structure
];

/**
 * Patterns that indicate visual or descriptive language
 */
const VISUAL_LANGUAGE_PATTERNS = [
  /vibrant|colorful|bright|dim|dark/i, // Visual descriptors
  /loud|quiet|silent|whisper|roar/i, // Sound descriptors
  /smooth|rough|soft|hard|silky/i, // Texture descriptors
  /sweet|bitter|spicy|tangy|fresh/i, // Taste descriptors
  /imagine|picture|visualize|see/i, // Visual prompts
  /feels like|felt like/i, // Feeling descriptors
  /just like|similar to|resembles/i, // Comparisons
  /metaphor|analogy/i, // Explicit literary devices
];

/**
 * Calculate vocabulary diversity score (0-20)
 * Higher scores indicate a more diverse and rich vocabulary
 */
function calculateVocabularyScore(text: string): number {
  // Remove common LinkedIn business jargon
  const cleanText = text.toLowerCase()
    .replace(/synergy|leverage|paradigm|bandwidth|actionable|proactive|stakeholder|deliverable|optimization|disruption/g, '');
    
  const words = cleanText.match(/\b\w{3,}\b/g) || [];
  if (words.length === 0) return 0;
  
  // Count unique words
  const uniqueWords = new Set(words);
  const uniqueRatio = uniqueWords.size / words.length;
  
  // Analyze word length distribution
  const longWords = words.filter(word => word.length > 6).length;
  const longWordRatio = longWords / words.length;
  
  // Calculate vocabulary score (0-20)
  const uniqueScore = Math.min(10, uniqueRatio * 15);
  const complexityScore = Math.min(10, longWordRatio * 20);
  
  return Math.round(uniqueScore + complexityScore);
}

/**
 * Calculate engagement technique score (0-20)
 * Measures the use of patterns that encourage reader engagement
 */
function calculateEngagementScore(text: string): number {
  let engagementCount = 0;
  
  ENGAGEMENT_PATTERNS.forEach(pattern => {
    if (pattern.test(text)) {
      engagementCount++;
    }
  });
  
  // Calculate score (0-20) based on engagement techniques
  return Math.min(20, Math.round(engagementCount * (20 / ENGAGEMENT_PATTERNS.length) * 1.5));
}

/**
 * Calculate originality score (0-20)
 * Measures how unique and original the content appears
 */
function calculateOriginalityScore(text: string): number {
  // Check for cliché LinkedIn phrases
  const clichés = [
    /thrilled to announce/i,
    /excited to share/i,
    /honored to be/i,
    /looking forward to/i,
    /connect with me/i,
    /thoughts\?$/i,
    /agree\?$/i,
    /your thoughts\?/i,
    /what do you think\?/i,
    /comment below/i,
  ];
  
  let clichéCount = 0;
  clichés.forEach(pattern => {
    if (pattern.test(text)) {
      clichéCount++;
    }
  });
  
  // Calculate cliché penalty
  const clichéPenalty = Math.min(15, clichéCount * 3);
  
  // Check for unique phrases or expressions
  const uniquePhrases = text.match(/"[^"]{10,}"/) || [];
  const analogyPoints = (text.match(/like a|similar to|resembles|compared to/gi) || []).length * 2;
  
  // Calculate originality score (0-20)
  const baseScore = 15;
  const score = baseScore - clichéPenalty + uniquePhrases.length * 3 + analogyPoints;
  
  return Math.max(0, Math.min(20, Math.round(score)));
}

/**
 * Calculate storytelling score (0-20)
 * Measures the use of narrative elements and structure
 */
function calculateStorytellingScore(text: string): number {
  let storyPoints = 0;
  
  STORYTELLING_PATTERNS.forEach(pattern => {
    if (pattern.test(text)) {
      storyPoints++;
    }
  });
  
  // Check for a narrative arc
  const hasBeginning = /^(today|yesterday|recently|once|when I|a few|last)/i.test(text);
  const hasMiddle = /(then|next|after that|subsequently|later)/i.test(text);
  const hasEnd = /(finally|in the end|ultimately|as a result|the outcome)/i.test(text);
  
  // Award points for narrative structure
  if (hasBeginning) storyPoints += 2;
  if (hasMiddle) storyPoints += 2;
  if (hasEnd) storyPoints += 2;
  
  // Calculate storytelling score (0-20)
  return Math.min(20, Math.round(storyPoints * (20 / (STORYTELLING_PATTERNS.length + 6)) * 1.8));
}

/**
 * Calculate visual language score (0-20)
 * Measures the use of descriptive and sensory language
 */
function calculateVisualLanguageScore(text: string): number {
  let visualPoints = 0;
  
  VISUAL_LANGUAGE_PATTERNS.forEach(pattern => {
    if (pattern.test(text)) {
      visualPoints++;
    }
  });
  
  // Count descriptive adjectives
  const descriptiveAdjectives = (text.match(/\b(amazing|beautiful|stunning|incredible|breathtaking|fascinating|captivating|inspiring|remarkable|extraordinary)\b/gi) || []).length;
  
  // Calculate visual language score (0-20)
  const patternScore = visualPoints * (15 / VISUAL_LANGUAGE_PATTERNS.length);
  const adjectiveScore = Math.min(5, descriptiveAdjectives);
  
  return Math.min(20, Math.round(patternScore + adjectiveScore));
}

/**
 * Get feedback based on the score components
 */
function generateFeedback(scores: Partial<CreativityScore>): string[] {
  const feedback: string[] = [];
  
  // Vocabulary feedback
  if (scores.vocabulary && scores.vocabulary < 8) {
    feedback.push("Try using more varied and distinctive vocabulary to make your post stand out.");
  } else if (scores.vocabulary && scores.vocabulary >= 15) {
    feedback.push("Excellent vocabulary diversity! Your word choice makes your content memorable.");
  }
  
  // Engagement feedback
  if (scores.engagement && scores.engagement < 8) {
    feedback.push("Add questions or calls to action to boost engagement with your audience.");
  } else if (scores.engagement && scores.engagement >= 15) {
    feedback.push("Great engagement techniques! You're effectively inviting reader interaction.");
  }
  
  // Originality feedback
  if (scores.originality && scores.originality < 8) {
    feedback.push("Your post contains some common LinkedIn phrases. Try a more unique approach.");
  } else if (scores.originality && scores.originality >= 15) {
    feedback.push("Your originality shines through! Your unique perspective will capture attention.");
  }
  
  // Storytelling feedback
  if (scores.storytelling && scores.storytelling < 8) {
    feedback.push("Consider adding narrative elements to create a more compelling story.");
  } else if (scores.storytelling && scores.storytelling >= 15) {
    feedback.push("Excellent storytelling! Your narrative approach will resonate with readers.");
  }
  
  // Visual language feedback
  if (scores.visualLanguage && scores.visualLanguage < 8) {
    feedback.push("Add more descriptive language to help readers visualize your message.");
  } else if (scores.visualLanguage && scores.visualLanguage >= 15) {
    feedback.push("Your descriptive language creates vivid imagery that readers will remember.");
  }
  
  return feedback;
}

/**
 * Determine creativity level based on total score
 */
function determineLevel(totalScore: number): CreativityScore['level'] {
  if (totalScore < 40) return 'Novice';
  if (totalScore < 60) return 'Apprentice';
  if (totalScore < 75) return 'Professional';
  if (totalScore < 90) return 'Expert';
  return 'Master';
}

/**
 * Award badges based on component scores
 */
function awardBadges(scores: Partial<CreativityScore>): string[] {
  const badges: string[] = [];
  
  if (scores.vocabulary && scores.vocabulary >= 18) badges.push("Wordsmith");
  if (scores.engagement && scores.engagement >= 18) badges.push("Engagement Guru");
  if (scores.originality && scores.originality >= 18) badges.push("Original Thinker");
  if (scores.storytelling && scores.storytelling >= 18) badges.push("Master Storyteller");
  if (scores.visualLanguage && scores.visualLanguage >= 18) badges.push("Vivid Visualizer");
  
  // Special combination badges
  if (scores.originality && scores.storytelling && 
      scores.originality >= 15 && scores.storytelling >= 15) {
    badges.push("Narrative Innovator");
  }
  
  if (scores.engagement && scores.vocabulary && 
      scores.engagement >= 15 && scores.vocabulary >= 15) {
    badges.push("Eloquent Engager");
  }
  
  return badges;
}

/**
 * Analyze text and generate a comprehensive creativity score
 */
export function analyzeCreativity(text: string): CreativityScore {
  // Return minimal scoring for empty or very short content
  if (!text || text.length < 50) {
    return {
      total: 0,
      vocabulary: 0,
      engagement: 0,
      originality: 0,
      storytelling: 0,
      visualLanguage: 0,
      feedback: ["Your post is too short to analyze. Add more content to receive creativity insights."],
      level: 'Novice',
      badges: []
    };
  }
  
  // Calculate individual component scores
  const vocabulary = calculateVocabularyScore(text);
  const engagement = calculateEngagementScore(text);
  const originality = calculateOriginalityScore(text);
  const storytelling = calculateStorytellingScore(text);
  const visualLanguage = calculateVisualLanguageScore(text);
  
  // Calculate total score (0-100)
  const componentScores = { vocabulary, engagement, originality, storytelling, visualLanguage };
  const total = Math.min(100, Object.values(componentScores).reduce((sum, score) => sum + score, 0));
  
  // Generate feedback
  const feedback = generateFeedback(componentScores);
  
  // Determine level
  const level = determineLevel(total);
  
  // Award badges
  const badges = awardBadges(componentScores);
  
  return {
    total,
    vocabulary,
    engagement,
    originality,
    storytelling,
    visualLanguage,
    feedback,
    level,
    badges
  };
}