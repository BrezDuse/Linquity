/**
 * LinkedIn SEO Optimization Module
 * 
 * This module analyzes LinkedIn content and provides recommendations
 * to improve discoverability through LinkedIn's algorithm.
 */

export interface LinkedInSeoResult {
  score: number; // 0-100 score
  recommendations: string[];
  keywordSuggestions: string[];
  hashtagRecommendations: string[];
  contentGaps: string[];
  strongAreas: string[];
  keywordsFound: Array<{keyword: string, count: number}>;
  keywordDensity: number;
  idealLength: boolean;
  readabilityLevel: 'basic' | 'intermediate' | 'advanced';
  seoLevel: 'poor' | 'fair' | 'good' | 'excellent';
}

interface IndustryKeywords {
  [industry: string]: string[];
}

// Sample industry-specific keywords for recommendation
const INDUSTRY_KEYWORDS: IndustryKeywords = {
  technology: [
    'artificial intelligence', 'machine learning', 'data science', 'cloud computing',
    'cybersecurity', 'digital transformation', 'blockchain', 'automation',
    'software development', 'programming', 'devops', 'big data',
    'iot', 'internet of things', 'saas', 'api', 'user experience',
    'product management', 'agile', 'scrum', 'tech stack', 'innovation'
  ],
  marketing: [
    'digital marketing', 'content marketing', 'social media', 'seo', 'sem',
    'email marketing', 'brand strategy', 'customer experience', 'cx',
    'market research', 'analytics', 'conversion rate', 'roi', 'kpi',
    'campaign management', 'marketing automation', 'inbound marketing',
    'lead generation', 'customer journey', 'marketing strategy'
  ],
  finance: [
    'financial services', 'investment', 'portfolio management', 'wealth management',
    'financial planning', 'risk management', 'asset allocation', 'retirement planning',
    'tax strategy', 'stock market', 'equity', 'bonds', 'mutual funds', 'etf',
    'cryptocurrency', 'financial analysis', 'capital markets', 'banking', 'fintech'
  ],
  healthcare: [
    'patient care', 'healthcare innovation', 'medical research', 'clinical trials',
    'healthcare technology', 'telehealth', 'medical devices', 'patient experience',
    'health equity', 'healthcare policy', 'public health', 'preventative care',
    'wellness', 'mental health', 'chronic disease', 'healthcare management'
  ],
  hr: [
    'recruitment', 'talent acquisition', 'employee engagement', 'retention',
    'performance management', 'compensation', 'benefits', 'company culture',
    'diversity and inclusion', 'dei', 'remote work', 'hybrid work', 'workplace',
    'hr technology', 'learning and development', 'onboarding', 'employee experience',
    'talent management', 'leadership development', 'organizational development'
  ],
  consulting: [
    'business strategy', 'management consulting', 'organizational change',
    'process improvement', 'business transformation', 'strategic planning',
    'operational excellence', 'business development', 'market analysis',
    'competitive intelligence', 'value proposition', 'business model innovation',
    'benchmarking', 'best practices', 'thought leadership'
  ],
  sales: [
    'sales strategy', 'sales process', 'pipeline management', 'prospecting',
    'lead qualification', 'sales enablement', 'account management', 'customer success',
    'b2b sales', 'b2c sales', 'sales technology', 'crm', 'negotiation',
    'closing techniques', 'value selling', 'solution selling', 'consultative selling',
    'sales leadership', 'revenue growth', 'customer retention'
  ],
  general: [
    'leadership', 'management', 'strategy', 'success', 'growth', 'innovation',
    'communication', 'teamwork', 'collaboration', 'problem solving', 'decision making',
    'career development', 'professional growth', 'networking', 'mentorship',
    'productivity', 'efficiency', 'best practices', 'lessons learned'
  ]
};

// Trending LinkedIn hashtags - would ideally be updated regularly
const TRENDING_HASHTAGS = [
  'leadership', 'innovation', 'productivity', 'futureofwork',
  'entrepreneurship', 'careertips', 'personaldevelopment', 'professionaldevelopment',
  'networking', 'business', 'technology', 'digitaltransformation',
  'remotework', 'ai', 'data', 'sustainability', 'diversity',
  'inclusion', 'hiring', 'management', 'marketing', 'success'
];

/**
 * Analyze text for LinkedIn SEO optimization
 * @param text The LinkedIn post content to analyze
 * @param industry The industry context for specialized recommendations
 * @returns Detailed SEO analysis results
 */
export function analyzeSeo(text: string, industry: string = 'general'): LinkedInSeoResult {
  // Initialize result
  const result: LinkedInSeoResult = {
    score: 0,
    recommendations: [],
    keywordSuggestions: [],
    hashtagRecommendations: [],
    contentGaps: [],
    strongAreas: [],
    keywordsFound: [],
    keywordDensity: 0,
    idealLength: false,
    readabilityLevel: 'intermediate',
    seoLevel: 'fair'
  };
  
  // Check if the text is empty
  if (!text || text.trim() === '') {
    result.recommendations.push('Add content to receive LinkedIn SEO recommendations.');
    result.seoLevel = 'poor';
    result.score = 0;
    return result;
  }
  
  // Get relevant keywords for the specified industry
  const relevantKeywords = [...INDUSTRY_KEYWORDS[industry] || [], ...INDUSTRY_KEYWORDS.general];
  
  // Basic text normalization
  const normalizedText = text.toLowerCase();
  const words = normalizedText.split(/\s+/);
  const wordCount = words.length;
  
  // ===== Check content length =====
  if (wordCount < 50) {
    result.recommendations.push('Your post is too short. LinkedIn favors posts between 150-250 words for optimal engagement.');
    result.contentGaps.push('Content length');
  } else if (wordCount > 500) {
    result.recommendations.push('Your post might be too long. Consider breaking it into multiple posts or shortening it for better engagement.');
    result.contentGaps.push('Content conciseness');
  } else {
    result.idealLength = true;
    result.strongAreas.push('Optimal content length');
  }
  
  // ===== Check for relevant keywords =====
  const keywordCounts: Record<string, number> = {};
  
  // Check each industry keyword
  relevantKeywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    const matches = normalizedText.match(regex);
    const count = matches ? matches.length : 0;
    
    if (count > 0) {
      keywordCounts[keyword] = count;
      result.keywordsFound.push({ keyword, count });
    }
  });
  
  // Calculate keyword density
  const totalKeywordCount = Object.values(keywordCounts).reduce((sum, count) => sum + count, 0);
  result.keywordDensity = wordCount > 0 ? (totalKeywordCount / wordCount) * 100 : 0;
  
  if (result.keywordsFound.length === 0) {
    result.recommendations.push('No industry-relevant keywords found. Include terms commonly used in your field to improve discoverability.');
    result.contentGaps.push('Industry-specific keywords');
  } else if (result.keywordsFound.length < 3) {
    result.recommendations.push('Add more industry-relevant keywords to improve your post\'s discoverability.');
    result.contentGaps.push('Keyword variety');
  } else if (result.keywordDensity > 10) {
    result.recommendations.push('Your keyword density is too high, which might make your content seem like keyword stuffing. Aim for a more natural usage.');
    result.contentGaps.push('Natural language usage');
  } else {
    result.strongAreas.push('Good use of industry keywords');
  }
  
  // ===== Suggest keywords that are missing =====
  // Find relevant keywords that aren't in the text
  const missingKeywords = relevantKeywords.filter(keyword => 
    !normalizedText.includes(keyword.toLowerCase())
  );
  
  // Suggest a reasonable number of missing keywords
  if (missingKeywords.length > 0) {
    // Shuffle array to get different suggestions each time
    const shuffled = [...missingKeywords].sort(() => 0.5 - Math.random());
    result.keywordSuggestions = shuffled.slice(0, Math.min(5, shuffled.length));
  }
  
  // ===== Check for hashtags =====
  const hashtagRegex = /#[a-zA-Z0-9]+/g;
  const hashtags = normalizedText.match(hashtagRegex) || [];
  
  if (hashtags.length === 0) {
    result.recommendations.push('Add 3-5 relevant hashtags to increase your post\'s discoverability. Place them at the end of your post.');
    result.contentGaps.push('Hashtags');
  } else if (hashtags.length > 9) {
    result.recommendations.push('You\'re using too many hashtags. LinkedIn works best with 3-5 focused hashtags rather than many.');
    result.contentGaps.push('Focused hashtag strategy');
  } else {
    result.strongAreas.push('Good hashtag usage');
  }
  
  // ===== Suggest relevant hashtags =====
  // Prioritize industry-specific hashtags plus some trending ones
  const industryHashtags = (INDUSTRY_KEYWORDS[industry] || [])
    .map(keyword => `#${keyword.replace(/\s+/g, '')}`)
    .filter(hashtag => !hashtags.includes(hashtag));
  
  const trendingHashtagsNotUsed = TRENDING_HASHTAGS
    .map(tag => `#${tag}`)
    .filter(hashtag => !hashtags.includes(hashtag));
  
  // Combine and limit recommendations
  const hashtagRecommendations = [
    ...industryHashtags.slice(0, 3), 
    ...trendingHashtagsNotUsed.slice(0, 2)
  ].slice(0, 5);
  
  result.hashtagRecommendations = hashtagRecommendations;
  
  // ===== Check for rich media mentions =====
  const mediaRegex = /image|photo|video|infographic|carousel|pdf|document|poll/gi;
  const mediaMatches = normalizedText.match(mediaRegex) || [];
  
  if (mediaMatches.length === 0) {
    result.recommendations.push('Consider mentioning or including rich media (images, videos, documents) in your post for higher engagement rates.');
    result.contentGaps.push('Rich media');
  } else {
    result.strongAreas.push('Rich media mentioned');
  }
  
  // ===== Check for engagement prompts =====
  const promptRegex = /what do you think|share your|comment below|your thoughts|agree|question|poll/gi;
  const promptMatches = normalizedText.match(promptRegex) || [];
  
  if (promptMatches.length === 0) {
    result.recommendations.push('Add a question or call to action to encourage comments, which boosts your post in LinkedIn\'s algorithm.');
    result.contentGaps.push('Engagement prompt');
  } else {
    result.strongAreas.push('Good engagement prompt');
  }
  
  // ===== Readability Analysis =====
  // Very basic formula: words per sentence
  const sentences = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0);
  const avgWordsPerSentence = sentences.length > 0 
    ? wordCount / sentences.length 
    : wordCount;
  
  if (avgWordsPerSentence > 25) {
    result.readabilityLevel = 'advanced';
    result.recommendations.push('Your sentences are quite long. For better readability on LinkedIn, aim for an average of 15-20 words per sentence.');
    result.contentGaps.push('Sentence simplicity');
  } else if (avgWordsPerSentence < 10) {
    result.readabilityLevel = 'basic';
    result.strongAreas.push('Concise, easy-to-read sentences');
  } else {
    result.readabilityLevel = 'intermediate';
    result.strongAreas.push('Good sentence structure');
  }
  
  // ===== LinkedIn URL Pattern =====
  const linkRegex = /linkedin\.com\/[a-z]+\/[a-z0-9_-]+/gi;
  const linkMatches = normalizedText.match(linkRegex) || [];
  
  if (linkMatches.length > 1) {
    result.recommendations.push('Multiple LinkedIn links detected. The algorithm may penalize posts with too many links. Consider focusing on a single link if needed.');
    result.contentGaps.push('Focused external links');
  }
  
  // ===== External URL Pattern =====
  const externalLinkRegex = /https?:\/\/(?!.*linkedin\.com)[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+/gi;
  const externalLinkMatches = normalizedText.match(externalLinkRegex) || [];
  
  if (externalLinkMatches.length > 0) {
    result.recommendations.push('External links detected. For better reach, consider putting links in the first comment rather than in the main post body.');
    result.contentGaps.push('Link placement strategy');
  }
  
  // ===== Personal Pronoun Check =====
  const firstPersonRegex = /\b(i|we|our|us|my)\b/gi;
  const firstPersonMatches = normalizedText.match(firstPersonRegex) || [];
  
  if (firstPersonMatches.length === 0) {
    result.recommendations.push('Add a personal touch by using "I" or "we" to increase authenticity and connection with your audience.');
    result.contentGaps.push('Personal voice');
  } else {
    result.strongAreas.push('Good personal voice');
  }
  
  // ===== Calculate overall score =====
  // Base score starts at 50
  let score = 50;
  
  // Content length: +/- 10 points
  if (result.idealLength) {
    score += 10;
  } else {
    score -= 10;
  }
  
  // Keywords: 0-20 points
  const keywordScore = Math.min(20, result.keywordsFound.length * 4);
  score += keywordScore;
  
  // Hashtags: 0-10 points
  if (hashtags.length >= 3 && hashtags.length <= 5) {
    score += 10;
  } else if (hashtags.length > 0) {
    score += 5;
  }
  
  // Media: 0-5 points
  if (mediaMatches.length > 0) {
    score += 5;
  }
  
  // Engagement: 0-5 points
  if (promptMatches.length > 0) {
    score += 5;
  }
  
  // Deductions for external links: 0-5 points
  if (externalLinkMatches.length > 0) {
    score -= 5;
  }
  
  // Finalize score (0-100 range)
  result.score = Math.max(0, Math.min(100, score));
  
  // Determine SEO level based on score
  if (result.score >= 80) {
    result.seoLevel = 'excellent';
  } else if (result.score >= 60) {
    result.seoLevel = 'good';
  } else if (result.score >= 40) {
    result.seoLevel = 'fair';
  } else {
    result.seoLevel = 'poor';
  }
  
  return result;
}