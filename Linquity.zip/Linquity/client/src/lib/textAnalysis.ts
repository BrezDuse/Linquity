/**
 * Calculate reading time in seconds based on word count
 * @param wordCount Number of words in the text
 * @returns Estimated reading time in seconds
 */
export function calculateReadingTime(wordCount: number): number {
  // Average adult reading speed is about 200-250 words per minute
  // We'll use 225 words per minute as the average
  const wordsPerMinute = 225;
  const minutes = wordCount / wordsPerMinute;
  return Math.ceil(minutes * 60); // Convert to seconds and round up
}

/**
 * Calculate word count from text
 * @param text The input text
 * @returns Number of words
 */
export function countWords(text: string): number {
  if (!text || text.trim() === '') return 0;
  return text.trim().split(/\s+/).length;
}

/**
 * Calculate Flesch Reading Ease score (simplified version)
 * Higher scores indicate material that is easier to read
 * @param text The input text
 * @returns A score between 0-100
 */
export function calculateFleschReadingEase(text: string): number {
  if (!text || text.trim() === '') return 0;
  
  // Count words, sentences, and syllables (approximate)
  const words = text.trim().split(/\s+/);
  const wordCount = words.length;
  
  // Count sentences (split by periods, exclamation points, question marks)
  const sentences = text.split(/[.!?]+/).filter(s => s.trim() !== '');
  const sentenceCount = sentences.length || 1; // Avoid division by zero
  
  // Approximate syllable count (very simplified)
  const syllableCount = words.reduce((count, word) => {
    return count + countSyllables(word);
  }, 0);
  
  // Flesch Reading Ease formula
  const score = 206.835 - (1.015 * (wordCount / sentenceCount)) - (84.6 * (syllableCount / wordCount));
  
  // Ensure score is within 0-100 range
  return Math.min(100, Math.max(0, Math.round(score)));
}

/**
 * Very simplified syllable counter (English only)
 * @param word A single word
 * @returns Approximate syllable count
 */
function countSyllables(word: string): number {
  word = word.toLowerCase().trim();
  if (!word) return 0;
  
  // Remove common suffixes
  word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
  word = word.replace(/^y/, '');
  
  // Count vowel groups
  const syllables = word.match(/[aeiouy]{1,2}/g);
  return syllables ? syllables.length : 1;
}

/**
 * Get reading level description based on Flesch score
 * @param score Flesch Reading Ease score (0-100)
 * @returns Description of the reading level
 */
export function getReadabilityRating(score: number): string {
  if (score >= 90) return "Very Easy";
  if (score >= 80) return "Easy";
  if (score >= 70) return "Good";
  if (score >= 60) return "Moderate";
  if (score >= 50) return "Fairly Difficult";
  if (score >= 30) return "Difficult";
  return "Very Difficult";
}

/**
 * Identify long or complex sentences in text
 * @param text The input text
 * @returns Array of long/complex sentences
 */
export function findComplexSentences(text: string): string[] {
  const sentences = text.split(/[.!?]+/).filter(s => s.trim() !== '');
  
  return sentences.filter(sentence => {
    const words = sentence.trim().split(/\s+/);
    const wordCount = words.length;
    
    // Sentence is complex if it has more than 20 words
    // or contains certain markers like semicolons, em-dashes
    return wordCount > 20 || 
           sentence.includes(';') || 
           sentence.includes('—') ||
           sentence.includes('however') ||
           sentence.includes('therefore');
  });
}
