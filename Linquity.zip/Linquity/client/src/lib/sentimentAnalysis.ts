/**
 * Sentiment Analysis Module for LinkedIn Content
 * 
 * This module provides functionality to analyze the emotional tone and sentiment
 * of LinkedIn content to help users optimize their messaging.
 */

export interface SentimentResult {
  score: number; // Range from -1 (very negative) to 1 (very positive)
  comparative: number; // Normalized score based on text length
  calculation: Record<string, number>; // Individual word scores
  positive: string[]; // Positive words found
  negative: string[]; // Negative words found
  tone: 'very negative' | 'negative' | 'neutral' | 'positive' | 'very positive';
  emotionalTone: 'professional' | 'optimistic' | 'enthusiastic' | 'empathetic' | 'confident' | 'cautious' | 'urgent';
  dominantEmotions: string[]; // Primary emotions detected
  suggestions: string[]; // Improvement suggestions
  emotions: Record<string, number>; // Emotional dimensions with scores
}

// Dictionary of positive words with intensity values
const POSITIVE_WORDS: Record<string, number> = {
  'achieve': 2,
  'achievement': 2,
  'advantage': 1,
  'amazing': 3,
  'believe': 1,
  'benefit': 2,
  'best': 2,
  'better': 1,
  'brilliant': 3,
  'celebrate': 2,
  'confident': 2,
  'create': 1,
  'creative': 2,
  'delight': 3,
  'delighted': 3,
  'easy': 1,
  'effective': 2,
  'efficient': 2,
  'enjoy': 2,
  'excellent': 3,
  'exceptional': 3,
  'excited': 3,
  'exciting': 3,
  'extraordinary': 3,
  'fantastic': 3,
  'fortunate': 2,
  'free': 1,
  'friendly': 2,
  'fun': 2,
  'generous': 2,
  'good': 1,
  'great': 2,
  'happy': 2,
  'helpful': 2,
  'ideal': 2,
  'impressive': 3,
  'improve': 1,
  'incredible': 3,
  'innovate': 2,
  'innovative': 2,
  'inspire': 2,
  'inspiring': 2,
  'leading': 2,
  'love': 3,
  'opportunity': 2,
  'optimistic': 2,
  'outstanding': 3,
  'perfect': 3,
  'pleased': 2,
  'positive': 2,
  'powerful': 2,
  'premium': 2,
  'progress': 1,
  'proud': 2,
  'recommend': 2,
  'reliable': 2,
  'spectacular': 3,
  'success': 2,
  'successful': 2,
  'support': 1,
  'supportive': 2,
  'thrive': 2,
  'thrilled': 3,
  'trusted': 2,
  'valuable': 2,
  'value': 1,
  'win': 2,
  'wonderful': 3,
  'worthy': 2
};

// Dictionary of negative words with intensity values
const NEGATIVE_WORDS: Record<string, number> = {
  'afraid': -2,
  'against': -1,
  'aggressive': -2,
  'anxiety': -2,
  'anxious': -2,
  'awful': -3,
  'bad': -2,
  'boring': -2,
  'broken': -2,
  'challenge': -1, // Can be positive in context
  'chaotic': -2,
  'complicated': -2,
  'concerned': -1,
  'concern': -1,
  'confusing': -2,
  'confused': -2,
  'damage': -2,
  'damaged': -2,
  'delay': -1,
  'delayed': -1,
  'difficult': -1,
  'disappointed': -2,
  'disappointing': -2,
  'disaster': -3,
  'doubt': -1,
  'error': -2,
  'fail': -2,
  'failed': -2,
  'failure': -2,
  'fear': -2,
  'fearful': -2,
  'flaw': -2,
  'flawed': -2,
  'forget': -1,
  'frustrate': -2,
  'frustrated': -2,
  'frustrating': -2,
  'hard': -1,
  'harm': -2,
  'harmful': -2,
  'hate': -3,
  'horrible': -3,
  'hurt': -2,
  'hurting': -2,
  'impossible': -2,
  'inadequate': -2,
  'ineffective': -2,
  'inferior': -2,
  'issue': -1,
  'lag': -1,
  'lagging': -1,
  'lose': -1,
  'losing': -1,
  'loss': -1,
  'lost': -1,
  'misunderstand': -1,
  'negative': -1,
  'never': -1,
  'not working': -2,
  'painful': -2,
  'poor': -2,
  'problem': -1,
  'regret': -2,
  'reject': -2,
  'rejected': -2,
  'risk': -1,
  'risky': -1,
  'rude': -2,
  'sad': -2,
  'slow': -1,
  'sorry': -1,
  'struggle': -1,
  'struggling': -1,
  'stuck': -1,
  'terrible': -3,
  'threat': -2,
  'tired': -1,
  'trouble': -2,
  'unbearable': -3,
  'uncertain': -1,
  'uncomfortable': -2,
  'unfortunate': -2,
  'unhappy': -2,
  'upset': -2,
  'weak': -2,
  'worried': -2,
  'worry': -2,
  'worse': -2,
  'worst': -3,
  'worthless': -3,
  'wrong': -2
};

// Words that boost or amplify sentiment
const BOOSTERS: Record<string, number> = {
  'absolutely': 1.5,
  'amazingly': 1.5,
  'completely': 1.25,
  'considerably': 1.25,
  'decidedly': 1.25,
  'deeply': 1.25,
  'enormously': 1.5,
  'entirely': 1.25,
  'especially': 1.25,
  'exceptional': 1.5,
  'exceptionally': 1.5,
  'extremely': 1.5,
  'greatly': 1.25,
  'highly': 1.25,
  'hugely': 1.5,
  'incredibly': 1.5,
  'intensely': 1.25,
  'particularly': 1.25,
  'really': 1.25,
  'remarkably': 1.25,
  'significantly': 1.25,
  'substantially': 1.25,
  'thoroughly': 1.25,
  'totally': 1.5,
  'tremendously': 1.5,
  'unbelievably': 1.5,
  'unusually': 1.25,
  'very': 1.25
};

// Words that reduce sentiment
const DIMINISHERS: Record<string, number> = {
  'almost': 0.75,
  'barely': 0.5,
  'hardly': 0.5,
  'just': 0.75,
  'kind of': 0.75,
  'kind-of': 0.75,
  'kinda': 0.75,
  'little': 0.75,
  'marginally': 0.75,
  'minimally': 0.5,
  'moderately': 0.75,
  'nearly': 0.75,
  'only': 0.75,
  'partially': 0.75,
  'rather': 0.75,
  'relatively': 0.75,
  'slightly': 0.5,
  'somewhat': 0.75,
  'sort of': 0.75,
  'sort-of': 0.75,
  'sorta': 0.75,
  'tentatively': 0.5
};

// Words that negate sentiment
const NEGATORS = [
  'not', 'no', 'none', 'neither', 'never', 'nobody', 'nowhere', 'isn\'t', 'aren\'t',
  'wasn\'t', 'weren\'t', 'haven\'t', 'hasn\'t', 'hadn\'t', 'doesn\'t', 'don\'t',
  'didn\'t', 'won\'t', 'wouldn\'t', 'can\'t', 'couldn\'t', 'shouldn\'t', 'without'
];

/**
 * Analyze the sentiment of a piece of text
 * 
 * @param text The text to analyze
 * @returns A detailed sentiment analysis result
 */
export function analyzeSentiment(text: string): SentimentResult {
  // Tokenize the text
  const words = text.toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
    .split(/\s+/);
  
  // Track scores
  let score = 0;
  const calculation: Record<string, number> = {};
  const positiveWords: string[] = [];
  const negativeWords: string[] = [];
  const emotions: Record<string, number> = {
    'optimism': 0,
    'enthusiasm': 0,
    'empathy': 0,
    'confidence': 0,
    'caution': 0,
    'urgency': 0,
    'professionalism': 0
  };
  
  // Process each word
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    
    // Check for negation (look at the previous word)
    const prevWord = i > 0 ? words[i - 1] : '';
    const isNegated = NEGATORS.includes(prevWord);
    
    // Check for boosters or diminishers (look at the previous word)
    const booster = BOOSTERS[prevWord] || 1;
    const diminisher = DIMINISHERS[prevWord] || 1;
    const modifier = isNegated ? -1 : (booster * diminisher);
    
    // Calculate word score
    let wordScore = 0;
    
    if (POSITIVE_WORDS[word]) {
      wordScore = POSITIVE_WORDS[word] * modifier;
      if (!isNegated) {
        positiveWords.push(word);
      }
    } else if (NEGATIVE_WORDS[word]) {
      wordScore = NEGATIVE_WORDS[word] * modifier;
      if (!isNegated) {
        negativeWords.push(word);
      }
    }
    
    // Track the calculation
    if (wordScore !== 0) {
      calculation[word] = wordScore;
      score += wordScore;
    }
    
    // Assess emotional dimensions
    // These detection rules are simplified for demonstration
    if (/believ|trust|hope|future|better|improve|grow/.test(word)) {
      emotions['optimism'] += 1;
    }
    if (/excit|thrill|passion|love|amaz|incredibl|fantastic/.test(word)) {
      emotions['enthusiasm'] += 1;
    }
    if (/understand|feel|support|help|care|together|community/.test(word)) {
      emotions['empathy'] += 1;
    }
    if (/certain|sure|prove|evidence|data|result|success|achieve/.test(word)) {
      emotions['confidence'] += 1;
    }
    if (/careful|risk|consider|assess|evaluate|may|might|could/.test(word)) {
      emotions['caution'] += 1;
    }
    if (/now|urgent|immediate|quickly|fast|soon|today|deadline/.test(word)) {
      emotions['urgency'] += 1;
    }
    if (/research|study|analysis|professional|expert|industry|standard/.test(word)) {
      emotions['professionalism'] += 1;
    }
  }
  
  // Calculate comparative score normalized by text length
  const comparative = words.length > 0 ? score / words.length : 0;
  
  // Determine tone based on score
  let tone: SentimentResult['tone'] = 'neutral';
  if (score > 3) {
    tone = 'very positive';
  } else if (score > 0) {
    tone = 'positive';
  } else if (score < -3) {
    tone = 'very negative';
  } else if (score < 0) {
    tone = 'negative';
  }
  
  // Determine dominant emotional tone
  let emotionalTone: SentimentResult['emotionalTone'] = 'professional';
  const emotionEntries = Object.entries(emotions);
  const sortedEmotions = emotionEntries.sort((a, b) => b[1] - a[1]);
  
  if (sortedEmotions.length > 0 && sortedEmotions[0][1] > 0) {
    const topEmotion = sortedEmotions[0][0];
    switch (topEmotion) {
      case 'optimism':
        emotionalTone = 'optimistic';
        break;
      case 'enthusiasm':
        emotionalTone = 'enthusiastic';
        break;
      case 'empathy':
        emotionalTone = 'empathetic';
        break;
      case 'confidence':
        emotionalTone = 'confident';
        break;
      case 'caution':
        emotionalTone = 'cautious';
        break;
      case 'urgency':
        emotionalTone = 'urgent';
        break;
      default:
        emotionalTone = 'professional';
    }
  }
  
  // Get the dominant emotions (top 3 if they have scores)
  const dominantEmotions = sortedEmotions
    .filter(([_, score]) => score > 0)
    .slice(0, 3)
    .map(([emotion]) => emotion);
  
  // Generate improvement suggestions based on analysis
  const suggestions: string[] = [];
  
  // Suggestion based on overall tone
  if (score < -1) {
    suggestions.push('Your content has a negative tone that may not resonate well on social media. Consider reframing with more positive language.');
  } else if (score < 0.5) {
    suggestions.push('Adding more positive and inspiring language could boost engagement on your post.');
  }
  
  // Suggestion based on emotional balance
  if (emotions['enthusiasm'] > 4 && emotions['confidence'] < 2) {
    suggestions.push('Your enthusiasm is clear, but adding data or evidence would build more credibility.');
  }
  
  if (emotions['confidence'] > 4 && emotions['empathy'] < 2) {
    suggestions.push('Your confidence comes through well, but adding more empathetic language would help connect with your audience.');
  }
  
  if (emotions['urgency'] > 3 && emotions['professionalism'] < 2) {
    suggestions.push('The sense of urgency may come across as overly promotional. Balance with more professional insights.');
  }
  
  // General content-specific suggestions
  if (words.length < 50) {
    suggestions.push('Your post is quite short. The algorithm tends to favor longer, thoughtful content.');
  } else if (words.length > 300) {
    suggestions.push('Your post is very long. Consider breaking it into key points with line breaks for better readability.');
  }
  
  if (positiveWords.length < 3 && words.length > 50) {
    suggestions.push('Including more positive terms like "opportunity," "success," or "benefit" can increase engagement.');
  }
  
  if (negativeWords.length > positiveWords.length) {
    suggestions.push('Your content has more negative terms than positive ones. Audiences typically respond better to positive, solution-oriented content.');
  }
  
  // If no suggestions were generated, add a generic one
  if (suggestions.length === 0) {
    if (score > 2) {
      suggestions.push('Your content has a strong positive tone that is likely to resonate well with readers.');
    } else {
      suggestions.push('Consider adding more industry-specific terminology to position yourself as a thought leader in your field.');
    }
  }
  
  return {
    score,
    comparative,
    calculation,
    positive: positiveWords,
    negative: negativeWords,
    tone,
    emotionalTone,
    dominantEmotions,
    suggestions,
    emotions
  };
}

/**
 * Get ideal emotion balance recommendations based on post goal
 * 
 * @param goal The goal of the post
 * @returns An object with recommended emotional balance
 */
export function getIdealEmotionBalance(goal: string): Record<string, number> {
  switch (goal.toLowerCase()) {
    case 'thought leadership':
      return {
        'confidence': 4,
        'professionalism': 4,
        'optimism': 3,
        'enthusiasm': 2,
        'empathy': 3,
        'caution': 2,
        'urgency': 1
      };
    case 'job search':
      return {
        'confidence': 3,
        'professionalism': 4,
        'optimism': 3,
        'enthusiasm': 2,
        'empathy': 3,
        'caution': 1,
        'urgency': 1
      };
    case 'networking':
      return {
        'confidence': 3,
        'professionalism': 3,
        'optimism': 3,
        'enthusiasm': 2,
        'empathy': 5,
        'caution': 1,
        'urgency': 1
      };
    case 'lead generation':
      return {
        'confidence': 4,
        'professionalism': 3,
        'optimism': 3,
        'enthusiasm': 3,
        'empathy': 4,
        'caution': 1,
        'urgency': 2
      };
    case 'promotional':
      return {
        'confidence': 4,
        'professionalism': 3,
        'optimism': 3,
        'enthusiasm': 4,
        'empathy': 3,
        'caution': 1,
        'urgency': 3
      };
    default:
      return {
        'confidence': 3,
        'professionalism': 3,
        'optimism': 3,
        'enthusiasm': 3,
        'empathy': 3,
        'caution': 2,
        'urgency': 2
      };
  }
}