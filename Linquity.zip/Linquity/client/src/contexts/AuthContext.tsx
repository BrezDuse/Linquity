import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

// User interface
interface User {
  id: number;
  email: string;
  firstName: string | null;
  lastName: string | null;
  isVerified: boolean;
  accessToken: string;
}

// Auth context interface
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  checkEmailVerification: () => Promise<boolean>;
  sendVerificationEmail: () => Promise<boolean>;
}

// Register data interface
interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName?: string;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: false,
  isAuthenticated: false,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
  checkEmailVerification: async () => false,
  sendVerificationEmail: async () => false,
});

// Custom hook to use the auth context
export const useAuth = () => useContext(AuthContext);

// Provider component
export const AuthProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      setIsLoading(true);
      try {
        const token = localStorage.getItem('accessToken');
        if (token) {
          const response = await fetch('/api/auth/me', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          if (response.ok) {
            const userData = await response.json();
            setUser({
              ...userData,
              accessToken: token,
            });
          } else {
            // Clear invalid token
            localStorage.removeItem('accessToken');
          }
        }
      } catch (error) {
        console.error('Authentication check failed:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuth();
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Login failed');
      }

      const userData = await response.json();
      
      // Store the token
      localStorage.setItem('accessToken', userData.accessToken);
      
      // Set the user data
      setUser(userData);
      
      // Show a welcome message
      toast({
        title: 'Welcome back!',
        description: userData.isVerified 
          ? 'You are now logged in.' 
          : 'Please verify your email to access all features.',
      });
      
      // Redirect to home
      setLocation('/');
      
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (userData: RegisterData) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...userData,
          confirmPassword: userData.password, // The API expects this field
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Registration failed');
      }

      const newUser = await response.json();
      
      // Store the token
      localStorage.setItem('accessToken', newUser.accessToken);
      
      // Set the user data
      setUser(newUser);
      
      // Show welcome message
      toast({
        title: 'Account created!',
        description: 'Please check your email to verify your account.',
      });
      
      // Redirect to verification page
      setLocation('/verify-email');
      
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('accessToken');
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
    } catch (error) {
      console.error('Logout failed:', error);
    } finally {
      // Always clear local data
      localStorage.removeItem('accessToken');
      setUser(null);
      setIsLoading(false);
      
      // Show logout message
      toast({
        title: 'Logged out',
        description: 'You have been successfully logged out.',
      });
      
      // Redirect to login
      setLocation('/login');
    }
  };

  // Check email verification status
  const checkEmailVerification = async (): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const response = await fetch('/api/auth/email-status', {
        headers: {
          Authorization: `Bearer ${user.accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to check email verification status');
      }

      const { isVerified } = await response.json();
      
      // Update user state with new verification status
      if (isVerified !== user.isVerified) {
        setUser(prev => prev ? { ...prev, isVerified } : null);
      }
      
      return isVerified;
    } catch (error) {
      console.error('Email verification check failed:', error);
      return false;
    }
  };

  // Request a new verification email
  const sendVerificationEmail = async (): Promise<boolean> => {
    if (!user) return false;
    
    try {
      // This endpoint will be implemented later when Mailchimp is connected
      const response = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to send verification email');
      }

      return true;
    } catch (error) {
      console.error('Failed to send verification email:', error);
      return false;
    }
  };

  // Create the context value
  const contextValue = {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    checkEmailVerification,
    sendVerificationEmail,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};