interface Template {
  id: string;
  name: string;
  description: string;
  content: string;
  goal: string;
  tone: string;
  category: 'professional' | 'career' | 'thought-leadership' | 'announcement' | 'event';
}

export const postTemplates: Template[] = [
  {
    id: 'case-study-roi',
    name: 'ROI Case Study',
    description: 'Share results with clear return on investment',
    category: 'professional',
    goal: 'educate',
    tone: 'professional',
    content: `📊 CASE STUDY: How [Company/Client] achieved [X]% ROI with [Solution/Strategy]

Over [timeframe], we helped [industry type] client overcome [specific challenge].

THE CHALLENGE:
• [Client] was struggling with [pain point 1]
• Their previous approach resulted in [negative outcome]
• This cost them approximately [financial or resource cost]

OUR APPROACH:
1. [Key strategy component 1]
2. [Key strategy component 2]
3. [Key strategy component 3]

THE RESULTS:
• [X]% increase in [key metric]
• $[amount] in [savings/revenue/profit]
• [Qualitative benefit] improvement within just [timeframe]

📈 ROI BREAKDOWN:
Total investment: $[amount]
Total return: $[amount]
ROI: [X]%
Payback period: [timeframe]

The most valuable insight from this project: [key learning that others can apply]

Interested in similar results for your business? Let's connect.

#CaseStudy #ROI #[Industry]`
  },
  
  {
    id: 'case-study-transformation',
    name: 'Digital Transformation Case Study',
    description: 'Showcase a digital transformation success story',
    category: 'professional',
    goal: 'educate',
    tone: 'professional',
    content: `DIGITAL TRANSFORMATION CASE STUDY: [Company Name]'s Journey

Before: [Brief description of company's previous state]
• Relying on [outdated process/technology]
• Struggling with [specific pain points]
• Falling behind competitors due to [limitation]

The Transformation Journey:
1. PHASE 1: [Initial stage] (Duration: [timeframe])
   • [Key implementation or change]
   • [Challenge overcome]
   • [Initial result]

2. PHASE 2: [Middle stage] (Duration: [timeframe])
   • [Key implementation or change]
   • [Challenge overcome]
   • [Result]

3. PHASE 3: [Final stage] (Duration: [timeframe])
   • [Key implementation or change]
   • [Challenge overcome]
   • [Result]

MEASURABLE OUTCOMES:
• Efficiency: [X]% improvement in [process]
• Cost: [X]% reduction in [expense category]
• Revenue: [X]% increase in [revenue stream]
• Customer satisfaction: [Specific improvement]

KEY SUCCESS FACTORS:
1. [Critical success factor 1]
2. [Critical success factor 2]
3. [Critical success factor 3]

Transformations aren't just about technology—they're about [key insight about people/process/culture].

Would you like to discuss your organization's digital transformation? Let's connect.

#DigitalTransformation #CaseStudy #[Industry]`
  },
  
  {
    id: 'case-study-problem-solution',
    name: 'Problem-Solution Case Study',
    description: 'Present a client problem and your innovative solution',
    category: 'professional',
    goal: 'educate',
    tone: 'storytelling',
    content: `THE PROBLEM:
[Client description] came to us with a critical challenge:
[Detailed explanation of the problem they were facing]

This resulted in:
• [Negative consequence 1]
• [Negative consequence 2]
• [Negative consequence 3]

THE SOLUTION:
After careful analysis, we developed a custom approach:

Step 1: [First component of solution]
✓ [How this addressed a specific aspect of the problem]
✓ [Specific action taken]

Step 2: [Second component of solution]
✓ [How this addressed a specific aspect of the problem]
✓ [Specific action taken]

Step 3: [Third component of solution]
✓ [How this addressed a specific aspect of the problem]
✓ [Specific action taken]

THE OUTCOME:
Within [timeframe], the client experienced:
• [Positive result 1] - [specific metric if applicable]
• [Positive result 2] - [specific metric if applicable]
• [Positive result 3] - [specific metric if applicable]

LESSONS LEARNED:
The most valuable insight from this project was [key learning that others can apply].

Have a similar challenge? I'd be happy to discuss how we might approach it for your organization.

#CaseStudy #ProblemSolving #[Industry]`
  },
  
  {
    id: 'case-study-customer-success',
    name: 'Customer Success Story',
    description: 'Highlight a customer success story with testimonial',
    category: 'professional',
    goal: 'promote',
    tone: 'storytelling',
    content: `"[Powerful quote from client about results achieved]" - [Client name], [Position] at [Company]

CUSTOMER SUCCESS STORY:

ABOUT THE CLIENT:
[Brief description of client company, industry, and size]

THEIR CHALLENGE:
[Client name] was facing [specific challenge]:
• [Detail of pain point 1]
• [Detail of pain point 2]
• [Detail of pain point 3]

WHY THEY CHOSE US:
After considering multiple options, they selected our [product/service/solution] because:
• [Unique value proposition 1]
• [Unique value proposition 2]
• [Unique value proposition 3]

THE IMPLEMENTATION:
Our teams collaborated to [brief description of implementation process]:
1. [Key milestone 1]
2. [Key milestone 2]
3. [Key milestone 3]

THE RESULTS:
Within [timeframe], [Client name] achieved:
• [Measurable result 1]
• [Measurable result 2]
• [Measurable result 3]

IN THEIR WORDS:
"[Extended testimonial from client about their experience and results]"

Want to learn more about how we can deliver similar results for your organization? DM me or comment below.

#CustomerSuccess #Testimonial #[Industry]`
  },
  
  {
    id: 'case-study-before-after',
    name: 'Before & After Case Study',
    description: 'Show dramatic before and after results',
    category: 'professional',
    goal: 'promote',
    tone: 'professional',
    content: `BEFORE & AFTER: [Brief description of transformation]

CLIENT PROFILE:
[Industry] company with [relevant characteristics]

BEFORE:
📉 [Metric 1]: [Baseline value]
📉 [Metric 2]: [Baseline value]
📉 [Metric 3]: [Baseline value]

THE CHALLENGE:
[Detailed description of the situation and pain points the client was experiencing]

OUR PROCESS:
We implemented a [timeframe] program focusing on three key areas:

1️⃣ [Focus area 1]
   • [Specific tactic/implementation]
   • [Specific tactic/implementation]

2️⃣ [Focus area 2]
   • [Specific tactic/implementation]
   • [Specific tactic/implementation]

3️⃣ [Focus area 3]
   • [Specific tactic/implementation]
   • [Specific tactic/implementation]

AFTER:
📈 [Metric 1]: [New value] ([X]% improvement)
📈 [Metric 2]: [New value] ([X]% improvement)
📈 [Metric 3]: [New value] ([X]% improvement)

Additional Benefits:
✓ [Unexpected positive outcome]
✓ [Unexpected positive outcome]

SUSTAINABILITY:
[Description of how the results have been maintained over time]

What transformation could your organization achieve with the right approach? Let's discuss.

#BeforeAndAfter #CaseStudy #[Industry]`
  },
  {
    id: 'weekly-insight',
    name: 'Weekly Industry Insight',
    description: 'Share a weekly professional insight',
    category: 'thought-leadership',
    goal: 'educate',
    tone: 'professional',
    content: `My weekly insight on [industry topic]:

The most overlooked opportunity in [specific area] right now is [observation].

3 reasons why this matters:
• [Reason 1] 
• [Reason 2]
• [Reason 3]

For professionals looking to stay ahead, consider [actionable suggestion].

What's your take on this? Would love to hear your perspectives.

#[Industry] #WeeklyInsight #ProfessionalDevelopment`
  },
  {
    id: 'product-launch',
    name: 'Product Launch',
    description: 'Announce a new product or service',
    category: 'announcement',
    goal: 'promote',
    tone: 'professional',
    content: `Excited to announce the launch of [Product/Service Name] today! 🚀

After [timeframe] of development, we've created a solution that [primary benefit].

Key features:
• [Feature 1] - [Brief benefit explanation]
• [Feature 2] - [Brief benefit explanation]
• [Feature 3] - [Brief benefit explanation]

Early users are already seeing [specific result].

Learn more: [Link]

#ProductLaunch #[Industry] #Innovation`
  },
  {
    id: 'networking-request',
    name: 'Networking Request',
    description: 'Connect with professionals in your industry',
    category: 'career',
    goal: 'connect',
    tone: 'professional',
    content: `I'm looking to connect with professionals who have expertise in [specific area/skill].

Currently, I'm working on [project/initiative] and would value insights on:
• [Specific question/area 1]
• [Specific question/area 2]
• [Specific question/area 3]

If this aligns with your experience, I'd appreciate a brief conversation. Please comment or DM me if you're open to connecting.

Thank you for considering!

#ProfessionalNetworking #[Industry] #CareerGrowth`
  },
  {
    id: 'work-anniversary',
    name: 'Work Anniversary',
    description: 'Celebrate a work anniversary milestone',
    category: 'professional',
    goal: 'reflect',
    tone: 'storytelling',
    content: `Today marks [number] years at [Company Name]! 🎉

Looking back, some highlights include:
• [Achievement/project 1]
• [Achievement/project 2]
• [Achievement/project 3]

The biggest lesson I've learned: [key insight]

I'm grateful to [acknowledgment of colleagues/mentors] for their support throughout this journey.

Excited for what's ahead in the coming year as we [future focus].

#WorkAnniversary #CareerJourney #[Industry]`
  },
  {
    id: 'career-transition',
    name: 'Career Transition',
    description: 'Announce a career change or new role',
    category: 'career',
    goal: 'announce',
    tone: 'professional',
    content: `I'm thrilled to share that I'm starting a new role as [Position] at [Company]!

After [timeframe] at [Previous Company], I'm grateful for:
• [Learning/experience 1]
• [Learning/experience 2]
• [Accomplishment]

I'm excited to bring my expertise in [skills/areas] to tackle [challenges/opportunities] in this new chapter.

Thank you to everyone who has supported me along the way. I look forward to connecting with my new colleagues and continuing to grow in [industry/field].

#NewRole #CareerMove #[Industry]`
  },
  {
    id: 'job-announcement',
    name: 'Job Announcement',
    description: 'Share a new job opening with your network',
    category: 'announcement',
    goal: 'announce',
    tone: 'professional',
    content: `We're expanding our team at [Company Name] and looking for a talented [Job Title] to join us.

What you'll contribute:
• [Key responsibility 1]
• [Key responsibility 2]
• [Key responsibility 3]

What we're looking for:
• [Qualification 1]
• [Qualification 2]
• [Qualification 3]

This role offers [unique benefit/opportunity].

Interested? Comment below or DM me for application details.

#Hiring #[Industry] #Careers`
  },
  {
    id: 'achievement-share',
    name: 'Personal Achievement',
    description: 'Share a personal or professional milestone',
    category: 'professional',
    goal: 'inspire',
    tone: 'storytelling',
    content: `Thrilled to share that I've [achievement] after [time period] of dedicated work.

This milestone matters because [brief explanation of significance].

Key lessons from this journey:
1. [Lesson 1]
2. [Lesson 2]
3. [Lesson 3]

I'm especially grateful to [mentions] for their support and guidance.

What meaningful milestone are you working toward?

#ProfessionalGrowth #[Industry]`
  },
  {
    id: 'industry-insights',
    name: 'Industry Insights',
    description: 'Share your expertise on industry trends',
    category: 'thought-leadership',
    goal: 'educate',
    tone: 'thought_leader',
    content: `After analyzing recent developments in [industry], I've identified three pivotal trends that will shape our field in [timeframe]:

1. [Trend 1]
   Impact: [Brief explanation of business impact]

2. [Trend 2]
   Impact: [Brief explanation of business impact]

3. [Trend 3]
   Impact: [Brief explanation of business impact]

Organizations that [strategic action] will likely gain significant competitive advantage.

What emerging trends are you preparing for?

#IndustryInsights #[Industry] #Innovation`
  },
  {
    id: 'event-promotion',
    name: 'Event Promotion',
    description: 'Promote an upcoming event',
    category: 'event',
    goal: 'promote',
    tone: 'professional',
    content: `I'm pleased to invite you to [Event Name] on [Date] at [Time].

This [event type] will feature:
• [Speaker/Feature 1]
• [Speaker/Feature 2]
• [Speaker/Feature 3]

Key takeaways for attendees:
- [Benefit 1]
- [Benefit 2]

Registration: [Link]

Limited spots available. I hope to see many of you there.

#[EventHashtag] #[Industry] #ProfessionalDevelopment`
  },
  {
    id: 'career-advice',
    name: 'Career Advice',
    description: 'Share career tips and advice',
    category: 'career',
    goal: 'educate',
    tone: 'professional',
    content: `Throughout my [number] years in [industry/role], I've learned several principles that have consistently proven valuable:

1. [Strategic advice point 1]

2. [Strategic advice point 2]

3. [Strategic advice point 3]

The most transformative insight? [Key insight with brief explanation]

What career principle has served you best in your professional journey?

#CareerStrategy #ProfessionalGrowth #Leadership`
  },
  {
    id: 'case-study',
    name: 'Client Success Story',
    description: 'Share a brief case study of client results',
    category: 'professional',
    goal: 'promote',
    tone: 'professional',
    content: `Recently, we partnered with [Company/Client type] facing [specific challenge].

The situation:
• [Brief description of initial problem]
• [Limitation or constraint]
• [Stakes or importance]

Our approach:
1. [Strategy element 1]
2. [Strategy element 2]
3. [Strategy element 3]

Results:
• [Quantifiable result 1]
• [Quantifiable result 2]
• [Qualitative impact]

Key learning: [Insight that others can apply]

#CaseStudy #[Industry] #Results`
  },
  {
    id: 'industry-question',
    name: 'Thought-Provoking Question',
    description: 'Start a professional conversation',
    category: 'thought-leadership',
    goal: 'engage',
    tone: 'thought_leader',
    content: `I've been thinking about this question lately:

[Thought-provoking industry question]?

In my experience, [brief personal perspective].

Some considerations:
• [Factor/perspective 1]
• [Factor/perspective 2]
• [Factor/perspective 3]

I'm curious about your thoughts - especially from those working in [related roles/industries].

What's your perspective?

#[Industry] #ProfessionalDiscussion`
  },
  {
    id: 'market-analysis',
    name: 'Market Analysis',
    description: 'Share insights about market conditions',
    category: 'thought-leadership',
    goal: 'educate',
    tone: 'professional',
    content: `After analyzing the current state of [market segment], here are three important observations worth noting:

1. [Key market observation 1]
   Implications: [Brief analysis]

2. [Key market observation 2]
   Implications: [Brief analysis]

3. [Key market observation 3]
   Implications: [Brief analysis]

For professionals in this space, the opportunity lies in [strategic direction].

Are you seeing similar patterns in your market?

#MarketAnalysis #[Industry] #Strategy`
  },
  {
    id: 'team-recognition',
    name: 'Team Recognition',
    description: 'Highlight team achievements and culture',
    category: 'professional',
    goal: 'inspire',
    tone: 'professional',
    content: `I want to recognize our outstanding [team/department] for their exceptional work on [project/initiative].

What they accomplished:
• [Achievement 1]
• [Achievement 2]
• [Achievement 3]

What impressed me most was [specific quality or approach].

This exemplifies our commitment to [company value or priority].

Proud to work alongside such talented professionals at [Company Name].

#TeamExcellence #[Industry] #Leadership`
  },
  {
    id: 'professional-milestone',
    name: 'Company Milestone',
    description: 'Celebrate organizational achievements',
    category: 'announcement',
    goal: 'announce',
    tone: 'professional',
    content: `I'm pleased to share that [Company Name] has reached a significant milestone: [achievement].

This represents:
• [Years/quantity] of [effort/work]
• [Number] of [clients/products/projects]
• [Impact statistic or achievement]

This wouldn't be possible without our dedicated team and loyal [customers/clients/partners].

Looking ahead, we're focused on [future vision or goal].

Thank you to everyone who has been part of this journey.

#[Industry] #BusinessMilestone #Growth`
  }
];

export const getTemplatesByCategory = (category: Template['category']) => {
  return postTemplates.filter(template => template.category === category);
};

export const getTemplateById = (id: string) => {
  return postTemplates.find(template => template.id === id);
};