import { FC } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface GoalToneSelectorsProps {
  goal: string;
  tone: string;
  onGoalChange: (goal: string) => void;
  onToneChange: (tone: string) => void;
}

export const GoalToneSelectors: FC<GoalToneSelectorsProps> = ({ 
  goal, 
  tone, 
  onGoalChange, 
  onToneChange 
}) => {
  return (
    <>
      <div className="w-full sm:w-auto">
        <Select value={goal} onValueChange={onGoalChange}>
          <SelectTrigger className="w-full px-3 py-2 bg-[#0a66c2] border border-[#0a66c2] rounded-md text-sm hover:bg-[#084e96] [&_*]:text-white">
            <SelectValue placeholder="Select Goal" />
          </SelectTrigger>
          <SelectContent className="bg-white border border-[#0a66c2]">
            <SelectItem value="engage" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Engage</SelectItem>
            <SelectItem value="educate" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Educate</SelectItem>
            <SelectItem value="inspire" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Inspire</SelectItem>
            <SelectItem value="promote" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Promote</SelectItem>
            <SelectItem value="announce" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Announce</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="w-full sm:w-auto">
        <Select value={tone} onValueChange={onToneChange}>
          <SelectTrigger className="w-full px-3 py-2 bg-[#0a66c2] border border-[#0a66c2] rounded-md text-sm hover:bg-[#084e96] [&_*]:text-white">
            <SelectValue placeholder="Select Tone" />
          </SelectTrigger>
          <SelectContent className="bg-white border border-[#0a66c2]">
            <SelectItem value="professional" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Professional</SelectItem>
            <SelectItem value="friendly" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Friendly</SelectItem>
            <SelectItem value="casual" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Casual</SelectItem>
            <SelectItem value="storytelling" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Storytelling</SelectItem>
            <SelectItem value="thought_leader" className="text-[#0a66c2] hover:bg-[#f3f6f8]">Thought Leader</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </>
  );
};
