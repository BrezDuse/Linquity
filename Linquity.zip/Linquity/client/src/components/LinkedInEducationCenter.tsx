import React, { useState } from 'react';
import { Book, Award, Star, Video, BookOpen, ChevronRight, Bookmark, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';

interface LessonProps {
  title: string;
  description: string;
  tags: string[];
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  content: React.ReactNode;
}

const Lesson: React.FC<LessonProps> = ({ title, description, tags, duration, level, content }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const getLevelColor = (level: string) => {
    switch(level) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-blue-100 text-blue-800';
      case 'Advanced': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-semibold">{title}</CardTitle>
            <Badge className={getLevelColor(level)}>{level}</Badge>
          </div>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="flex flex-wrap gap-1 mb-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
          <div className="text-sm text-gray-500">
            <span className="flex items-center">
              <Book className="h-3 w-3 mr-1" />
              {duration} read
            </span>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            variant="outline" 
            className="w-full text-[#0a66c2] border-[#0a66c2] hover:bg-[#0a66c2] hover:text-white"
            onClick={() => setIsOpen(true)}
          >
            Read Lesson <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
          <DialogHeader className="bg-[#0a66c2] p-4 rounded-t-lg">
            <DialogTitle className="text-xl font-bold text-white">{title}</DialogTitle>
            <div className="flex items-center mt-1">
              <Badge className={`${getLevelColor(level)} mr-2`}>{level}</Badge>
              <span className="text-sm text-white opacity-90 flex items-center">
                <Book className="h-3 w-3 mr-1" />
                {duration} read
              </span>
            </div>
          </DialogHeader>
          
          <div className="p-4">
            {content}
            
            <div className="mt-6 flex justify-between">
              <Button 
                variant="outline" 
                className="text-gray-600"
                onClick={() => setIsOpen(false)}
              >
                Close
              </Button>
              <Button 
                className="bg-[#0a66c2] hover:bg-[#084e96] text-white"
                onClick={() => {
                  window.alert("Lesson saved to your bookmarks!");
                  setIsOpen(false);
                }}
              >
                <Bookmark className="mr-2 h-4 w-4" /> Save to Bookmarks
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

const LinkedInEducationCenter: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <>
      <div className="fixed bottom-4 left-4 z-50">
        <Button 
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-[#0a66c2] to-[#134e4a] hover:from-[#084e96] hover:to-[#0e3e3a] text-white shadow-lg"
        >
          <BookOpen className="mr-2 h-4 w-4" />
          Learning Center
        </Button>
      </div>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="bg-gradient-to-r from-[#0a66c2] to-[#134e4a] p-4 rounded-t-lg">
            <DialogTitle className="text-xl font-bold text-white">LinkedIn Content Academy</DialogTitle>
            <p className="text-sm text-white opacity-90">
              Master the art of professional content creation on LinkedIn
            </p>
          </DialogHeader>
          
          <Tabs defaultValue="lessons" className="w-full p-4">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="lessons">Lessons</TabsTrigger>
              <TabsTrigger value="practices">Best Practices</TabsTrigger>
              <TabsTrigger value="examples">Examples</TabsTrigger>
            </TabsList>
            
            <TabsContent value="lessons" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Lesson
                  title="Crafting Attention-Grabbing Hooks"
                  description="Learn how to write compelling opening lines that stop the scroll"
                  tags={['Engagement', 'Writing', 'Psychology']}
                  duration="5 min"
                  level="Beginner"
                  content={
                    <div className="space-y-4">
                      <p>The first 2-3 lines of your LinkedIn post are crucial - they determine whether someone will stop scrolling and read your content or continue past it.</p>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-4">5 Proven Hook Techniques:</h3>
                      
                      <div className="pl-4 border-l-2 border-[#0a66c2] my-4">
                        <h4 className="font-medium">1. The Curiosity Gap</h4>
                        <p className="text-sm text-gray-700 mb-2">Create a knowledge gap that readers want to fill by hinting at valuable information without revealing everything.</p>
                        <div className="bg-gray-50 p-2 rounded text-sm italic">
                          "I made a $10,000 mistake last week. Here's what I learned from it..."
                        </div>
                      </div>
                      
                      <div className="pl-4 border-l-2 border-[#0a66c2] my-4">
                        <h4 className="font-medium">2. The Contrarian View</h4>
                        <p className="text-sm text-gray-700 mb-2">Challenge conventional wisdom with a thoughtful counterpoint that makes people reconsider their assumptions.</p>
                        <div className="bg-gray-50 p-2 rounded text-sm italic">
                          "Most career advice says to follow your passion. I believe that's completely wrong."
                        </div>
                      </div>
                      
                      <div className="pl-4 border-l-2 border-[#0a66c2] my-4">
                        <h4 className="font-medium">3. The Startling Statistic</h4>
                        <p className="text-sm text-gray-700 mb-2">Lead with a surprising number or data point that challenges assumptions and demands attention.</p>
                        <div className="bg-gray-50 p-2 rounded text-sm italic">
                          "73% of hiring managers spend less than 10 seconds reviewing your resume. Here's how to make those seconds count..."
                        </div>
                      </div>
                      
                      <div className="pl-4 border-l-2 border-[#0a66c2] my-4">
                        <h4 className="font-medium">4. The Personal Story</h4>
                        <p className="text-sm text-gray-700 mb-2">Start with a vulnerable, authentic moment that creates an emotional connection.</p>
                        <div className="bg-gray-50 p-2 rounded text-sm italic">
                          "I was rejected from 47 jobs before landing my dream role at Google. The journey taught me these 5 lessons..."
                        </div>
                      </div>
                      
                      <div className="pl-4 border-l-2 border-[#0a66c2] my-4">
                        <h4 className="font-medium">5. The Direct Question</h4>
                        <p className="text-sm text-gray-700 mb-2">Ask a thought-provoking question that resonates with your audience's pain points or aspirations.</p>
                        <div className="bg-gray-50 p-2 rounded text-sm italic">
                          "Is your LinkedIn profile working for you while you sleep? Most aren't. Here's why..."
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-6">Implementation Tips:</h3>
                      <ul className="list-disc pl-5 space-y-2 text-sm">
                        <li>Keep your hook under 2-3 lines before it gets cut off in the feed</li>
                        <li>Make sure your hook aligns with the rest of your content</li>
                        <li>Test different hook styles to see what resonates with your audience</li>
                        <li>Avoid clickbait - deliver on the promise your hook makes</li>
                      </ul>
                    </div>
                  }
                />
                
                <Lesson
                  title="Writing LinkedIn Posts That Convert"
                  description="Structure your content for maximum engagement and business results"
                  tags={['Conversion', 'Marketing', 'Structure']}
                  duration="7 min"
                  level="Intermediate"
                  content={
                    <div className="space-y-4">
                      <p>A high-converting LinkedIn post needs more than just an attention-grabbing hook. It requires a strategic structure that guides readers toward your desired action.</p>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-4">The AIDA Framework for LinkedIn:</h3>
                      
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="attention">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            A - Attention
                          </AccordionTrigger>
                          <AccordionContent>
                            <p className="mb-2">Grab attention with a powerful hook using one of these techniques:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Share a surprising insight or statistic</li>
                              <li>Ask a thought-provoking question</li>
                              <li>Make a bold, contrarian statement</li>
                              <li>Start a relatable story with conflict</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="interest">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            I - Interest
                          </AccordionTrigger>
                          <AccordionContent>
                            <p className="mb-2">Build interest by establishing relevance to your audience:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Connect to a current industry trend or challenge</li>
                              <li>Share why this matters to their career or business</li>
                              <li>Hint at the value or insight they'll gain</li>
                              <li>Use "you" language to speak directly to the reader</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="desire">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            D - Desire
                          </AccordionTrigger>
                          <AccordionContent>
                            <p className="mb-2">Create desire by delivering valuable content:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Share specific, actionable insights</li>
                              <li>Use bullet points for easy scanning</li>
                              <li>Include personal examples or case studies</li>
                              <li>Address potential objections or concerns</li>
                              <li>Use the "text staircase" format for visual appeal</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="action">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            A - Action
                          </AccordionTrigger>
                          <AccordionContent>
                            <p className="mb-2">End with a clear, compelling call-to-action:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Ask a specific question to encourage comments</li>
                              <li>Invite them to share their experience or opinion</li>
                              <li>Direct them to a resource or next step</li>
                              <li>Keep it casual and conversational, not salesy</li>
                            </ul>
                            <div className="bg-gray-50 p-2 mt-2 rounded text-sm italic">
                              "What's one productivity hack that's saved you hours each week? Comment below and I'll compile the best ones into a free resource."
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-6">Content Formats That Convert:</h3>
                      <ul className="list-disc pl-5 space-y-2 text-sm">
                        <li><span className="font-medium">How-to guides:</span> Step-by-step actionable advice</li>
                        <li><span className="font-medium">Listicles:</span> Numbered lists of tips, resources, or mistakes to avoid</li>
                        <li><span className="font-medium">Case studies:</span> Real results with specific details and outcomes</li>
                        <li><span className="font-medium">Contrarian takes:</span> Challenge industry assumptions with evidence</li>
                        <li><span className="font-medium">Behind-the-scenes:</span> Authentic looks at your process or journey</li>
                      </ul>
                    </div>
                  }
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Lesson
                  title="Visual Storytelling on LinkedIn"
                  description="Using text formatting and visuals for maximum impact"
                  tags={['Design', 'Formatting', 'Visual']}
                  duration="6 min"
                  level="Intermediate"
                  content={
                    <div className="space-y-4">
                      <p>LinkedIn's algorithm favors text posts, but that doesn't mean they need to look boring. Strategic text formatting and visual elements can dramatically increase engagement.</p>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-4">Text Formatting Techniques:</h3>
                      
                      <div className="space-y-4">
                        <div className="border rounded-md p-3">
                          <h4 className="font-medium mb-2">1. Text Staircases</h4>
                          <p className="text-sm text-gray-700 mb-2">Creating a visual pattern with progressively longer or shorter lines:</p>
                          <div className="bg-gray-50 p-3 rounded">
                            <p>Start small.</p>
                            <p>Build your message gradually.</p>
                            <p>Add more details as you expand your thoughts.</p>
                            <p>Create a visual rhythm that guides readers through your content.</p>
                            <p>Then deliver your most important point as the culmination of your ideas.</p>
                          </div>
                        </div>
                        
                        <div className="border rounded-md p-3">
                          <h4 className="font-medium mb-2">2. Line Breaks & White Space</h4>
                          <p className="text-sm text-gray-700 mb-2">Using strategic spacing to improve readability:</p>
                          <div className="bg-gray-50 p-3 rounded">
                            <p>Long walls of text exhaust readers.</p>
                            <p>&nbsp;</p>
                            <p>Short paragraphs with plenty of white space are inviting.</p>
                            <p>&nbsp;</p>
                            <p>They create natural pauses.</p>
                            <p>&nbsp;</p>
                            <p>And make your content much easier to consume.</p>
                          </div>
                        </div>
                        
                        <div className="border rounded-md p-3">
                          <h4 className="font-medium mb-2">3. Emojis as Visual Anchors</h4>
                          <p className="text-sm text-gray-700 mb-2">Using emojis to create structure and highlight key points:</p>
                          <div className="bg-gray-50 p-3 rounded">
                            <p>🚀 Start with an attention-grabber</p>
                            <p>💡 Introduce your main insight</p>
                            <p>🔍 Explore details and evidence</p>
                            <p>⚠️ Address potential objections</p>
                            <p>✅ Conclude with your main takeaway</p>
                          </div>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-6">Visual Content Tips:</h3>
                      <ul className="list-disc pl-5 space-y-2 text-sm">
                        <li>Use high-contrast images that remain clear when scaled down in the feed</li>
                        <li>Include text overlays on images to clarify your message</li>
                        <li>Create custom graphics that visualize statistics or concepts</li>
                        <li>Use informal, authentic images rather than overly polished stock photos</li>
                        <li>Consider carousels for step-by-step guides or multi-point messages</li>
                        <li>Add alt text to images for accessibility and SEO benefits</li>
                      </ul>
                      
                      <div className="bg-blue-50 p-4 rounded-md border border-blue-100 mt-4">
                        <h4 className="font-medium text-blue-800 flex items-center">
                          <Star className="h-4 w-4 mr-2" /> Pro Tip
                        </h4>
                        <p className="text-sm text-blue-800 mt-1">
                          When using the text staircase format in Linquity, experiment with different patterns to see which best emphasizes your key message. The visual structure should reinforce your content's narrative flow.
                        </p>
                      </div>
                    </div>
                  }
                />
                
                <Lesson
                  title="Advanced LinkedIn Algorithm Strategies"
                  description="Optimize your content for maximum reach and engagement"
                  tags={['Algorithm', 'Strategy', 'Growth']}
                  duration="8 min"
                  level="Advanced"
                  content={
                    <div className="space-y-4">
                      <p>Understanding how the LinkedIn algorithm evaluates content can help you strategically craft posts that reach more people and generate higher engagement.</p>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-4">How the Algorithm Works:</h3>
                      
                      <div className="border rounded-md p-4 bg-gray-50">
                        <h4 className="font-medium mb-2">The Three Evaluation Phases</h4>
                        <ol className="space-y-3 text-sm">
                          <li>
                            <span className="font-medium">Initial Distribution:</span> LinkedIn shows your post to a small sample of your followers to gauge interest. High initial engagement signals quality content.
                          </li>
                          <li>
                            <span className="font-medium">Content Filtering:</span> LinkedIn evaluates your post against spam signals and quality indicators like formatting, hashtag use, and engagement types.
                          </li>
                          <li>
                            <span className="font-medium">Extended Reach:</span> If your post performs well in early phases, LinkedIn expands its distribution to your wider network and potentially beyond.
                          </li>
                        </ol>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-[#0a66c2] mt-6">Strategic Optimization Techniques:</h3>
                      
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="timing">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            Timing Strategies
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Post when your specific audience is most active (typically weekdays 8-10am or 4-6pm in their time zone)</li>
                              <li>Use LinkedIn Analytics to identify when your followers are online</li>
                              <li>Schedule for consistent posting rather than random bursts</li>
                              <li>Consider posting 1-2 hours before peak times to gain initial momentum</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="engagement">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            Engagement Acceleration
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Reply to every comment within the first hour of posting</li>
                              <li>Ask specific questions that prompt thoughtful responses</li>
                              <li>Tag only people who are genuinely relevant to the content</li>
                              <li>Leverage your internal network to kickstart engagement</li>
                              <li>Create "engagement pods" with colleagues for mutual support</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="hashtags">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            Hashtag Optimization
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Use 3-5 targeted hashtags maximum (not 20+ like on Instagram)</li>
                              <li>Mix hashtag sizes: 1 broad (1M+ followers), 2 medium (10k-500k), 1 niche (under 10k)</li>
                              <li>Create a branded hashtag for content series</li>
                              <li>Place hashtags at the end of your post, not throughout the text</li>
                              <li>Follow hashtags relevant to your content to understand what performs well</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                        
                        <AccordionItem value="content">
                          <AccordionTrigger className="font-medium text-[#0a66c2]">
                            Content Type Strategies
                          </AccordionTrigger>
                          <AccordionContent>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li>Text-only posts often receive wider distribution than image or link posts</li>
                              <li>If including links, place them in the first comment rather than the main post</li>
                              <li>Documents/PDFs typically receive more engagement than external links</li>
                              <li>LinkedIn Live videos receive 7x more reactions than standard video</li>
                              <li>Alternate between content types to reach different segments of your audience</li>
                            </ul>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                      
                      <div className="bg-blue-50 p-4 rounded-md border border-blue-100 mt-4">
                        <h4 className="font-medium text-blue-800 flex items-center">
                          <Star className="h-4 w-4 mr-2" /> Advanced Insight
                        </h4>
                        <p className="text-sm text-blue-800 mt-1">
                          LinkedIn's algorithm values "dwell time" - how long people spend reading your post. Format longer posts with line breaks and visual elements to increase readability and keep people engaged with your content longer.
                        </p>
                      </div>
                    </div>
                  }
                />
              </div>
            </TabsContent>
            
            <TabsContent value="practices" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Award className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    LinkedIn Content Best Practices
                  </CardTitle>
                  <CardDescription>
                    Research-backed guidelines for creating effective content
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="post-length">
                      <AccordionTrigger>
                        Optimal Post Length
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="list-disc pl-5 space-y-2 text-sm">
                          <li><span className="font-medium">Text posts:</span> 1,200-1,500 characters (approximately 200-250 words) performs best for engagement</li>
                          <li><span className="font-medium">Articles:</span> 1,500-2,000 words for comprehensive thought leadership</li>
                          <li><span className="font-medium">Video:</span> 30-90 seconds for native video content</li>
                          <li><span className="font-medium">Comments:</span> Substantive comments of 50+ words get more visibility</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="posting-frequency">
                      <AccordionTrigger>
                        Posting Frequency
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="list-disc pl-5 space-y-2 text-sm">
                          <li><span className="font-medium">Individuals:</span> 2-3 times per week is optimal for most professionals</li>
                          <li><span className="font-medium">Companies:</span> 5-7 times per week maintains presence without overwhelming</li>
                          <li><span className="font-medium">Thought leaders:</span> Daily posting can work if content quality remains high</li>
                          <li>Consistency matters more than volume - establish a sustainable rhythm</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="content-mix">
                      <AccordionTrigger>
                        Content Mix Formula
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="mb-3 text-sm">Follow the 3-2-1 rule for a balanced content strategy:</p>
                        <ul className="list-disc pl-5 space-y-2 text-sm">
                          <li><span className="font-medium">3 Educational posts:</span> Insights, tips, industry trends, how-to guides</li>
                          <li><span className="font-medium">2 Inspirational/Story posts:</span> Personal journeys, lessons learned, behind-the-scenes</li>
                          <li><span className="font-medium">1 Promotional post:</span> Services, products, or direct calls-to-action</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="engagement">
                      <AccordionTrigger>
                        Engagement Best Practices
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="list-disc pl-5 space-y-2 text-sm">
                          <li>Respond to all comments within 24 hours, ideally within the first hour</li>
                          <li>Ask specific, thought-provoking questions to spark discussion</li>
                          <li>Engage with others' content daily - comment on 5-10 relevant posts</li>
                          <li>Tag only 1-3 people maximum who are directly relevant</li>
                          <li>Engage with commenters by asking follow-up questions</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Edit3 className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    Writing Style Guidelines
                  </CardTitle>
                  <CardDescription>
                    Tone and voice recommendations for LinkedIn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex border-b pb-3">
                      <div className="w-1/2 pr-3">
                        <h3 className="text-sm font-medium text-green-600">Do This</h3>
                        <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                          <li>Write in first person using "I" or "we"</li>
                          <li>Use conversational, accessible language</li>
                          <li>Break complex concepts into simple terms</li>
                          <li>Share specific examples and details</li>
                          <li>Vary sentence length for rhythm</li>
                        </ul>
                      </div>
                      <div className="w-1/2 pl-3">
                        <h3 className="text-sm font-medium text-red-600">Avoid This</h3>
                        <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
                          <li>Corporate jargon and buzzwords</li>
                          <li>Overly formal or academic tone</li>
                          <li>Vague claims without evidence</li>
                          <li>Exclusively third-person perspective</li>
                          <li>Long, complex sentences</li>
                        </ul>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-2">Voice & Tone by Content Type</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="border rounded p-3">
                          <h4 className="text-xs font-semibold text-[#0a66c2]">THOUGHT LEADERSHIP</h4>
                          <p className="text-xs mt-1">Authoritative but accessible, confident without being arrogant, backed by experience and insights</p>
                        </div>
                        
                        <div className="border rounded p-3">
                          <h4 className="text-xs font-semibold text-[#0a66c2]">PERSONAL STORIES</h4>
                          <p className="text-xs mt-1">Authentic, vulnerable, conversational, emotionally resonant with clear lessons</p>
                        </div>
                        
                        <div className="border rounded p-3">
                          <h4 className="text-xs font-semibold text-[#0a66c2]">EDUCATIONAL CONTENT</h4>
                          <p className="text-xs mt-1">Clear, structured, practical, focused on actionable insights and valuable takeaways</p>
                        </div>
                        
                        <div className="border rounded p-3">
                          <h4 className="text-xs font-semibold text-[#0a66c2]">PROMOTIONAL CONTENT</h4>
                          <p className="text-xs mt-1">Value-focused, benefits-oriented, subtle, educational rather than pushy</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="examples" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Video className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    LinkedIn Content Examples by Category
                  </CardTitle>
                  <CardDescription>
                    Study these high-performing examples for inspiration
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="stories">
                    <TabsList className="grid grid-cols-3">
                      <TabsTrigger value="stories">Stories</TabsTrigger>
                      <TabsTrigger value="lists">List Posts</TabsTrigger>
                      <TabsTrigger value="thought">Thought Leadership</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="stories" className="mt-4">
                      <div className="border rounded-md p-4 bg-gray-50">
                        <div className="flex items-start mb-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <span className="text-[#0a66c2] font-bold">JD</span>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium">Jane Doe</h3>
                            <p className="text-xs text-gray-500">Product Manager at Tech Company</p>
                          </div>
                        </div>
                        
                        <div className="text-sm space-y-2">
                          <p>"I almost didn't apply for the job."</p>
                          <p>Scanning the requirements, I counted the ones I didn't meet:</p>
                          <p>• 7+ years experience (I had 4)</p>
                          <p>• MBA preferred (I had none)</p>
                          <p>• Prior management role (Nope)</p>
                          <p>• Experience with enterprise clients (Not really)</p>
                          <p>The voice in my head said "You're not qualified."</p>
                          <p>But I applied anyway.</p>
                          <p>Then came the interview process:</p>
                          <p>→ 6 interviews</p>
                          <p>→ 2 technical assessments</p>
                          <p>→ 1 presentation to executives</p>
                          <p>At each stage, I focused not on checking boxes but on demonstrating how I approach problems.</p>
                          <p>Yesterday marked my 3rd year at the company. I'm now leading our largest product initiative.</p>
                          <p>The lesson?</p>
                          <p>Job requirements are often a wishlist, not a checklist.</p>
                          <p>That job you're hesitating to apply for? Send your application.</p>
                          <p>If I hadn't, I wouldn't be where I am today.</p>
                          <p>Have you ever applied for a role you felt "underqualified" for? What happened?</p>
                        </div>
                        
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <span className="text-blue-500 mr-1">👍</span> 3,247
                          </div>
                          <div className="flex items-center mr-4">
                            <span className="mr-1">💬</span> 214 comments
                          </div>
                          <div className="flex items-center">
                            <span className="mr-1">↗️</span> 57 shares
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 space-y-2 text-sm">
                        <h3 className="font-medium">Why This Works:</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Strong opening hook that creates curiosity</li>
                          <li>Uses the text staircase format for visual appeal</li>
                          <li>Tells a relatable personal story with conflict and resolution</li>
                          <li>Includes specific details that build credibility</li>
                          <li>Delivers a clear, actionable takeaway</li>
                          <li>Ends with an engaging question to prompt comments</li>
                        </ul>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="lists" className="mt-4">
                      <div className="border rounded-md p-4 bg-gray-50">
                        <div className="flex items-start mb-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <span className="text-[#0a66c2] font-bold">MS</span>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium">Mark Smith</h3>
                            <p className="text-xs text-gray-500">Sales Director | B2B Strategy</p>
                          </div>
                        </div>
                        
                        <div className="text-sm space-y-2">
                          <p>5 sales email mistakes killing your response rates:</p>
                          <p>&nbsp;</p>
                          <p>1. Generic subject lines</p>
                          <p>• "Following up" or "Quick question" get ignored</p>
                          <p>• Instead: "Your Q2 revenue goals + our solution"</p>
                          <p>&nbsp;</p>
                          <p>2. Opening with "I hope this email finds you well"</p>
                          <p>• Everyone uses this - instant delete</p>
                          <p>• Instead: "I noticed your company just [specific observation]"</p>
                          <p>&nbsp;</p>
                          <p>3. Talking about your product features</p>
                          <p>• Nobody cares about your features</p>
                          <p>• Instead: "Our clients typically see [specific result]"</p>
                          <p>&nbsp;</p>
                          <p>4. Asking for a 30-minute call immediately</p>
                          <p>• Too big an ask for a cold outreach</p>
                          <p>• Instead: "Is this challenge relevant to your Q3 priorities?"</p>
                          <p>&nbsp;</p>
                          <p>5. Sending walls of text</p>
                          <p>• Busy executives won't read paragraphs</p>
                          <p>• Instead: 3-4 sentences max with white space</p>
                          <p>&nbsp;</p>
                          <p>I've seen response rates jump from 2% to 23% by fixing these issues.</p>
                          <p>&nbsp;</p>
                          <p>What's your biggest cold email challenge?</p>
                          <p>Comment below and I'll share specific advice.</p>
                        </div>
                        
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <span className="text-blue-500 mr-1">👍</span> 4,879
                          </div>
                          <div className="flex items-center mr-4">
                            <span className="mr-1">💬</span> 387 comments
                          </div>
                          <div className="flex items-center">
                            <span className="mr-1">↗️</span> 194 shares
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 space-y-2 text-sm">
                        <h3 className="font-medium">Why This Works:</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Clear, specific title that promises valuable insights</li>
                          <li>Structured format with numbered points for easy scanning</li>
                          <li>Each point includes both the problem and the solution</li>
                          <li>Uses bullet points and white space for readability</li>
                          <li>Includes specific evidence of results (2% to 23%)</li>
                          <li>Specific CTA asks for comments with promise of personalized advice</li>
                        </ul>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="thought" className="mt-4">
                      <div className="border rounded-md p-4 bg-gray-50">
                        <div className="flex items-start mb-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <span className="text-[#0a66c2] font-bold">AL</span>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium">Aisha Lee</h3>
                            <p className="text-xs text-gray-500">CMO | Digital Strategy | Speaker</p>
                          </div>
                        </div>
                        
                        <div className="text-sm space-y-2">
                          <p>The future of marketing isn't AI.</p>
                          <p>&nbsp;</p>
                          <p>It's humanity.</p>
                          <p>&nbsp;</p>
                          <p>Let me explain...</p>
                          <p>&nbsp;</p>
                          <p>As AI systems get better at creating content, we're seeing two diverging paths:</p>
                          <p>&nbsp;</p>
                          <p>Path 1: AI-generated marketing that's technically perfect but emotionally hollow.</p>
                          <p>&nbsp;</p>
                          <p>Path 2: Human-created marketing that's sometimes imperfect but deeply authentic.</p>
                          <p>&nbsp;</p>
                          <p>The brands that will win aren't choosing between these paths.</p>
                          <p>&nbsp;</p>
                          <p>They're creating a third path:</p>
                          <p>&nbsp;</p>
                          <p>Human-directed, AI-enhanced marketing that combines:</p>
                          <p>&nbsp;</p>
                          <p>• The efficiency and precision of AI</p>
                          <p>• The emotional intelligence and creativity of humans</p>
                          <p>&nbsp;</p>
                          <p>I'm seeing this with our clients:</p>
                          <p>&nbsp;</p>
                          <p>→ One used AI to analyze thousands of customer service conversations, identifying patterns humans missed</p>
                          <p>&nbsp;</p>
                          <p>→ But it was their human team that turned those insights into a campaign that increased engagement by 47%</p>
                          <p>&nbsp;</p>
                          <p>→ The AI found the signals. The humans created the meaning.</p>
                          <p>&nbsp;</p>
                          <p>As marketers, our value isn't in production tasks that AI can automate.</p>
                          <p>&nbsp;</p>
                          <p>It's in our uniquely human abilities:</p>
                          <p>&nbsp;</p>
                          <p>• Emotional connection</p>
                          <p>• Cultural awareness</p>
                          <p>• Ethical judgment</p>
                          <p>• Creative intuition</p>
                          <p>&nbsp;</p>
                          <p>The brands that thrive won't be the ones using the most advanced AI.</p>
                          <p>&nbsp;</p>
                          <p>They'll be the ones using AI to amplify their humanity.</p>
                          <p>&nbsp;</p>
                          <p>What do you think? How are you finding the balance between AI efficiency and human creativity in your marketing?</p>
                        </div>
                        
                        <div className="mt-4 flex items-center text-sm text-gray-500">
                          <div className="flex items-center mr-4">
                            <span className="text-blue-500 mr-1">👍</span> 6,154
                          </div>
                          <div className="flex items-center mr-4">
                            <span className="mr-1">💬</span> 428 comments
                          </div>
                          <div className="flex items-center">
                            <span className="mr-1">↗️</span> 276 shares
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 space-y-2 text-sm">
                        <h3 className="font-medium">Why This Works:</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Opens with a contrarian statement that challenges assumptions</li>
                          <li>Uses very short paragraphs and abundant white space for emphasis</li>
                          <li>Creates a framework (Path 1/Path 2/Third path) that makes the concept memorable</li>
                          <li>Includes specific example with measurable results (47% increase)</li>
                          <li>Offers both philosophical insight and practical application</li>
                          <li>Positions the author as a forward-thinking thought leader</li>
                        </ul>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default LinkedInEducationCenter;