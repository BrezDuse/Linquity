import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, CheckCircle, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EmailVerificationCardProps {
  email: string;
  isVerified: boolean;
  onSendVerification?: () => Promise<void>;
  onCheckVerification?: () => Promise<void>;
}

export const EmailVerificationCard: React.FC<EmailVerificationCardProps> = ({
  email,
  isVerified,
  onSendVerification,
  onCheckVerification
}) => {
  const { toast } = useToast();
  const [isChecking, setIsChecking] = React.useState(false);
  const [isSending, setIsSending] = React.useState(false);

  const handleSendVerification = async () => {
    if (!onSendVerification) return;
    
    setIsSending(true);
    try {
      await onSendVerification();
      toast({
        title: "Verification email sent",
        description: `We've sent a verification email to ${email}`,
      });
    } catch (error) {
      toast({
        title: "Failed to send verification email",
        description: "Please try again later or contact support",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleCheckVerification = async () => {
    if (!onCheckVerification) return;
    
    setIsChecking(true);
    try {
      await onCheckVerification();
      if (!isVerified) {
        toast({
          title: "Email not yet verified",
          description: "Please check your inbox and click the verification link",
        });
      }
    } catch (error) {
      toast({
        title: "Verification check failed",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-2">
      <CardHeader className={`${isVerified ? 'bg-green-50' : 'bg-amber-50'} rounded-t-lg`}>
        <CardTitle className="flex items-center gap-2 text-xl">
          {isVerified ? (
            <>
              <CheckCircle className="h-6 w-6 text-green-600" />
              <span>Email Verified</span>
            </>
          ) : (
            <>
              <AlertTriangle className="h-6 w-6 text-amber-600" />
              <span>Verification Required</span>
            </>
          )}
        </CardTitle>
        <CardDescription>
          {isVerified 
            ? "Your email has been verified. You have full access to all features."
            : "Please verify your email to unlock all premium features."}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6 pb-2">
        <div className="flex items-start gap-4">
          <div className="bg-blue-100 p-2 rounded-full">
            <Mail className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-medium text-gray-900">Your email address</h3>
            <p className="text-sm text-gray-500 mt-1">{email}</p>
            {!isVerified && (
              <p className="text-sm mt-2 text-gray-700">
                Check your inbox for a verification link. If you don't see it, check your spam folder or request a new link below.
              </p>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2 pt-2">
        {!isVerified && onSendVerification && (
          <Button 
            variant="outline" 
            onClick={handleSendVerification}
            disabled={isSending}
            className="w-full sm:w-auto"
          >
            {isSending ? "Sending..." : "Resend Verification Email"}
          </Button>
        )}
        {!isVerified && onCheckVerification && (
          <Button 
            onClick={handleCheckVerification}
            disabled={isChecking}
            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700"
          >
            {isChecking ? "Checking..." : "Check Verification Status"}
          </Button>
        )}
        {isVerified && (
          <p className="text-sm text-green-600 font-medium">
            ✓ Your email is verified and your account is active
          </p>
        )}
      </CardFooter>
    </Card>
  );
};