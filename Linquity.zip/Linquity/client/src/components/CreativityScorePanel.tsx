import { FC, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Trophy,
  Lightbulb,
  BookText,
  Palette,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { CreativityScore } from '@/lib/creativityScoring';

interface CreativityScorePanelProps {
  score: CreativityScore;
}

const CreativityScorePanel: FC<CreativityScorePanelProps> = ({ score }) => {
  const [activeTab, setActiveTab] = useState('overview');

  // Determine background color based on score
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  // Determine level color and icon
  const getLevelDetails = (level: CreativityScore['level']) => {
    switch(level) {
      case 'Master':
        return { color: 'text-purple-600', icon: <Trophy className="w-5 h-5" /> };
      case 'Expert':
        return { color: 'text-blue-600', icon: <Sparkles className="w-5 h-5" /> };
      case 'Professional':
        return { color: 'text-green-600', icon: <BookText className="w-5 h-5" /> };
      case 'Apprentice':
        return { color: 'text-yellow-600', icon: <Palette className="w-5 h-5" /> };
      default:
        return { color: 'text-gray-600', icon: <Lightbulb className="w-5 h-5" /> };
    }
  };

  const levelDetails = getLevelDetails(score.level);

  return (
    <Card className="mt-6 bg-white rounded-lg shadow-sm border-[#e0e6eb]">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-[#134e4a]">Creativity Score</h2>
          <div className="flex items-center">
            <span className={`${levelDetails.color} flex items-center font-semibold`}>
              {levelDetails.icon}
              <span className="ml-2">{score.level}</span>
            </span>
          </div>
        </div>

        {/* Main score display */}
        <div className="mb-6 relative pt-2">
          <div className="flex justify-between items-end mb-1">
            <span className="text-sm text-gray-500">Creativity</span>
            <span className="text-2xl font-bold text-[#0a66c2]">{score.total}/100</span>
          </div>
          <Progress 
            value={score.total} 
            max={100}
            className={`h-4 ${getScoreColor(score.total)} rounded-full transition-all duration-500 ease-in-out`}
          />
        </div>

        {/* Badges section */}
        {score.badges.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Achievements</h3>
            <div className="flex flex-wrap gap-2">
              {score.badges.map((badge, index) => (
                <Badge 
                  key={index}
                  variant="secondary"
                  className="bg-gradient-to-r from-[#134e4a] to-[#0a66c2] text-white"
                >
                  {badge}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        <Tabs defaultValue="overview" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="tips">Improvement Tips</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-gray-50 p-3">
                <div className="text-sm text-gray-500 mb-1">Top Strength</div>
                <div className="font-semibold">
                  {Object.entries({
                    'Vocabulary': score.vocabulary,
                    'Engagement': score.engagement,
                    'Originality': score.originality,
                    'Storytelling': score.storytelling,
                    'Visual Language': score.visualLanguage
                  }).sort((a, b) => b[1] - a[1])[0][0]}
                </div>
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <div className="text-sm text-gray-500 mb-1">Needs Improvement</div>
                <div className="font-semibold">
                  {Object.entries({
                    'Vocabulary': score.vocabulary,
                    'Engagement': score.engagement,
                    'Originality': score.originality,
                    'Storytelling': score.storytelling,
                    'Visual Language': score.visualLanguage
                  }).sort((a, b) => a[1] - b[1])[0][0]}
                </div>
              </div>
            </div>
            <div className="rounded-lg bg-blue-50 p-4 border border-blue-100">
              <div className="font-semibold text-blue-700 mb-1 flex items-center">
                <Sparkles className="w-4 h-4 mr-2" />
                Creativity Insight
              </div>
              <p className="text-sm text-gray-700">
                {score.feedback[0] || "Add more content to get personalized creativity insights."}
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="details" className="space-y-4">
            <div className="space-y-3">
              {/* Individual category scores */}
              <CategoryScore 
                name="Vocabulary" 
                score={score.vocabulary} 
                icon={<BookText className="w-4 h-4" />}
                description="Word choice diversity and complexity"
              />
              <CategoryScore 
                name="Engagement" 
                score={score.engagement} 
                icon={<MessageSquare className="w-4 h-4" />}
                description="Techniques that invite reader interaction"
              />
              <CategoryScore 
                name="Originality" 
                score={score.originality} 
                icon={<Lightbulb className="w-4 h-4" />}
                description="Unique ideas and fresh perspectives"
              />
              <CategoryScore 
                name="Storytelling" 
                score={score.storytelling} 
                icon={<BookText className="w-4 h-4" />}
                description="Narrative elements and structure"
              />
              <CategoryScore 
                name="Visual Language" 
                score={score.visualLanguage} 
                icon={<Palette className="w-4 h-4" />}
                description="Descriptive imagery and sensory details"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="tips">
            <div className="space-y-4">
              {score.feedback.length > 0 ? (
                score.feedback.map((tip, index) => (
                  <div key={index} className="flex items-start">
                    <div className="mt-1 mr-3 text-[#0a66c2]">
                      <Lightbulb className="w-5 h-5" />
                    </div>
                    <p className="text-sm text-gray-700">{tip}</p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 italic">
                  Add more content to receive specific improvement tips.
                </p>
              )}
              
              {/* General tips */}
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="font-medium text-sm text-gray-700 mb-2">General Improvement Tips</h4>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <div className="mt-1 mr-3 text-green-600">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <p className="text-sm text-gray-700">
                      Use storytelling techniques to make your content more relatable and memorable.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <div className="mt-1 mr-3 text-green-600">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <p className="text-sm text-gray-700">
                      Replace common LinkedIn phrases with unique expressions that reflect your voice.
                    </p>
                  </div>
                  <div className="flex items-start">
                    <div className="mt-1 mr-3 text-green-600">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <p className="text-sm text-gray-700">
                      Incorporate questions or calls to action to boost engagement with your audience.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

// Helper component for category scores
interface CategoryScoreProps {
  name: string;
  score: number;
  icon: React.ReactNode;
  description: string;
}

const CategoryScore: FC<CategoryScoreProps> = ({ name, score, icon, description }) => {
  // Calculate percentage for the score (0-20 scale)
  const percentage = (score / 20) * 100;
  
  // Determine color based on score
  const getColor = (score: number) => {
    if (score >= 16) return 'text-green-600';
    if (score >= 12) return 'text-blue-600';
    if (score >= 8) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  return (
    <div className="relative">
      <div className="flex justify-between items-center mb-1">
        <div className="flex items-center">
          <span className="mr-2 text-gray-500">{icon}</span>
          <span className="text-sm font-medium">{name}</span>
        </div>
        <span className={`text-sm font-semibold ${getColor(score)}`}>{score}/20</span>
      </div>
      <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
        <div 
          className="h-full rounded-full transition-all duration-500 ease-in-out"
          style={{ 
            width: `${percentage}%`,
            background: score >= 16 ? 'linear-gradient(to right, #10b981, #059669)' :
                      score >= 12 ? 'linear-gradient(to right, #3b82f6, #2563eb)' :
                      score >= 8 ? 'linear-gradient(to right, #f59e0b, #d97706)' :
                      'linear-gradient(to right, #ef4444, #dc2626)'
          }}
        ></div>
      </div>
      <p className="text-xs text-gray-500 mt-1">{description}</p>
    </div>
  );
};

export default CreativityScorePanel;