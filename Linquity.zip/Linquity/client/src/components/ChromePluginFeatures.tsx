import React, { useState } from 'react';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from '@/components/ui/button';

interface FeatureCategory {
  title: string;
  icon: React.ReactNode;
  features: string[];
}

const ChromePluginFeatures: React.FC = () => {
  const [showAll, setShowAll] = useState(false);
  
  const featureCategories: FeatureCategory[] = [
    {
      title: "Direct LinkedIn Integration",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
          <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
          <rect x="2" y="9" width="4" height="12"></rect>
          <circle cx="4" cy="4" r="2"></circle>
        </svg>
      ),
      features: [
        "Context-aware post creation with direct LinkedIn integration",
        "Profile section detection for targeted optimization",
        "Comment enhancement with right-click optimization"
      ]
    },
    {
      title: "Content Analysis",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600">
          <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
          <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
        </svg>
      ),
      features: [
        "Competitor analysis for content strategy suggestions",
        "Audience insights based on follower demographics",
        "Engagement prediction before posting",
        "SEO/Keyword highlighting for visibility"
      ]
    },
    {
      title: "Workflow Enhancements",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="9" y1="3" x2="9" y2="21"></line>
        </svg>
      ),
      features: [
        "One-click publishing directly to LinkedIn",
        "Smart scheduling based on follower activity",
        "Content calendar accessible from browser toolbar",
        "Draft synchronization between web app and extension"
      ]
    }
  ];
  
  const additionalCategories: FeatureCategory[] = [
    {
      title: "AI & Personalization",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
          <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
          <line x1="12" y1="22.08" x2="12" y2="12"></line>
        </svg>
      ),
      features: [
        "Personalized templates based on writing style",
        "Voice matching to maintain consistent tone",
        "Multi-language support for global reach",
        "Image suggestions to complement text content"
      ]
    },
    {
      title: "Analytics & Learning",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600">
          <path d="M3 3v18h18"></path>
          <path d="M18.4 8.42a4 4 0 1 0-7.5 2.16L18.42 18"></path>
          <path d="M8 18l4-4"></path>
        </svg>
      ),
      features: [
        "Performance tracking directly in the extension",
        "A/B testing to optimize content performance",
        "Learning dashboard with personalized insights",
        "Competitor benchmarking against industry standards"
      ]
    },
    {
      title: "User Experience",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-cyan-600">
          <path d="M17 18a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v9z"></path>
          <path d="M15 2v5"></path>
          <path d="M9 2v5"></path>
          <path d="M3 10h18"></path>
        </svg>
      ),
      features: [
        "Minimalist mode for distraction-free writing",
        "Dark mode that matches LinkedIn's theme",
        "Customizable UI for feature prioritization",
        "Interactive tutorials for new users",
        "Visual progress indicators for AI processing"
      ]
    }
  ];

  const allCategories = [...featureCategories, ...(showAll ? additionalCategories : [])];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 max-w-4xl mx-auto my-8">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Chrome Extension Coming Soon</h2>
        <p className="text-gray-600">
          We're building a powerful Chrome extension that seamlessly integrates with LinkedIn.
          Here's a preview of the upcoming features:
        </p>
      </div>

      <Accordion type="single" collapsible className="w-full">
        {allCategories.map((category, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center">
                <span className="mr-2">{category.icon}</span>
                <span className="font-medium">{category.title}</span>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <ul className="space-y-2 pl-9">
                {category.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="text-gray-700 flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 mr-2 mt-1 flex-shrink-0">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      {!showAll && (
        <div className="text-center mt-6">
          <Button
            variant="outline"
            onClick={() => setShowAll(true)}
            className="text-blue-600 border-blue-600 hover:bg-blue-50"
          >
            Show All Features
          </Button>
        </div>
      )}

      <div className="mt-8 pt-6 border-t border-gray-200">
        <div className="flex justify-end">
          <Button 
            variant="default" 
            className="bg-blue-600 hover:bg-blue-700"
          >
            Join Waitlist
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChromePluginFeatures;