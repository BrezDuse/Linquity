import { FC } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import HelpGuide from './HelpGuide';
import { Link } from 'wouter';

interface HeaderProps {
  onSaveDraft: () => Promise<void>;
}

const Header: FC<HeaderProps> = ({ onSaveDraft }) => {
  const { toast } = useToast();
  
  const handleSaveDraft = async () => {
    try {
      await onSaveDraft();
      toast({
        title: "Draft saved successfully",
        description: "Your post draft has been saved",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error saving draft",
        description: "There was an error saving your draft",
        variant: "destructive",
      });
    }
  };
  
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <i className="fas fa-feather-alt text-[#0a66c2] text-xl"></i>
          <h1 className="text-xl font-semibold text-[#0a66c2]">Linquity</h1>
        </div>
        <div className="flex items-center space-x-4">
          <Link href="/drafts">
            <Button 
              variant="default" 
              className="bg-[#134e4a] hover:bg-[#0a3533] text-white"
            >
              <i className="far fa-file-alt mr-2"></i> My Drafts
            </Button>
          </Link>
          <Button 
            variant="default" 
            className="bg-[#134e4a] hover:bg-[#0a3533] text-white" 
            onClick={handleSaveDraft}
          >
            <i className="far fa-save mr-2"></i> Save Draft
          </Button>
          <HelpGuide />
        </div>
      </div>
    </header>
  );
};

export default Header;
