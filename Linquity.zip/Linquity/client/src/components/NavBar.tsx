import React from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Home, 
  FileText, 
  LogIn, 
  UserPlus, 
  ChevronDown, 
  LogOut, 
  Mail,
  AlertCircle
} from 'lucide-react';

const NavBar: React.FC = () => {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex items-center">
          <Link href="/">
            <a className="flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                <rect x="2" y="9" width="4" height="12"></rect>
                <circle cx="4" cy="4" r="2"></circle>
              </svg>
            </a>
          </Link>
        </div>

        <nav className="flex items-center space-x-4 lg:space-x-6 mx-6">
          <Link href="/">
            <a className={`flex items-center text-sm font-medium transition-colors hover:text-primary ${location === '/' ? 'text-foreground' : 'text-muted-foreground'}`}>
              <Home className="h-4 w-4 mr-1" />
              Home
            </a>
          </Link>
          
          <Link href="/drafts">
            <a className={`flex items-center text-sm font-medium transition-colors hover:text-primary ${location === '/drafts' ? 'text-foreground' : 'text-muted-foreground'}`}>
              <FileText className="h-4 w-4 mr-1" />
              Drafts
            </a>
          </Link>
          
          <Link href="/chrome-plugin">
            <a className={`flex items-center text-sm font-medium transition-colors hover:text-primary ${location === '/chrome-plugin' ? 'text-foreground' : 'text-muted-foreground'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <circle cx="12" cy="12" r="10"></circle>
                <circle cx="12" cy="12" r="4"></circle>
                <line x1="21.17" y1="8" x2="12" y2="8"></line>
                <line x1="3.95" y1="6.06" x2="8.54" y2="14"></line>
                <line x1="10.88" y1="21.94" x2="15.46" y2="14"></line>
              </svg>
              Chrome Plugin
            </a>
          </Link>
        </nav>

        <div className="ml-auto flex items-center space-x-4">
          {!isAuthenticated ? (
            <>
              <Link href="/login">
                <Button variant="ghost" size="sm" className="gap-1">
                  <LogIn className="h-4 w-4" /> 
                  Sign in
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm" className="gap-1">
                  <UserPlus className="h-4 w-4" /> 
                  Sign up
                </Button>
              </Link>
            </>
          ) : (
            <>
              {!user?.isVerified && (
                <Link href="/verify-email">
                  <Button variant="outline" size="sm" className="gap-1 border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100">
                    <AlertCircle className="h-4 w-4" />
                    Verify Email
                  </Button>
                </Link>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1">
                    {user?.firstName || user?.email?.split('@')[0] || 'Account'}
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    <div className="flex flex-col">
                      <span>{user?.email}</span>
                      <span className="text-xs text-muted-foreground">
                        {user?.isVerified ? 
                          'Email verified' : 
                          'Email verification required'}
                      </span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  
                  {!user?.isVerified && (
                    <Link href="/verify-email">
                      <DropdownMenuItem className="cursor-pointer">
                        <Mail className="mr-2 h-4 w-4" />
                        <span>Verify Email</span>
                      </DropdownMenuItem>
                    </Link>
                  )}
                  
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default NavBar;