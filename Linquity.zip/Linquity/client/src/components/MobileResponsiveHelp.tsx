import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Smartphone, Laptop, Maximize2, PanelLeftClose, Zap } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

const MobileResponsiveHelp: React.FC = () => {
  const [open, setOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <>
      {isMobile && (
        <div className="fixed bottom-20 right-4 z-50">
          <Button 
            size="sm" 
            onClick={() => setOpen(true)}
            className="bg-[#0a66c2] hover:bg-[#084e96] text-white shadow-lg rounded-full h-12 w-12 p-0"
            aria-label="Mobile help"
          >
            <Smartphone className="h-5 w-5" />
          </Button>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="bg-[#0a66c2] p-4 rounded-t-lg">
            <DialogTitle className="text-xl font-bold text-white">Mobile Optimization Tips</DialogTitle>
            <p className="text-sm text-white opacity-90">
              Get the most out of Linquity on your mobile device
            </p>
          </DialogHeader>

          <Tabs defaultValue="interface" className="w-full p-4">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="interface">Interface</TabsTrigger>
              <TabsTrigger value="shortcuts">Shortcuts</TabsTrigger>
              <TabsTrigger value="tips">Tips</TabsTrigger>
            </TabsList>

            <TabsContent value="interface" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <PanelLeftClose className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    Collapse Panels
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Tap the arrow icons at the edges of panels to collapse them for more writing space.
                    Double-tap anywhere to expand the editor to full screen.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Maximize2 className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    Rotate for Better Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    For longer writing sessions, rotate your device to landscape mode for a more 
                    comfortable typing experience and better toolbar access.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="shortcuts" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    Mobile Gestures
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Swipe right on text to quickly format as a heading</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Double tap paragraph to see formatting options</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Long press to activate text selection with handles</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Two-finger pinch to zoom in/out of preview</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tips" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Laptop className="h-5 w-5 mr-2 text-[#0a66c2]" />
                    Productivity Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Use voice dictation on your keyboard for faster content creation</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Save drafts often when on mobile to prevent losing work</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Add Linquity to your home screen for quick access</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-semibold mr-2">•</span>
                      <span>Try the templates feature to quickly start high-quality posts</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Button
                className="w-full bg-[#0a66c2] hover:bg-[#084e96] text-white"
                onClick={() => setOpen(false)}
              >
                Got It
              </Button>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MobileResponsiveHelp;