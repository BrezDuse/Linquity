import React, { useState, useEffect } from 'react';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Progress 
} from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';
import { 
  SmilePlus, 
  Frown, 
  Meh, 
  Search, 
  TrendingUp, 
  AlertTriangle, 
  Award, 
  BarChart2, 
  Users, 
  Heart, 
  BrainCircuit, 
  Check, 
  HelpCircle, 
  Zap
} from 'lucide-react';

import { 
  analyzeSentiment, 
  SentimentResult 
} from '@/lib/sentimentAnalysis';
import { 
  analyzeSeo, 
  LinkedInSeoResult 
} from '@/lib/linkedinSeo';

interface AdvancedContentOptimizationProps {
  text: string;
  industry?: string;
  goal?: string;
}

const AdvancedContentOptimization: React.FC<AdvancedContentOptimizationProps> = ({ 
  text, 
  industry = 'general',
  goal = 'networking'
}) => {
  const [sentimentResult, setSentimentResult] = useState<SentimentResult | null>(null);
  const [seoResult, setSeoResult] = useState<LinkedInSeoResult | null>(null);
  const [activeTab, setActiveTab] = useState('sentiment');
  
  // Analyze content when text changes
  useEffect(() => {
    if (text) {
      setSentimentResult(analyzeSentiment(text));
      setSeoResult(analyzeSeo(text, industry));
    } else {
      setSentimentResult(null);
      setSeoResult(null);
    }
  }, [text, industry]);

  // Helper function to get emotion icon
  const getEmotionIcon = (emotion: string, size = 16) => {
    switch (emotion) {
      case 'optimism':
        return <TrendingUp size={size} className="text-green-500" />;
      case 'enthusiasm':
        return <Zap size={size} className="text-yellow-500" />;
      case 'empathy':
        return <Heart size={size} className="text-red-500" />;
      case 'confidence':
        return <Award size={size} className="text-blue-500" />;
      case 'caution':
        return <AlertTriangle size={size} className="text-orange-500" />;
      case 'urgency':
        return <HelpCircle size={size} className="text-purple-500" />;
      case 'professionalism':
        return <BrainCircuit size={size} className="text-gray-500" />;
      default:
        return <Check size={size} className="text-gray-500" />;
    }
  };
  
  // Helper function to get sentiment icon
  const getSentimentIcon = (tone: string) => {
    switch (tone) {
      case 'very positive':
      case 'positive':
        return <SmilePlus className="h-6 w-6 text-green-500" />;
      case 'negative':
      case 'very negative':
        return <Frown className="h-6 w-6 text-red-500" />;
      default:
        return <Meh className="h-6 w-6 text-gray-500" />;
    }
  };

  // Get color for SEO score
  const getSeoScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  // Get color for sentiment score
  const getSentimentScoreColor = (score: number) => {
    if (score >= 3) return 'bg-green-500';
    if (score >= 1) return 'bg-blue-500';
    if (score >= -1) return 'bg-gray-500';
    if (score >= -3) return 'bg-orange-500';
    return 'bg-red-500';
  };

  return (
    <Card className="mt-6 shadow-sm border-[#e0e6eb]">
      <CardHeader className="bg-gradient-to-r from-[#134e4a] to-[#0a66c2] text-white rounded-t-lg">
        <CardTitle className="text-lg font-semibold flex items-center">
          <BarChart2 className="mr-2 h-5 w-5" />
          Advanced Content Optimization
        </CardTitle>
        <CardDescription className="text-gray-100">
          Get insights to improve your LinkedIn content's emotional appeal and discoverability
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-0">
        <Tabs 
          defaultValue="sentiment" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid grid-cols-2 rounded-none p-0 h-12">
            <TabsTrigger 
              value="sentiment" 
              className={`rounded-none data-[state=active]:bg-white ${activeTab === 'sentiment' ? 'border-b-2 border-[#0a66c2]' : 'border-b border-gray-200'}`}
            >
              <div className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                Emotional Tone
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="seo" 
              className={`rounded-none data-[state=active]:bg-white ${activeTab === 'seo' ? 'border-b-2 border-[#0a66c2]' : 'border-b border-gray-200'}`}
            >
              <div className="flex items-center">
                <Search className="mr-2 h-4 w-4" />
                Discoverability
              </div>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="sentiment" className="p-4 pt-6">
            {sentimentResult ? (
              <div className="space-y-6">
                {/* Sentiment Overview */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {getSentimentIcon(sentimentResult.tone)}
                    <div className="ml-2">
                      <h3 className="font-medium">
                        {sentimentResult.tone.charAt(0).toUpperCase() + sentimentResult.tone.slice(1)} tone
                      </h3>
                      <p className="text-sm text-gray-500">
                        Emotional tone: {sentimentResult.emotionalTone}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={sentimentResult.score >= 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                      {sentimentResult.score >= 0 ? 'Positive' : 'Negative'} sentiment
                    </Badge>
                  </div>
                </div>
                
                {/* Sentiment Score */}
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Sentiment score</span>
                    <span className="font-medium">{sentimentResult.score}</span>
                  </div>
                  <Progress 
                    value={50 + (sentimentResult.score * 10)} 
                    max={100}
                    className={`h-2 ${getSentimentScoreColor(sentimentResult.score)}`}
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Negative</span>
                    <span>Neutral</span>
                    <span>Positive</span>
                  </div>
                </div>
                
                {/* Emotion Breakdown */}
                <div>
                  <h3 className="text-sm font-medium mb-3">Emotional Dimensions</h3>
                  
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={sentimentResult.dominantEmotions.map(emotion => ({
                        emotion,
                        value: sentimentResult.emotions?.[emotion] || 0
                      }))}
                      margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="emotion" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value, name, props) => [`${value}`, 'Intensity']}
                        labelFormatter={(label) => `${label.charAt(0).toUpperCase() + label.slice(1)}`}
                      />
                      <Bar dataKey="value" name="Intensity">
                        {sentimentResult.dominantEmotions.map((emotion, index) => {
                          const colors = ['#10b981', '#3b82f6', '#f97316', '#8b5cf6', '#ec4899', '#6b7280'];
                          return <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />;
                        })}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                {/* Suggestions */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Tone Recommendations</h3>
                  <div className="space-y-2">
                    {sentimentResult.suggestions.map((suggestion, index) => (
                      <div key={index} className="flex items-start">
                        <div className="mt-1 mr-2 text-[#0a66c2]">
                          <Zap className="h-4 w-4" />
                        </div>
                        <p className="text-sm text-gray-700">{suggestion}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Word Analysis */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="border rounded-md p-3">
                    <h3 className="text-sm font-medium mb-2 text-green-600 flex items-center">
                      <SmilePlus className="h-4 w-4 mr-1" /> Positive Language
                    </h3>
                    {sentimentResult.positive.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {sentimentResult.positive.slice(0, 10).map((word, index) => (
                          <Badge key={index} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            {word}
                          </Badge>
                        ))}
                        {sentimentResult.positive.length > 10 && (
                          <span className="text-xs text-gray-500">+{sentimentResult.positive.length - 10} more</span>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-500 italic">No positive terms detected</p>
                    )}
                  </div>
                  
                  <div className="border rounded-md p-3">
                    <h3 className="text-sm font-medium mb-2 text-red-600 flex items-center">
                      <Frown className="h-4 w-4 mr-1" /> Negative Language
                    </h3>
                    {sentimentResult.negative.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {sentimentResult.negative.slice(0, 10).map((word, index) => (
                          <Badge key={index} variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            {word}
                          </Badge>
                        ))}
                        {sentimentResult.negative.length > 10 && (
                          <span className="text-xs text-gray-500">+{sentimentResult.negative.length - 10} more</span>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-500 italic">No negative terms detected</p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 text-gray-500">
                <Users className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p>Enter content to analyze emotional tone</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="seo" className="p-4 pt-6">
            {seoResult ? (
              <div className="space-y-6">
                {/* SEO Score Overview */}
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium flex items-center">
                      <Search className="mr-2 h-4 w-4 text-[#0a66c2]" />
                      LinkedIn Discoverability Score
                    </h3>
                    <p className="text-sm text-gray-500">
                      SEO Level: {seoResult.seoLevel.charAt(0).toUpperCase() + seoResult.seoLevel.slice(1)}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-[#0a66c2]">
                      {seoResult.score}
                      <span className="text-sm text-gray-500">/100</span>
                    </div>
                  </div>
                </div>
                
                {/* SEO Score Progress */}
                <div className="space-y-1">
                  <Progress 
                    value={seoResult.score} 
                    max={100}
                    className={`h-3 ${getSeoScoreColor(seoResult.score)}`}
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Poor</span>
                    <span>Fair</span>
                    <span>Good</span>
                    <span>Excellent</span>
                  </div>
                </div>
                
                {/* Recommendations */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Discoverability Recommendations</h3>
                  <div className="space-y-2">
                    {seoResult.recommendations.map((recommendation, index) => (
                      <div key={index} className="flex items-start">
                        <div className="mt-1 mr-2 text-[#0a66c2]">
                          <TrendingUp className="h-4 w-4" />
                        </div>
                        <p className="text-sm text-gray-700">{recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Keyword Analysis */}
                <div>
                  <h3 className="text-sm font-medium mb-2">LinkedIn Keywords Found</h3>
                  {seoResult.keywordsFound.length > 0 ? (
                    <div className="flex flex-wrap gap-1 mb-4">
                      {seoResult.keywordsFound.map((item, index) => (
                        <Badge key={index} className="bg-blue-50 text-blue-700 border border-blue-200">
                          {item.keyword} ({item.count})
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic mb-4">No relevant industry keywords detected</p>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="border rounded-md p-3">
                      <h3 className="text-xs font-medium text-[#0a66c2] mb-2">Suggested Keywords</h3>
                      {seoResult.keywordSuggestions.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {seoResult.keywordSuggestions.map((keyword, index) => (
                            <Badge key={index} variant="outline" className="bg-gray-50">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-gray-500 italic">No additional suggestions</p>
                      )}
                    </div>
                    
                    <div className="border rounded-md p-3">
                      <h3 className="text-xs font-medium text-[#0a66c2] mb-2">Recommended Hashtags</h3>
                      {seoResult.hashtagRecommendations.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {seoResult.hashtagRecommendations.map((hashtag, index) => (
                            <Badge key={index} variant="outline" className="bg-gray-50">
                              {hashtag}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-gray-500 italic">No hashtag recommendations</p>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Strengths and Gaps */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="border rounded-md p-3">
                    <h3 className="text-sm font-medium text-green-600 flex items-center mb-2">
                      <Check className="h-4 w-4 mr-1" /> Content Strengths
                    </h3>
                    {seoResult.strongAreas.length > 0 ? (
                      <ul className="space-y-1">
                        {seoResult.strongAreas.map((strength, index) => (
                          <li key={index} className="text-sm flex items-start">
                            <Check className="h-3 w-3 mr-1 mt-1 text-green-500" />
                            <span>{strength}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-gray-500 italic">No strengths detected yet</p>
                    )}
                  </div>
                  
                  <div className="border rounded-md p-3">
                    <h3 className="text-sm font-medium text-orange-600 flex items-center mb-2">
                      <AlertTriangle className="h-4 w-4 mr-1" /> Content Gaps
                    </h3>
                    {seoResult.contentGaps.length > 0 ? (
                      <ul className="space-y-1">
                        {seoResult.contentGaps.map((gap, index) => (
                          <li key={index} className="text-sm flex items-start">
                            <AlertTriangle className="h-3 w-3 mr-1 mt-1 text-orange-500" />
                            <span>{gap}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-gray-500 italic">No significant gaps detected</p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 text-gray-500">
                <Search className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p>Enter content to analyze LinkedIn discoverability</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AdvancedContentOptimization;