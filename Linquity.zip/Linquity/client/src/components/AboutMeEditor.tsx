import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';

interface AboutMeEditorProps {
  onClose: () => void;
}

const AboutMeEditor: FC<AboutMeEditorProps> = ({ onClose }) => {
  const [aboutText, setAboutText] = useState<string>('');
  const [previewType, setPreviewType] = useState<string>('profile');
  const [previewDevice, setPreviewDevice] = useState<string>('mobile');
  const [expanded, setExpanded] = useState<boolean>(false);
  const [language, setLanguage] = useState<string>('english');

  // Calculate character count and limit for LinkedIn About section
  const maxChars = 2600; // LinkedIn's character limit
  const charCount = aboutText.length;
  const charPercentage = Math.min((charCount / maxChars) * 100, 100);
  
  // Helper to get a color based on character count
  const getCharCountColor = () => {
    if (charCount > maxChars) return 'text-red-500';
    if (charCount > maxChars * 0.9) return 'text-amber-500';
    return 'text-gray-500';
  };

  // Get truncated text for non-expanded view
  const getTruncatedText = () => {
    // For mobile truncate to about 2-3 lines or ~200 chars
    const mobileLimit = 210;
    // For desktop truncate to about 5 lines or ~400 chars
    const desktopLimit = 400;
    
    const limit = previewDevice === 'mobile' ? mobileLimit : desktopLimit;
    
    if (aboutText.length <= limit || expanded) {
      return aboutText;
    } else {
      return aboutText.slice(0, limit) + '...';
    }
  };

  // Structure tips based on the type
  const getTips = () => {
    if (previewType === 'profile') {
      return [
        "Start with a strong hook to encourage readers to click 'see more'",
        "Use first person pronouns (I, me, my) to build personal connection",
        "Tell your authentic story, including challenges and successes",
        "Include specific results and achievements with numbers",
        "End with a clear call-to-action for next steps"
      ];
    } else {
      return [
        "Begin with your company's mission or unique value proposition",
        "Describe what problems your company solves for customers",
        "Highlight key products/services and what makes them different",
        "Include company achievements, awards, or milestone statistics",
        "End with how interested parties can engage with your company"
      ];
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-semibold">LinkedIn About Me Editor</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <i className="fas fa-times"></i>
          </Button>
        </div>
        
        <div className="flex-1 overflow-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
            {/* Editor Side */}
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">Edit Your About Text</h3>
                <span className={`text-sm ${getCharCountColor()}`}>
                  {charCount}/{maxChars}
                </span>
              </div>
              
              <Textarea 
                placeholder={`Write your LinkedIn ${previewType === 'profile' ? 'About Me' : 'Page Description'} here...`}
                className="min-h-[400px] resize-none text-white bg-[#134e4a] placeholder:text-gray-300"
                value={aboutText}
                onChange={(e) => setAboutText(e.target.value)}
              />
              
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <h4 className="font-medium text-sm">Tips for a Great About Section</h4>
                <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
                  {getTips().map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Preview Side */}
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">Preview</h3>
                <div className="flex space-x-4">
                  <div className="flex items-center space-x-2">
                    <ToggleGroup type="single" value={previewType} onValueChange={(val) => val && setPreviewType(val)}>
                      <ToggleGroupItem value="profile">Profile</ToggleGroupItem>
                      <ToggleGroupItem value="page">Page</ToggleGroupItem>
                    </ToggleGroup>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <ToggleGroup type="single" value={previewDevice} onValueChange={(val) => val && setPreviewDevice(val)}>
                      <ToggleGroupItem value="mobile">
                        <i className="fas fa-mobile-alt mr-1"></i>
                      </ToggleGroupItem>
                      <ToggleGroupItem value="desktop">
                        <i className="fas fa-desktop mr-1"></i>
                      </ToggleGroupItem>
                    </ToggleGroup>
                  </div>
                </div>
              </div>
              
              <div className={`border rounded-lg overflow-hidden ${
                previewDevice === 'mobile' ? 'max-w-[375px] mx-auto' : 'w-full'
              }`}>
                {/* Mock LinkedIn Header */}
                <div className="bg-white p-3 border-b flex">
                  <div className="font-semibold text-sm text-gray-700">
                    {previewType === 'profile' ? 'About' : 'Page Description'}
                  </div>
                </div>
                
                {/* Preview Content */}
                <div className="bg-white p-4">
                  <div className="text-sm whitespace-pre-wrap">
                    {getTruncatedText()}
                  </div>
                  
                  {!expanded && aboutText.length > (previewDevice === 'mobile' ? 210 : 400) && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-800 hover:bg-transparent p-0 h-auto mt-2"
                      onClick={() => setExpanded(true)}
                    >
                      see more
                    </Button>
                  )}
                  
                  {expanded && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-800 hover:bg-transparent p-0 h-auto mt-2"
                      onClick={() => setExpanded(false)}
                    >
                      see less
                    </Button>
                  )}
                </div>
              </div>
              
              <div className="flex flex-col space-y-3">
                <div className="flex items-center justify-between bg-[#134e4a] bg-opacity-10 p-3 rounded-lg border border-[#134e4a] border-opacity-20">
                  <Label htmlFor="language" className="text-sm font-medium text-[#134e4a]">Language</Label>
                  <select 
                    id="language"
                    className="text-sm border border-[#0a66c2] rounded p-2 bg-white text-[#134e4a] font-medium cursor-pointer"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                  >
                    <option value="english">English</option>
                    <option value="spanish">Spanish</option>
                    <option value="french">French</option>
                    <option value="german">German</option>
                    <option value="dutch">Dutch</option>
                    <option value="polish">Polish</option>
                  </select>
                </div>
                
                <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                  <p className="text-sm text-blue-800">
                    <i className="fas fa-info-circle mr-1"></i>
                    LinkedIn {previewType === 'profile' ? 'profiles' : 'pages'} have a limit of {maxChars} characters for the About section.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t flex justify-end space-x-3">
          <Button 
            variant="default" 
            className="bg-[#134e4a] hover:bg-[#0a3533] text-white" 
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button 
            variant="default" 
            className="bg-[#134e4a] hover:bg-[#0a3533] text-white"
            onClick={() => {
              // Here you could integrate with the main app to:
              // - Export the text to the main editor 
              // - Save as a draft
              // - Copy to clipboard
              // For now we'll just close
              onClose();
            }}
          >
            Use in Post
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AboutMeEditor;