import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

const PromptDownloader: React.FC = () => {
  const downloadPrompt = () => {
    // Create anchor element
    const link = document.createElement('a');
    link.href = '/linquity-prompt.md';
    link.download = 'linquity-prompt.md';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        onClick={downloadPrompt}
        className="bg-gradient-to-r from-[#134e4a] to-[#0a66c2] hover:from-[#0a3e3a] hover:to-[#084e96] text-white shadow-lg"
      >
        <Download className="mr-2 h-4 w-4" />
        Download App Prompt
      </Button>
    </div>
  );
};

export default PromptDownloader;