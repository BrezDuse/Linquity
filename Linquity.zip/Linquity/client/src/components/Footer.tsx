import React from 'react';
import { Link } from 'wouter';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 py-8 border-t">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600 mr-2">
              <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
              <rect x="2" y="9" width="4" height="12"></rect>
              <circle cx="4" cy="4" r="2"></circle>
            </svg>
            <span className="font-bold text-lg">Linquity</span>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            AI-powered LinkedIn content editor
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex gap-6 mb-4 md:mb-0">
            <Link href="/">
              <a className="text-gray-600 hover:text-blue-600 text-sm">Home</a>
            </Link>
            <Link href="/drafts">
              <a className="text-gray-600 hover:text-blue-600 text-sm">Drafts</a>
            </Link>
            <Link href="#">
              <a className="text-gray-600 hover:text-blue-600 text-sm">Privacy Policy</a>
            </Link>
            <Link href="#">
              <a className="text-gray-600 hover:text-blue-600 text-sm">Terms of Service</a>
            </Link>
          </div>
          
          <p className="text-sm text-gray-500">
            © 2025 Linquity. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;