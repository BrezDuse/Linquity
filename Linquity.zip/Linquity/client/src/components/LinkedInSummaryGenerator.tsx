import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';

interface LinkedInSummaryGeneratorProps {
  initialSummary?: string;
  onGenerateSummary: (summary: string) => void;
}

const LinkedInSummaryGenerator: FC<LinkedInSummaryGeneratorProps> = ({ 
  initialSummary = '',
  onGenerateSummary
}) => {
  const [summaryType, setSummaryType] = useState<string>('professional');
  const [personalInfo, setPersonalInfo] = useState({
    role: '',
    experience: '',
    skills: '',
    achievements: '',
    personalNote: ''
  });
  const [generatedSummary, setGeneratedSummary] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [summaryLength, setSummaryLength] = useState<number>(600);
  const [tone, setTone] = useState<string>('professional');

  // Handle form input changes
  const handleInputChange = (field: string, value: string) => {
    setPersonalInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Generate a LinkedIn summary based on the inputs
  const handleGenerate = async () => {
    setIsGenerating(true);
    
    try {
      // Here we would connect to an AI service like OpenAI
      // For this example, we'll simulate it with a timeout
      
      setTimeout(() => {
        const summaries = {
          professional: `Results-driven ${personalInfo.role} with ${personalInfo.experience} of experience specializing in ${personalInfo.skills}. Known for ${personalInfo.achievements}. I help organizations achieve their goals through strategic implementation and a focus on outcomes. ${personalInfo.personalNote}`,
          creative: `Passionate ${personalInfo.role} bringing creativity and fresh perspectives to ${personalInfo.skills}. My journey includes ${personalInfo.experience} of transforming challenges into opportunities. Proud to have ${personalInfo.achievements}. ${personalInfo.personalNote}`,
          academic: `Dedicated ${personalInfo.role} with extensive background in ${personalInfo.skills}. ${personalInfo.experience} experience contributing to advancements in the field. Notable accomplishments include ${personalInfo.achievements}. ${personalInfo.personalNote}`,
          technical: `Technical ${personalInfo.role} specializing in ${personalInfo.skills} with ${personalInfo.experience} of hands-on experience. Successfully delivered ${personalInfo.achievements}. I approach problems with analytical thinking and innovative solutions. ${personalInfo.personalNote}`
        };
        
        // Get the summary based on the selected type
        const summary = summaries[summaryType] || summaries.professional;
        
        // Adjust length (this is simplified; in a real implementation, you'd use the API)
        const adjustedSummary = summary.substring(0, summaryLength);
        
        setGeneratedSummary(adjustedSummary);
        setIsGenerating(false);
      }, 1500);
    } catch (error) {
      console.error('Error generating summary:', error);
      setIsGenerating(false);
    }
  };

  // Apply the generated summary
  const handleApply = () => {
    onGenerateSummary(generatedSummary);
  };

  return (
    <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="p-4 border-b bg-[#134e4a] bg-opacity-10">
        <CardTitle className="text-lg font-medium text-[#134e4a] flex items-center">
          <span className="bg-[#0d9488] h-5 w-5 rounded-full mr-2"></span>
          LinkedIn Summary Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <Tabs defaultValue="input" className="space-y-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="input" className="data-[state=active]:bg-[#134e4a] data-[state=active]:text-white">
              <i className="fas fa-info-circle mr-2"></i>Details
            </TabsTrigger>
            <TabsTrigger value="customize" className="data-[state=active]:bg-[#134e4a] data-[state=active]:text-white">
              <i className="fas fa-sliders-h mr-2"></i>Customize
            </TabsTrigger>
            <TabsTrigger value="result" className="data-[state=active]:bg-[#134e4a] data-[state=active]:text-white">
              <i className="fas fa-file-alt mr-2"></i>Results
            </TabsTrigger>
          </TabsList>
          
          {/* Input Tab */}
          <TabsContent value="input" className="space-y-4">
            <div className="space-y-3">
              <div>
                <Label htmlFor="role" className="text-[#134e4a]">Current Role</Label>
                <Input 
                  id="role" 
                  placeholder="Product Manager, Software Engineer, Marketing Specialist..." 
                  value={personalInfo.role}
                  onChange={(e) => handleInputChange('role', e.target.value)}
                  className="border-gray-300 focus:border-[#0d9488] focus:ring-[#0d9488]"
                />
              </div>
              
              <div>
                <Label htmlFor="experience" className="text-[#134e4a]">Years of Experience</Label>
                <Input 
                  id="experience" 
                  placeholder="5+ years, a decade, etc." 
                  value={personalInfo.experience}
                  onChange={(e) => handleInputChange('experience', e.target.value)}
                  className="border-gray-300 focus:border-[#0d9488] focus:ring-[#0d9488]"
                />
              </div>
              
              <div>
                <Label htmlFor="skills" className="text-[#134e4a]">Key Skills</Label>
                <Input 
                  id="skills" 
                  placeholder="project management, data analysis, UX design..." 
                  value={personalInfo.skills}
                  onChange={(e) => handleInputChange('skills', e.target.value)}
                  className="border-gray-300 focus:border-[#0d9488] focus:ring-[#0d9488]"
                />
              </div>
              
              <div>
                <Label htmlFor="achievements" className="text-[#134e4a]">Notable Achievements</Label>
                <Textarea 
                  id="achievements" 
                  placeholder="Led a team that increased revenue by 30%, Launched 5 successful products..." 
                  value={personalInfo.achievements}
                  onChange={(e) => handleInputChange('achievements', e.target.value)}
                  className="border-gray-300 focus:border-[#0d9488] focus:ring-[#0d9488] min-h-[80px]"
                />
              </div>
              
              <div>
                <Label htmlFor="personalNote" className="text-[#134e4a]">Personal Touch</Label>
                <Textarea 
                  id="personalNote" 
                  placeholder="Outside of work, I enjoy reading, hiking, or mentoring young professionals..." 
                  value={personalInfo.personalNote}
                  onChange={(e) => handleInputChange('personalNote', e.target.value)}
                  className="border-gray-300 focus:border-[#0d9488] focus:ring-[#0d9488] min-h-[80px]"
                />
              </div>
            </div>
          </TabsContent>
          
          {/* Customize Tab */}
          <TabsContent value="customize" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="summaryType" className="text-[#134e4a]">Summary Type</Label>
                <Select value={summaryType} onValueChange={setSummaryType}>
                  <SelectTrigger id="summaryType" className="border-gray-300">
                    <SelectValue placeholder="Choose a summary type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional & Formal</SelectItem>
                    <SelectItem value="creative">Creative & Dynamic</SelectItem>
                    <SelectItem value="academic">Academic & Research</SelectItem>
                    <SelectItem value="technical">Technical & Analytical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="tone" className="text-[#134e4a]">Tone of Voice</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger id="tone" className="border-gray-300">
                    <SelectValue placeholder="Choose a tone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="conversational">Conversational</SelectItem>
                    <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                    <SelectItem value="authoritative">Authoritative</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-[#134e4a]">Summary Length ({summaryLength} characters)</Label>
                <Slider
                  defaultValue={[600]}
                  min={300}
                  max={2000}
                  step={100}
                  onValueChange={(value) => setSummaryLength(value[0])}
                  className="my-4"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Concise (300)</span>
                  <span>Recommended (600)</span>
                  <span>Detailed (2000)</span>
                </div>
              </div>
            </div>
          </TabsContent>
          
          {/* Result Tab */}
          <TabsContent value="result" className="space-y-4">
            {generatedSummary ? (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-md border border-gray-200 min-h-[200px]">
                  <p className="whitespace-pre-wrap">{generatedSummary}</p>
                </div>
                
                <div className="flex items-center justify-between">
                  <Button 
                    variant="outline" 
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="border-[#134e4a] text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                  >
                    <i className="fas fa-sync-alt mr-2"></i>
                    Regenerate
                  </Button>
                  
                  <Button 
                    onClick={handleApply}
                    className="bg-[#0d9488] hover:bg-[#134e4a]"
                  >
                    <i className="fas fa-check mr-2"></i>
                    Apply to Profile
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 space-y-4">
                <div className="rounded-full bg-[#134e4a] bg-opacity-10 h-20 w-20 flex items-center justify-center mx-auto">
                  <i className="fas fa-lightbulb text-[#0d9488] text-3xl"></i>
                </div>
                <h3 className="text-lg font-medium text-gray-700">No Summary Generated Yet</h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  Fill in your professional details in the "Details" tab, customize options, then click generate.
                </p>
                <Button 
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="mt-2 bg-[#0d9488] hover:bg-[#134e4a]"
                >
                  {isGenerating ? (
                    <><i className="fas fa-spinner fa-spin mr-2"></i>Generating...</>
                  ) : (
                    <><i className="fas fa-magic mr-2"></i>Generate Summary</>
                  )}
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default LinkedInSummaryGenerator;