import { FC, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface TextFormatterProps {
  text: string;
  onTextChange: (text: string) => void;
}

const TextFormatter: FC<TextFormatterProps> = ({ text, onTextChange }) => {
  const [activeTab, setActiveTab] = useState<string>('basic');
  const [selectedText, setSelectedText] = useState<{text: string, start: number, end: number} | null>(null);
  
  // Function to handle applying formatting to selected text
  const applyFormatting = (formatType: string, replacement?: string) => {
    // If there's no text, focus on content first
    if (!text) {
      return;
    }
    
    // Default to adding at the end if no selection
    let newText = text;
    
    switch (formatType) {
      case 'bold':
        if (selectedText) {
          // Apply to selected text
          newText = text.substring(0, selectedText.start) + 
                   `**${selectedText.text}**` + 
                   text.substring(selectedText.end);
        } else {
          // Add at current position with placeholder
          newText = text + "**Important text**";
        }
        break;
        
      case 'italic':
        if (selectedText) {
          newText = text.substring(0, selectedText.start) + 
                   `_${selectedText.text}_` + 
                   text.substring(selectedText.end);
        } else {
          newText = text + "_Emphasized text_";
        }
        break;
        
      case 'bullet-list':
        // Always add a new line before lists if not already there
        if (!text.endsWith('\n\n') && !text.endsWith('\n') && text.length > 0) {
          newText = text + '\n\n';
        } else if (!text.endsWith('\n') && text.length > 0) {
          newText = text + '\n';
        }
        newText += "• First point\n• Second point\n• Third point";
        break;
        
      case 'numbered-list':
        if (!text.endsWith('\n\n') && !text.endsWith('\n') && text.length > 0) {
          newText = text + '\n\n';
        } else if (!text.endsWith('\n') && text.length > 0) {
          newText = text + '\n';
        }
        newText += "1. First item\n2. Second item\n3. Third item";
        break;
        
      case 'emoji':
        newText = text + (replacement || '');
        break;
        
      case 'line-break':
        newText = text + '\n\n';
        break;
        
      case 'heading':
        if (!text.endsWith('\n') && text.length > 0) {
          newText = text + '\n';
        }
        newText += "# Heading Text";
        break;
        
      case 'blockquote':
        if (!text.endsWith('\n') && text.length > 0) {
          newText = text + '\n';
        }
        newText += "> Important quote or insight";
        break;
        
      case 'divider':
        if (!text.endsWith('\n\n') && !text.endsWith('\n') && text.length > 0) {
          newText = text + '\n\n';
        } else if (!text.endsWith('\n') && text.length > 0) {
          newText = text + '\n';
        }
        newText += "---\n";
        break;
        
      case 'hashtag':
        newText = text + (replacement ? ' ' + replacement : '');
        break;
    }
    
    onTextChange(newText);
  };
  
  // Function for reorganizing text
  const reorganizeText = (type: string) => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return; // Need at least 2 lines to sort
    
    let newLines: string[] = [];
    const linesByLength = [...lines].sort((a, b) => a.length - b.length);
    
    switch (type) {
      case 'shortest-to-longest':
        newLines = [...linesByLength];
        break;
        
      case 'longest-to-shortest':
        newLines = [...linesByLength].reverse();
        break;
        
      case 'short-long-pattern':
        newLines = [];
        for (let i = 0; i < lines.length; i++) {
          if (i % 2 === 0) {
            // For even positions, use shortest lines
            const index = Math.floor(i/2);
            if (index < linesByLength.length) {
              newLines.push(linesByLength[index]);
            }
          } else {
            // For odd positions, use longest lines
            const index = linesByLength.length - 1 - Math.floor(i/2);
            if (index >= 0) {
              newLines.push(linesByLength[index]);
            }
          }
        }
        break;
        
      case 'long-short-pattern':
        newLines = [];
        for (let i = 0; i < lines.length; i++) {
          if (i % 2 === 0) {
            // For even positions, use longest lines
            const index = linesByLength.length - 1 - Math.floor(i/2);
            if (index >= 0) {
              newLines.push(linesByLength[index]);
            }
          } else {
            // For odd positions, use shortest lines
            const index = Math.floor(i/2);
            if (index < linesByLength.length) {
              newLines.push(linesByLength[index]);
            }
          }
        }
        break;
    }
    
    onTextChange(newLines.join('\n'));
  };
  
  // Set up event listener for detecting selected text in the editor
  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection();
      if (selection && selection.toString().trim() !== '') {
        // Only track selections within our editor component
        // This would need actual DOM element reference logic in real implementation
        setSelectedText({
          text: selection.toString(),
          start: text.indexOf(selection.toString()),
          end: text.indexOf(selection.toString()) + selection.toString().length
        });
      } else {
        setSelectedText(null);
      }
    };
    
    document.addEventListener('selectionchange', handleSelectionChange);
    
    return () => {
      document.removeEventListener('selectionchange', handleSelectionChange);
    };
  }, [text]);

  return (
    <Card className="mb-4 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="p-3 pb-0 border-b bg-[#134e4a] bg-opacity-10">
        <CardTitle className="text-sm font-medium text-[#134e4a] flex items-center">
          <span className="bg-[#0d9488] h-4 w-4 rounded-full mr-2"></span>
          Format Text {selectedText ? `(${selectedText.text.substring(0, 15)}${selectedText.text.length > 15 ? '...' : ''} selected)` : ''}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <Tabs defaultValue="basic" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-3 bg-[#134e4a] bg-opacity-5">
            <TabsTrigger value="basic" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-text-height mr-2"></i>
              Basic Styling
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-layer-group mr-2"></i>
              Advanced
            </TabsTrigger>
            <TabsTrigger value="sort" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-sort mr-2"></i>
              Reorganize
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic" className="space-y-2">
            <div className="flex flex-wrap gap-2 justify-center">
              <div className="flex rounded-md overflow-hidden border border-gray-200 shadow-sm">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-9 px-3 rounded-none border-r hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                      onClick={() => applyFormatting('bold')}
                    >
                      <i className="fas fa-bold"></i>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Bold Text</TooltipContent>
                </Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-9 px-3 rounded-none border-r hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                      onClick={() => applyFormatting('italic')}
                    >
                      <i className="fas fa-italic"></i>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Italic Text</TooltipContent>
                </Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-9 px-3 rounded-none hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                      onClick={() => applyFormatting('line-break')}
                    >
                      <i className="fas fa-paragraph"></i>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Line Break</TooltipContent>
                </Tooltip>
              </div>
              
              <div className="flex rounded-md overflow-hidden border border-gray-200 shadow-sm">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-9 px-3 rounded-none border-r hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                      onClick={() => applyFormatting('bullet-list')}
                    >
                      <i className="fas fa-list-ul"></i>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Bullet List</TooltipContent>
                </Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-9 px-3 rounded-none hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                      onClick={() => applyFormatting('numbered-list')}
                    >
                      <i className="fas fa-list-ol"></i>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Numbered List</TooltipContent>
                </Tooltip>
              </div>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 px-3 border-gray-200 shadow-sm text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]"
                  >
                    <i className="far fa-smile mr-1"></i> Emoji
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-2 w-auto">
                  <div className="grid grid-cols-6 gap-2">
                    {['👍', '🔥', '💡', '✅', '⭐', '🚀', '💪', '🎯', '📊', '📈', '🙌', '👏'].map(emoji => (
                      <Button 
                        key={emoji} 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 w-9 p-0 hover:bg-[#134e4a] hover:bg-opacity-10" 
                        onClick={() => applyFormatting('emoji', emoji)}
                      >
                        {emoji}
                      </Button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            
            {selectedText && (
              <div className="mt-2 bg-[#134e4a] bg-opacity-5 rounded-md p-2 text-sm text-[#134e4a] flex items-center">
                <i className="fas fa-info-circle mr-2"></i>
                Text selected: Apply formatting directly to your selection!
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="advanced" className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 border-gray-200 shadow-sm text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                    onClick={() => applyFormatting('heading')}
                  >
                    <i className="fas fa-heading mr-2"></i>
                    <span>Heading</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add Heading Text</TooltipContent>
              </Tooltip>
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 border-gray-200 shadow-sm text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                    onClick={() => applyFormatting('blockquote')}
                  >
                    <i className="fas fa-quote-right mr-2"></i>
                    <span>Quote</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add Blockquote</TooltipContent>
              </Tooltip>
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 border-gray-200 shadow-sm text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                    onClick={() => applyFormatting('divider')}
                  >
                    <i className="fas fa-minus mr-2"></i>
                    <span>Divider</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add Horizontal Divider</TooltipContent>
              </Tooltip>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-9 border-gray-200 shadow-sm text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                  >
                    <i className="fas fa-hashtag mr-2"></i>
                    <span>Hashtags</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-2 w-auto">
                  <div className="grid grid-cols-1 gap-2">
                    {['#LinkedIn', '#CareerAdvice', '#Leadership', '#Networking', '#JobSearch', '#ProfessionalDevelopment'].map(hashtag => (
                      <Button 
                        key={hashtag} 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 justify-start hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#0d9488]" 
                        onClick={() => applyFormatting('hashtag', hashtag)}
                      >
                        {hashtag}
                      </Button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </TabsContent>
          
          <TabsContent value="sort" className="space-y-3">
            <div className="text-xs text-[#134e4a] flex items-center bg-[#134e4a] bg-opacity-5 p-2 rounded-md mb-2">
              <i className="fas fa-info-circle text-[#0d9488] mr-2 text-base"></i>
              Split your text into multiple lines first, then use these tools to reorganize them.
            </div>
          
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 border-gray-200 shadow-sm justify-start text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => reorganizeText('shortest-to-longest')}
              >
                <i className="fas fa-sort-amount-down-alt mr-2"></i>
                <span>Shortest to Longest</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 border-gray-200 shadow-sm justify-start text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => reorganizeText('longest-to-shortest')}
              >
                <i className="fas fa-sort-amount-down mr-2"></i>
                <span>Longest to Shortest</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 border-gray-200 shadow-sm justify-start text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => reorganizeText('short-long-pattern')}
              >
                <i className="fas fa-exchange-alt mr-2"></i>
                <span>Short-Long Pattern</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 border-gray-200 shadow-sm justify-start text-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => reorganizeText('long-short-pattern')}
              >
                <i className="fas fa-random mr-2"></i>
                <span>Long-Short Pattern</span>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="mt-3 pt-2 border-t border-gray-200 text-center">
          <p className="text-xs text-[#134e4a] italic">
            Pro tip: Select text first for targeted formatting
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TextFormatter;