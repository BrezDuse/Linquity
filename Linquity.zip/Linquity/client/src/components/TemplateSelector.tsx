import { FC, useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { postTemplates } from '@/data/postTemplates';

interface TemplateSelectorProps {
  onSelectTemplate: (content: string, goal: string, tone: string) => void;
}

const TemplateSelector: FC<TemplateSelectorProps> = ({ onSelectTemplate }) => {
  const [activeTab, setActiveTab] = useState<string>('professional');
  
  // Group templates by category
  const categories = [
    { id: 'professional', label: 'Professional' },
    { id: 'career', label: 'Career' },
    { id: 'thought-leadership', label: 'Thought Leadership' },
    { id: 'announcement', label: 'Announcements' },
    { id: 'event', label: 'Events' }
  ];
  
  const handleSelectTemplate = (content: string, goal: string, tone: string) => {
    onSelectTemplate(content, goal, tone);
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full mb-4">
          <i className="fas fa-book-open mr-2"></i> Template Library
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>LinkedIn Post Templates</DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="professional" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-5 mb-4 bg-[#0a66c2] p-1 rounded-lg">
            {categories.map((category) => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="text-white data-[state=active]:bg-white data-[state=active]:text-[#0a66c2] data-[state=active]:font-semibold"
              >
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {categories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                {postTemplates
                  .filter((template) => template.category === category.id)
                  .map((template) => (
                    <Card key={template.id} className="border-2 border-[#0a66c2] border-opacity-30 shadow-md">
                      <CardHeader className="bg-gradient-to-r from-[#0a66c2] to-[#0e76a8] text-white p-3">
                        <CardTitle className="text-white text-base">{template.name}</CardTitle>
                        <CardDescription className="text-white text-opacity-90 text-xs">{template.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm bg-white p-4 rounded-md max-h-[200px] overflow-y-auto border border-[#0a66c2] border-opacity-30 shadow-sm text-gray-800">
                          {template.content.split('\n').map((line, index) => {
                            // If line includes hashtags, make them blue
                            if (line.includes('#')) {
                              const parts = line.split(/(#\w+)/g);
                              return (
                                <p key={index} className={`${index !== 0 ? 'mt-2' : ''} ${index === 0 ? 'font-semibold text-base text-[#333333]' : 'text-[#555555]'}`}>
                                  {parts.map((part, i) => 
                                    part.startsWith('#') 
                                      ? <span key={i} className="text-[#0a66c2] font-medium">{part}</span> 
                                      : part
                                  )}
                                </p>
                              );
                            }
                            
                            // Check for emoji patterns
                            if (line.match(/[\p{Emoji}]/u)) {
                              return (
                                <p key={index} className={`${index !== 0 ? 'mt-2' : ''} ${index === 0 ? 'font-semibold text-base text-[#333333]' : 'text-[#555555]'}`}>
                                  {line}
                                </p>
                              );
                            }
                            
                            // Check for bullet points or numbered lists
                            if (line.match(/^[\s]*[•\-\*\d+\.]/)) {
                              return (
                                <p key={index} className="mt-1 ml-2 text-[#0a66c2] font-medium">
                                  {line}
                                </p>
                              );
                            }
                            
                            return (
                              <p key={index} className={`${index !== 0 ? 'mt-2' : ''} ${index === 0 ? 'font-semibold text-base text-[#333333]' : 'text-[#555555]'}`}>
                                {line}
                              </p>
                            );
                          })}
                        </div>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                            Goal: {template.goal}
                          </span>
                          <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">
                            Tone: {template.tone.replace('_', ' ')}
                          </span>
                        </div>
                      </CardContent>
                      <CardFooter className="bg-gray-50">
                        <DialogClose asChild>
                          <Button 
                            className="w-full bg-[#0a66c2] hover:bg-[#0e76a8] text-white" 
                            onClick={() => handleSelectTemplate(
                              template.content, 
                              template.goal, 
                              template.tone
                            )}
                          >
                            <i className="fas fa-check-circle mr-2"></i>
                            Use This Template
                          </Button>
                        </DialogClose>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
              
              {postTemplates.filter((template) => template.category === category.id).length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500">No templates available in this category yet.</p>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default TemplateSelector;