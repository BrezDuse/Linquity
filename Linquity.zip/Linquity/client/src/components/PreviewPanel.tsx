import { FC } from 'react';
import { Card } from '@/components/ui/card';
import { PreviewTips } from '@/types';
import { Button } from '@/components/ui/button';
import { LinkedInProfile } from '@/components/LinkedInProfileConnect';

interface PreviewPanelProps {
  formattedText: string;
  activePreview: 'mobile' | 'desktop';
  previewTips: PreviewTips;
  onPreviewChange: (view: 'mobile' | 'desktop') => void;
  linkedInProfile?: LinkedInProfile | null;
}

const PreviewPanel: FC<PreviewPanelProps> = ({ 
  formattedText, 
  activePreview, 
  previewTips, 
  onPreviewChange,
  linkedInProfile
}) => {
  const formatContentWithLineBreaks = (content: string) => {
    if (!content || content.trim() === '') {
      return <p className="text-gray-400 italic">Your LinkedIn post preview will appear here...</p>;
    }
    
    return content.split('\n').map((line, index) => {
      // If line includes hashtags, make them blue
      if (line.includes('#')) {
        const parts = line.split(/(#\w+)/g);
        return (
          <p key={index} className={`mb-2 leading-relaxed ${index === 0 ? 'text-lg' : ''}`}>
            {parts.map((part, i) => 
              part.startsWith('#') 
                ? <span key={i} className="text-[#0a66c2] font-semibold">{part}</span> 
                : part
            )}
          </p>
        );
      }
      
      return (
        <p key={index} className={`mb-2 leading-relaxed ${index === 0 ? 'text-lg' : ''}`}>
          {line}
        </p>
      );
    });
  };
  
  return (
    <Card className="bg-white rounded-lg shadow-sm">
      <div className="flex border-b">
        <Button
          variant="ghost"
          className={`px-6 py-3 flex-1 ${
            activePreview === 'mobile' 
              ? 'text-[#0a66c2] border-b-2 border-[#0a66c2] font-medium' 
              : 'text-gray-500 hover:text-white hover:bg-[#0a66c2]'
          }`}
          onClick={() => onPreviewChange('mobile')}
        >
          <i className="fas fa-mobile-alt mr-2"></i> Mobile Preview
        </Button>
        <Button
          variant="ghost"
          className={`px-6 py-3 flex-1 ${
            activePreview === 'desktop' 
              ? 'text-[#0a66c2] border-b-2 border-[#0a66c2] font-medium' 
              : 'text-gray-500 hover:text-white hover:bg-[#0a66c2]'
          }`}
          onClick={() => onPreviewChange('desktop')}
        >
          <i className="fas fa-desktop mr-2"></i> Desktop Preview
        </Button>
      </div>
      
      <div className="p-6">
        {/* Mobile/Desktop Preview Frame */}
        <div className={`mx-auto bg-[#f3f2ef] rounded-xl overflow-hidden border border-gray-300 ${
          activePreview === 'mobile' ? 'max-w-[320px]' : 'max-w-[600px]'
        }`}>
          {/* LinkedIn Header (Shows real profile if connected) */}
          <div className="bg-white p-3 border-b border-gray-300">
            <div className="flex items-center">
              {linkedInProfile ? (
                <>
                  <img 
                    src={linkedInProfile.profilePicture} 
                    alt={linkedInProfile.name}
                    className="w-10 h-10 rounded-full border border-gray-200 mr-2"
                  />
                  <div>
                    <div className="font-semibold text-sm">{linkedInProfile.name}</div>
                    <div className="text-xs text-gray-500 truncate max-w-[220px]">{linkedInProfile.headline}</div>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center mr-2">
                    <i className="fas fa-user text-gray-500"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-sm">Sarah Johnson</div>
                    <div className="text-xs text-gray-500">Founder & CEO at TechVentures</div>
                  </div>
                </>
              )}
            </div>
          </div>
          
          {/* Post Content */}
          <div className="bg-white p-4 shadow-sm">
            <div className="text-base font-medium text-gray-800">
              {formatContentWithLineBreaks(formattedText)}
            </div>

            {/* Image Attachment (if present) */}
            {linkedInProfile?.imageAttachment && (
              <div className="mt-3 border border-gray-200 rounded-md overflow-hidden">
                <img 
                  src={linkedInProfile.imageAttachment} 
                  alt="Attached image" 
                  className="w-full object-cover max-h-[300px]"
                />
              </div>
            )}
            
            {/* Mock Engagement Icons */}
            <div className="flex items-center justify-between mt-4 pt-3 border-t text-xs text-gray-500">
              <div className="flex items-center">
                <i className="fas fa-thumbs-up text-[#0a66c2] mr-1"></i>
                <span>24 reactions</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-comment mr-1"></i>
                <span>8 comments</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Preview Tips */}
        <div className="mt-6 text-sm text-gray-600 space-y-3">
          <div className="bg-green-50 border border-green-200 rounded-md p-3">
            <p className="font-medium text-[#057642]">Hook Strength: {previewTips.hookStrength}</p>
            <p>{previewTips.hookMessage}</p>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
            <p className="font-medium text-[#0a66c2]">Formatting Tips</p>
            <ul className="list-disc pl-5 space-y-1">
              {previewTips.formattingTips.map((tip, index) => (
                <li key={index}>{tip}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PreviewPanel;
