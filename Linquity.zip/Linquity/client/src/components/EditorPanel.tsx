import { FC, useState } from 'react';
import RichTextEditor from './RichTextEditor';
import ReadabilityPanel from './ReadabilityPanel';
import TemplateSelector from './TemplateSelector';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PostContent, ReadabilityFeedback } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

interface EditorPanelProps {
  content: PostContent;
  readability: ReadabilityFeedback;
  onContentChange: (content: Partial<PostContent>) => void;
  onEnhancePost: () => Promise<void>;
}

const EditorPanel: FC<EditorPanelProps> = ({ 
  content, 
  readability, 
  onContentChange, 
  onEnhancePost 
}) => {
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [scheduledDate, setScheduledDate] = useState<Date | null>(null);
  const [scheduledTime, setScheduledTime] = useState<string>('09:00');
  const [timeZone, setTimeZone] = useState<string>(Intl.DateTimeFormat().resolvedOptions().timeZone);
  const [scheduledPosts, setScheduledPosts] = useState<Array<{date: Date, content: string}>>([]);
  return (
    <Card className="bg-white rounded-lg shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-lg font-semibold mb-4 text-[#134e4a]">Create Your LinkedIn Post</h2>
        
        <TemplateSelector 
          onSelectTemplate={(rawText, goal, tone) => {
            onContentChange({ 
              rawText,
              goal,
              tone
            });
          }} 
        />
        


        <RichTextEditor 
          value={content.rawText}
          onChange={(rawText) => onContentChange({ rawText })}
          wordCount={readability.wordCount}
          readingTime={readability.readingTime}
        />
        
        {/* LinkedIn sharing options toolbar */}
        <div className="bg-[#f3f6f8] border border-[#e0e6eb] rounded-md p-2 mt-4 mb-4">
          <div className="flex justify-between items-center w-full">
            {/* Video Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="Add video"
              onClick={() => {
                alert("Video upload feature would open here.");
                // In a real implementation, we would open a video upload dialog
              }}
            >
              <i className="fas fa-play-circle text-lg sm:text-xl"></i>
            </button>
            
            {/* Photo Button */}
            <label className="cursor-pointer">
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    // In a real implementation, this would upload the image and return a URL
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      const imageUrl = event.target?.result as string;
                      onContentChange({ 
                        imageAttachment: imageUrl 
                      });
                      alert("Image attached successfully!");
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
              <span className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" title="Add photo">
                <i className="fas fa-image text-lg sm:text-xl"></i>
              </span>
            </label>
            
            {/* Event Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="Add event"
              onClick={() => {
                const eventText = `📅 Event: Professional Networking Mixer\nDate: ${new Date().toLocaleDateString()}\nTime: 6:00 PM - 8:00 PM\nLocation: Virtual via Zoom\n\nJoin us for an exciting opportunity to connect with industry professionals!`;
                onContentChange({ rawText: content.rawText + '\n\n' + eventText });
                alert("Event details added to your post!");
              }}
            >
              <i className="fas fa-calendar-alt text-lg sm:text-xl"></i>
            </button>
            
            {/* Celebrate Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="Celebrate an occasion"
              onClick={() => {
                const celebrations = [
                  "🎉 I'm thrilled to announce that I've reached a major milestone in my career!",
                  "🎊 We're celebrating our company's anniversary today!",
                  "🥂 Excited to share that our team has achieved record-breaking results this quarter!",
                  "🎯 After months of hard work, I'm proud to announce that we've successfully launched our new product!"
                ];
                const celebration = celebrations[Math.floor(Math.random() * celebrations.length)];
                onContentChange({ rawText: content.rawText + '\n\n' + celebration });
                alert("Celebration text added to your post!");
              }}
            >
              <i className="fas fa-gift text-lg sm:text-xl"></i>
            </button>
            
            {/* Document Button */}
            <label className="cursor-pointer">
              <input 
                type="file" 
                accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx" 
                className="hidden" 
                onChange={() => {
                  alert("Document upload feature would process the file here.");
                  // In a real implementation, this would handle document upload
                }}
              />
              <span className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" title="Add a document">
                <i className="fas fa-briefcase text-lg sm:text-xl"></i>
              </span>
            </label>
            
            {/* Poll Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="Create a poll"
              onClick={() => {
                const pollTemplate = "📊 Poll: What skill is most important for professionals in 2025?\n\n- AI & Machine Learning\n- Communication & Leadership\n- Industry-specific expertise\n- Adaptability & Learning";
                onContentChange({ rawText: content.rawText + '\n\n' + pollTemplate });
                alert("Poll template added to your post!");
              }}
            >
              <i className="fas fa-chart-bar text-lg sm:text-xl"></i>
            </button>
            
            {/* Carousel Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="Add carousel post"
              onClick={() => {
                alert("In a real implementation, this would open a carousel editor to add multiple images or slides.");
              }}
            >
              <i className="fas fa-clone text-lg sm:text-xl"></i>
            </button>
            
            {/* More Options Button */}
            <button 
              className="text-[#666666] hover:text-[#0a66c2] transition-colors flex justify-center items-center py-2" 
              title="More options"
              onClick={() => {
                const additionalOptions = [
                  "Add background color",
                  "Tag people",
                  "Add location",
                  "Feeling/activity",
                  "Create template",
                  "Schedule post"
                ];
                
                alert(`Additional options would include:\n- ${additionalOptions.join('\n- ')}`);
              }}
            >
              <i className="fas fa-ellipsis-h text-lg sm:text-xl"></i>
            </button>
          </div>
        </div>
        
        <ReadabilityPanel readability={readability} />
        
        <div className="flex flex-wrap gap-2 mt-6">
          <div className="flex-1 bg-gradient-to-r from-[#0a66c2] to-[#0e76a8] p-1 rounded-lg shadow-lg">
            <Button 
              className="w-full bg-white hover:bg-[#f8fafc] text-[#0a66c2] font-semibold text-base sm:text-lg py-4 sm:py-6 border-none" 
              onClick={() => {
                // First enhance the post if needed, then attempt to publish
                onEnhancePost().then(() => {
                  // After enhancement, show LinkedIn connect dialog
                  const confirmPublish = window.confirm("Ready to publish this post to your LinkedIn profile?");
                  
                  if (confirmPublish) {
                    // Simulate connection to LinkedIn - in a real app, this would use LinkedIn API
                    alert("Connecting to LinkedIn... Your post will be published to your feed.");
                  }
                });
              }}
            >
              <div className="flex items-center justify-center">
                <div className="bg-gradient-to-r from-[#0a66c2] to-[#0e76a8] text-transparent bg-clip-text">
                  <i className="fa-brands fa-linkedin mr-2 sm:mr-3 text-lg sm:text-xl"></i> 
                  <span className="font-bold text-sm sm:text-base">PUBLISH NOW</span>
                </div>
              </div>
            </Button>
          </div>
          
          <div className="w-full sm:w-auto bg-gradient-to-r from-[#134e4a] to-[#065f46] p-1 rounded-lg shadow-lg">
            <Button 
              className="w-full bg-white hover:bg-[#f8fafc] text-[#134e4a] font-semibold text-base sm:text-lg py-4 sm:py-6 border-none" 
              onClick={() => {
                // Open Google Calendar-like scheduling dialog
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                tomorrow.setHours(9, 0, 0, 0); // 9 AM tomorrow
                
                setScheduledDate(tomorrow);
                setShowScheduleDialog(true);
              }}
            >
              <div className="flex items-center justify-center">
                <div className="bg-gradient-to-r from-[#134e4a] to-[#065f46] text-transparent bg-clip-text">
                  <i className="fas fa-calendar-alt mr-2 sm:mr-3 text-lg sm:text-xl"></i> 
                  <span className="font-bold text-sm sm:text-base">SCHEDULE</span>
                </div>
              </div>
            </Button>
          </div>
          
          {/* Google Calendar-like Scheduling Dialog */}
          <Dialog open={showScheduleDialog} onOpenChange={setShowScheduleDialog}>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader className="bg-[#0a66c2] p-4 rounded-t-lg">
                <DialogTitle className="text-xl font-bold text-white mb-1">Schedule LinkedIn Post</DialogTitle>
                <p className="text-sm text-white opacity-90">Choose when to automatically publish your post to LinkedIn</p>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4 px-4 bg-[#0a66c2]">
                <div className="space-y-4 border-r border-gray-600 pr-4">
                  <div>
                    <h3 className="text-sm font-medium text-white mb-2">Select Date</h3>
                    <div className="border rounded-md p-4 overflow-hidden mx-auto flex justify-center items-center">
                      <DatePicker
                        selected={scheduledDate}
                        onChange={(date: Date) => setScheduledDate(date)}
                        minDate={new Date()}
                        inline
                        className="transform scale-90"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-white mb-2">Select Time</h3>
                    <div className="grid gap-2">
                      <div className="flex flex-col">
                        <label className="text-xs text-white mb-1">Time</label>
                        <input 
                          type="time" 
                          value={scheduledTime}
                          onChange={(e) => setScheduledTime(e.target.value)}
                          className="border rounded-md px-2 py-1.5"
                        />
                      </div>
                      
                      <div className="flex flex-col">
                        <label className="text-xs text-white mb-1">Time Zone</label>
                        <select 
                          value={timeZone}
                          onChange={(e) => setTimeZone(e.target.value)}
                          className="border rounded-md px-2 py-1.5 text-sm"
                        >
                          <option value="America/New_York">Eastern Time (ET)</option>
                          <option value="America/Chicago">Central Time (CT)</option>
                          <option value="America/Denver">Mountain Time (MT)</option>
                          <option value="America/Los_Angeles">Pacific Time (PT)</option>
                          <option value="Europe/London">London (GMT)</option>
                          <option value="Europe/Paris">Paris (CET)</option>
                          <option value="Asia/Tokyo">Tokyo (JST)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-white mb-2">Suggested Times</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { label: "8:00 AM", value: "08:00" },
                        { label: "9:30 AM", value: "09:30" },
                        { label: "12:00 PM", value: "12:00" },
                        { label: "3:00 PM", value: "15:00" }
                      ].map((time) => (
                        <Button 
                          key={time.value}
                          type="button"
                          variant="outline"
                          className={`text-xs ${scheduledTime === time.value ? 'bg-blue-50 border-blue-500' : ''}`}
                          onClick={() => setScheduledTime(time.value)}
                        >
                          {time.label}
                        </Button>
                      ))}
                    </div>
                    <p className="text-xs text-white mt-2 opacity-80">Best engagement times based on LinkedIn analytics</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-white mb-2">Preview</h3>
                    <div className="text-sm p-3 bg-blue-50 rounded-md">
                      {scheduledDate && (
                        <div className="flex items-start">
                          <div className="mr-2 text-blue-600">
                            <i className="fas fa-calendar-check text-lg"></i>
                          </div>
                          <div>
                            <p className="font-medium">{scheduledDate.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
                            <p className="text-gray-600">{scheduledTime} • {timeZone.split('/').pop()?.replace('_', ' ')}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <DialogFooter className="bg-[#0a66c2] p-4 border-t border-blue-700">
                <div className="flex items-center space-x-2 justify-between w-full">
                  <div className="text-xs text-white">
                    <i className="fas fa-info-circle mr-1"></i> Post will be automatically published at the scheduled time
                  </div>
                  <div className="flex space-x-2">
                    <DialogClose asChild>
                      <Button variant="outline" className="border-white text-white hover:bg-blue-800">Cancel</Button>
                    </DialogClose>
                    <Button 
                      type="button" 
                      className="bg-white text-[#0a66c2] font-bold hover:bg-gray-100"
                      onClick={() => {
                        // Combine date and time
                        if (!scheduledDate) return;
                        
                        const [hours, minutes] = scheduledTime.split(':').map(Number);
                        const scheduledDateTime = new Date(scheduledDate);
                        scheduledDateTime.setHours(hours, minutes, 0, 0);
                        
                        // Validate scheduled time is in the future
                        if (scheduledDateTime <= new Date()) {
                          alert("Scheduled time must be in the future.");
                          return;
                        }
                        
                        // Add to scheduled posts
                        setScheduledPosts([
                          ...scheduledPosts,
                          {
                            date: scheduledDateTime,
                            content: content.rawText
                          }
                        ]);
                        
                        // In a real app, this would save the post for scheduled publishing
                        alert(`Your post has been scheduled for ${scheduledDateTime.toLocaleString()} and will be published automatically to LinkedIn.`);
                        setShowScheduleDialog(false);
                      }}
                    >
                      Schedule Post
                    </Button>
                  </div>
                </div>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <p className="text-center text-xs text-gray-500 mt-2">
          Publish now to your LinkedIn profile or schedule for later automatic publishing
        </p>
      </CardContent>
    </Card>
  );
};

export default EditorPanel;
