import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";

const HelpGuide: React.FC = () => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-white text-[#134e4a] border-[#134e4a] hover:bg-[#134e4a] hover:bg-opacity-10">
          <i className="far fa-question-circle mr-2"></i> Help Guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-white">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#134e4a]">Linquity Help Guide</DialogTitle>
          <DialogDescription className="text-gray-700">
            Learn how to create engaging LinkedIn posts with Linquity
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="getting-started">
          <TabsList className="w-full mb-4 bg-[#0a66c2]">
            <TabsTrigger value="getting-started" className="flex-1 text-white data-[state=active]:bg-[#084e96] data-[state=active]:text-white">Getting Started</TabsTrigger>
            <TabsTrigger value="features" className="flex-1 text-white data-[state=active]:bg-[#084e96] data-[state=active]:text-white">Features</TabsTrigger>
            <TabsTrigger value="templates" className="flex-1 text-white data-[state=active]:bg-[#084e96] data-[state=active]:text-white">Templates</TabsTrigger>
            <TabsTrigger value="tips" className="flex-1 text-white data-[state=active]:bg-[#084e96] data-[state=active]:text-white">Tips & Tricks</TabsTrigger>
          </TabsList>

          <TabsContent value="getting-started" className="space-y-4">
            <div className="p-4 bg-[#f0f4f8] rounded-lg">
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Welcome to Linquity!</h3>
              <p className="mb-4 text-gray-700">
                Linquity helps you create engaging, professional LinkedIn posts and profile content with AI-powered suggestions and formatting tools.
              </p>
              
              <ol className="list-decimal pl-6 space-y-3 text-gray-700">
                <li>
                  <strong className="text-gray-800">Choose your goal</strong> - Select a content goal like educate, inspire, or announce 
                </li>
                <li>
                  <strong className="text-gray-800">Select your tone</strong> - Choose a writing tone that fits your professional brand
                </li>
                <li>
                  <strong className="text-gray-800">Start writing</strong> - Type directly in the editor or use a template to get started
                </li>
                <li>
                  <strong className="text-gray-800">Format your content</strong> - Use the toolbar to add formatting like bold, lists, and hashtags
                </li>
                <li>
                  <strong className="text-gray-800">Enhance your post</strong> - Click "Enhance" to get AI suggestions for improving your content
                </li>
                <li>
                  <strong className="text-gray-800">Preview and save</strong> - Check how your post will look on LinkedIn and save your draft
                </li>
              </ol>
            </div>
          </TabsContent>

          <TabsContent value="features" className="space-y-4">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="formatting" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Text Formatting
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <p>Format your text using the toolbar above the editor:</p>
                  <ul className="list-disc pl-6">
                    <li><strong>Bold</strong> - Highlight important points</li>
                    <li><em>Italic</em> - Add emphasis</li>
                    <li>Bullet Lists - Create easy-to-scan points</li>
                    <li>Numbered Lists - For step-by-step instructions</li>
                    <li>Hashtags - Add relevant tags for discoverability</li>
                    <li>Emojis - Add personality to your posts</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="ai-enhancement" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  AI Enhancement
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <p>Our AI enhancement tool analyzes your content and provides suggestions to make it more engaging and effective:</p>
                  <ul className="list-disc pl-6">
                    <li>Readability improvements</li>
                    <li>Sentence structure optimization</li>
                    <li>Tone consistency checks</li>
                    <li>Engagement hooks suggestions</li>
                    <li>Professional language improvements</li>
                  </ul>
                  <p className="mt-2">Click the "Enhance Post" button after writing your content to see AI suggestions.</p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="templates" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Templates
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <p>Start with a professional template for various post types:</p>
                  <ul className="list-disc pl-6">
                    <li>Job announcements</li>
                    <li>Personal achievements</li>
                    <li>Industry insights</li>
                    <li>Event promotions</li>
                    <li>Career advice</li>
                    <li>Weekly updates</li>
                    <li>And many more!</li>
                  </ul>
                  <p className="mt-2">Click "Use Template" in the template library to start with a pre-formatted post.</p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="drafts" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Saving Drafts
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <p>Save your work to revisit later:</p>
                  <ul className="list-disc pl-6">
                    <li>Click "Save Draft" in the header to store your current post</li>
                    <li>Access saved drafts from the "My Drafts" section</li>
                    <li>Edit and update previous drafts any time</li>
                    <li>Organize multiple posts for different purposes</li>
                  </ul>
                  <p className="mt-2">Your drafts are stored securely and only accessible to you.</p>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="preview" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  LinkedIn Preview
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <p>See how your post will look on LinkedIn before publishing:</p>
                  <ul className="list-disc pl-6">
                    <li>Toggle between mobile and desktop views</li>
                    <li>Check formatting and readability</li>
                    <li>Review how hashtags appear</li>
                    <li>See engagement tip suggestions</li>
                  </ul>
                  <p className="mt-2">Use the preview to ensure your post looks professional on all devices.</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <div className="p-4 bg-[#f0f4f8] rounded-lg">
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Using Templates Effectively</h3>
              <p className="mb-4 text-gray-700">
                Our templates provide professional structures for different types of LinkedIn content:
              </p>
              
              <ul className="list-disc pl-6 space-y-3 text-gray-700">
                <li>
                  <strong className="text-gray-800">Choose by purpose</strong> - Select templates based on your communication goal 
                </li>
                <li>
                  <strong className="text-gray-800">Customize placeholders</strong> - Replace [bracketed text] with your specific information
                </li>
                <li>
                  <strong className="text-gray-800">Maintain structure</strong> - The template format is designed for readability
                </li>
                <li>
                  <strong className="text-gray-800">Adjust tone</strong> - Each template has a suggested tone, but you can modify it
                </li>
                <li>
                  <strong className="text-gray-800">Add personal touches</strong> - Include your unique perspective and voice
                </li>
              </ul>
              
              <p className="mt-4 text-gray-700">
                Pro tip: Templates are starting points - always add your authentic voice and specific details to stand out.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="tips" className="space-y-4">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="engagement" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Boost Engagement
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <ul className="list-disc pl-6 text-gray-700">
                    <li>Start with a strong hook or question</li>
                    <li>Use short paragraphs (2-3 lines each)</li>
                    <li>Include a call to action at the end</li>
                    <li>Add 3-5 relevant hashtags</li>
                    <li>Post consistently (3-5 times per week)</li>
                    <li>Engage with comments promptly</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="hashtags" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Hashtag Strategy
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <ul className="list-disc pl-6 text-gray-700">
                    <li>Use a mix of popular and niche hashtags</li>
                    <li>Include 3-5 hashtags per post (not more)</li>
                    <li>Place hashtags at the end of your post</li>
                    <li>Create a branded personal hashtag</li>
                    <li>Research trending industry hashtags</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="timing" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Best Posting Times
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <ul className="list-disc pl-6 text-gray-700">
                    <li>Weekday mornings (7-9am)</li>
                    <li>Lunch breaks (12-1pm)</li>
                    <li>Early evening (5-6pm)</li>
                    <li>Tuesday, Wednesday, and Thursday tend to have highest engagement</li>
                    <li>Consistency matters more than perfect timing</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="profile" className="border border-[#e0e6eb] rounded-md mb-2">
                <AccordionTrigger className="text-lg font-semibold text-[#134e4a] bg-[#f3f6f8] px-4 py-2 rounded-t-md">
                  Profile Optimization
                </AccordionTrigger>
                <AccordionContent className="space-y-3 bg-white p-4 text-gray-700">
                  <ul className="list-disc pl-6 text-gray-700">
                    <li>Use a professional, high-quality photo</li>
                    <li>Create a descriptive headline beyond just your job title</li>
                    <li>Write an About section that tells your professional story</li>
                    <li>Add relevant skills and get endorsements</li>
                    <li>Showcase your best work in the Featured section</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>
        </Tabs>

        <div className="mt-6 flex justify-end">
          <DialogClose asChild>
            <Button variant="default" className="bg-[#134e4a] hover:bg-[#0a3533] text-white">Close Guide</Button>
          </DialogClose>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default HelpGuide;