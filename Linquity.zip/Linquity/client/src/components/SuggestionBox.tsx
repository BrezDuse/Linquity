import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/contexts/AuthContext';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { MessagesSquare, SendIcon, CheckCircle, LockIcon } from 'lucide-react';

// Schema only requires suggestion when using authenticated user data
const suggestionSchema = z.object({
  suggestion: z.string().min(5, "Please enter a suggestion (minimum 5 characters)"),
});

type SuggestionFormValues = z.infer<typeof suggestionSchema>;

const SuggestionBox: React.FC = () => {
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const form = useForm<SuggestionFormValues>({
    resolver: zodResolver(suggestionSchema),
    defaultValues: {
      suggestion: '',
    },
  });

  // Get user info for submission
  const userEmail = user?.email || '';
  const userName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}` 
    : (user?.firstName || user?.email?.split('@')[0] || '');

  const onSubmit = async (values: SuggestionFormValues) => {
    setIsSubmitting(true);
    try {
      // The actual Google Forms submission URL
      // This would be the URL from your Google Form in production
      // For now, we'll simulate a successful submission
      
      // In production, you would use a real Google Forms URL like:
      // const formUrl = "https://docs.google.com/forms/d/e/YOUR_FORM_ID/formResponse";
      
      // And you would map your form fields to Google Forms fields, including the user's info:
      // const formData = new FormData();
      // formData.append('entry.123456789', userName); // Replace with your actual entry IDs
      // formData.append('entry.987654321', userEmail);
      // formData.append('entry.567891234', values.suggestion);
      
      // Then submit with:
      // await fetch(formUrl, {
      //   method: 'POST',
      //   mode: 'no-cors', // Google Forms requires this
      //   body: formData,
      // });
      
      // For now, we'll just simulate a successful submission with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Submitted suggestion with:', {
        name: userName,
        email: userEmail,
        suggestion: values.suggestion
      });
      
      // Show success message
      toast({
        title: "Thank you for your suggestion!",
        description: "We appreciate your feedback and will consider it for future updates.",
      });
      
      // Reset form and show success state
      form.reset();
      setSubmitted(true);
      
    } catch (error) {
      console.error('Error submitting suggestion:', error);
      toast({
        title: "Failed to submit suggestion",
        description: "Please try again later or contact support.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    form.reset();
    setSubmitted(false);
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-50 py-12 px-4 border-t">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold tracking-tight">Help Us Improve</h2>
            <p className="text-muted-foreground mt-2">
              We value your feedback! Share your ideas to help us make Linquity better.
            </p>
          </div>
          
          <Card className="shadow-md">
            <CardContent className="flex flex-col items-center justify-center py-10 text-center">
              <div className="bg-amber-100 rounded-full p-3 mb-4">
                <LockIcon className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Please sign in to submit suggestions</h3>
              <p className="text-gray-600 mb-6 max-w-md">
                To help us prevent spam and better track suggestions, please sign in to submit feedback. We'll use your account information to identify your suggestions.
              </p>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => window.location.href = '/login'}>
                Sign in to submit feedback
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-12 px-4 border-t">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold tracking-tight">Help Us Improve</h2>
          <p className="text-muted-foreground mt-2">
            We value your feedback! Share your ideas, suggestions, or report issues.
          </p>
        </div>
        
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessagesSquare className="h-5 w-5 text-blue-600" />
              Suggestion Box
            </CardTitle>
            <CardDescription>
              Submit your ideas to help us make Linquity even better
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {submitted ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <div className="bg-green-100 rounded-full p-3 mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Thanks for your suggestion!</h3>
                <p className="text-gray-600 mb-6 max-w-md">
                  We appreciate your feedback and will consider it for future updates to improve the platform.
                </p>
                <Button variant="outline" onClick={resetForm}>
                  Submit another suggestion
                </Button>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  {/* Display user information used for submission */}
                  <div className="bg-gray-100 p-4 rounded-lg mb-2">
                    <h4 className="text-sm font-medium mb-2">Submitting feedback as:</h4>
                    <div className="flex flex-col md:flex-row gap-2 md:gap-4">
                      <div className="text-sm">
                        <span className="font-medium">Name:</span> {userName}
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">Email:</span> {userEmail}
                      </div>
                    </div>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="suggestion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Suggestion</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="I suggest adding..." 
                            className="min-h-[120px]" 
                            {...field} 
                            disabled={isSubmitting}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <SendIcon className="mr-2 h-4 w-4" />
                          Submit Suggestion
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </CardContent>
          
          <CardFooter className="bg-gray-50 border-t px-6 py-4">
            <p className="text-xs text-gray-500">
              Your suggestions help us prioritize new features and improvements. Thank you for helping make Linquity better!
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default SuggestionBox;