import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

interface LinkedInHooksGeneratorProps {
  onSelectHook: (hook: string) => void;
}

type HookType = 'question' | 'statistic' | 'story' | 'challenge' | 'quote';

interface GeneratedHook {
  text: string;
  type: HookType;
  strength: 'high' | 'medium' | 'low';
}

const LinkedInHooksGenerator: FC<LinkedInHooksGeneratorProps> = ({ onSelectHook }) => {
  const [topic, setTopic] = useState<string>('');
  const [industry, setIndustry] = useState<string>('technology');
  const [audience, setAudience] = useState<string>('professionals');
  const [selectedHookTypes, setSelectedHookTypes] = useState<HookType[]>(['question', 'statistic', 'story']);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedHooks, setGeneratedHooks] = useState<GeneratedHook[]>([]);

  // Example hook templates for demonstration
  const hookTemplates = {
    question: [
      "Did you know that {X}% of {industry} professionals struggle with {topic}?",
      "What would happen if your {topic} strategy was completely transformed overnight?",
      "Are you still using outdated approaches to {topic} in {currentYear}?",
      "Have you ever wondered why some {industry} leaders excel at {topic} while others fail?",
      "What's the one {topic} mistake that's costing {industry} businesses millions?"
    ],
    statistic: [
      "A shocking {X}% of {industry} initiatives fail due to poor {topic} management.",
      "{X} out of 10 {audience} report that {topic} is their biggest challenge in {currentYear}.",
      "Companies that master {topic} see up to {X}% higher growth than their competitors.",
      "Only {X}% of {industry} professionals feel confident in their {topic} strategy.",
      "New research: {industry} companies investing in {topic} outperform peers by {X}%."
    ],
    story: [
      "When I first started working with {topic}, I made a mistake that cost my team {X} hours of work...",
      "Last year, a client came to me with a {topic} disaster. Here's how we turned it around...",
      "My biggest {topic} failure taught me a lesson I'll never forget...",
      "I remember when {topic} seemed impossible to master. Then everything changed when...",
      "Three years ago, I watched a {industry} giant collapse due to one critical {topic} oversight..."
    ],
    challenge: [
      "I challenge you to improve your {topic} results by {X}% in the next 30 days.",
      "Can you identify the three biggest {topic} mistakes in your {industry} organization?",
      "Take the {topic} assessment: Are you really as effective as you think?",
      "For the next week, track how much time you spend on {topic}. You'll be shocked.",
      "Most {audience} can't name 5 best practices for {topic}. Can you?"
    ],
    quote: [
      ""The biggest risk in {industry} isn't taking a chance on {topic}, it's taking no chance at all."",
      ""In a world of {industry} noise, mastering {topic} is your competitive advantage."",
      ""The secret to {topic} isn't working harder; it's working smarter than your competition."",
      ""We don't have a {topic} problem; we have a {topic} perspective problem."",
      ""Your approach to {topic} today determines your {industry} success tomorrow.""
    ]
  };

  const generateHooks = () => {
    if (!topic) {
      alert('Please enter a topic for your hooks');
      return;
    }

    setIsGenerating(true);

    // Simulate API call delay
    setTimeout(() => {
      const currentYear = new Date().getFullYear();
      const newHooks: GeneratedHook[] = [];

      // Generate 2 hooks for each selected type
      selectedHookTypes.forEach(type => {
        const availableTemplates = hookTemplates[type];
        
        // Get two random templates
        const randomIndexes = [
          Math.floor(Math.random() * availableTemplates.length),
          Math.floor(Math.random() * availableTemplates.length)
        ];
        
        // Make sure they're different
        if (randomIndexes[0] === randomIndexes[1] && availableTemplates.length > 1) {
          randomIndexes[1] = (randomIndexes[0] + 1) % availableTemplates.length;
        }
        
        randomIndexes.forEach(index => {
          let template = availableTemplates[index];
          
          // Replace variables in template
          let hookText = template
            .replace('{topic}', topic)
            .replace('{industry}', industry)
            .replace('{audience}', audience)
            .replace('{currentYear}', currentYear.toString())
            .replace('{X}', Math.floor(Math.random() * 60 + 30).toString()); // Random number between 30-90
          
          // Determine hook strength (in a real app, would use AI to analyze)
          const strength = Math.random() > 0.6 ? 'high' : (Math.random() > 0.3 ? 'medium' : 'low');
          
          newHooks.push({
            text: hookText,
            type,
            strength
          });
        });
      });
      
      setGeneratedHooks(newHooks);
      setIsGenerating(false);
    }, 1500);
  };

  const getStrengthColor = (strength: string) => {
    switch(strength) {
      case 'high': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getIconForHookType = (type: HookType) => {
    switch(type) {
      case 'question': return 'fas fa-question-circle';
      case 'statistic': return 'fas fa-chart-bar';
      case 'story': return 'fas fa-book-open';
      case 'challenge': return 'fas fa-trophy';
      case 'quote': return 'fas fa-quote-right';
    }
  };

  const handleHookTypeChange = (type: HookType) => {
    setSelectedHookTypes(prev => {
      if (prev.includes(type)) {
        return prev.filter(t => t !== type);
      } else {
        return [...prev, type];
      }
    });
  };

  return (
    <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="p-4 border-b bg-[#134e4a] bg-opacity-10">
        <CardTitle className="text-lg font-medium text-[#134e4a] flex items-center">
          <span className="bg-[#0d9488] h-5 w-5 rounded-full mr-2"></span>
          LinkedIn Hooks Generator 🧲
        </CardTitle>
        <CardDescription>
          Create attention-grabbing hooks that make your audience stop scrolling
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="space-y-6">
          {/* Input Section */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="topic" className="text-[#134e4a]">What's your post about?</Label>
              <Input 
                id="topic" 
                placeholder="Leadership, remote work, industry trends, etc."
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="mt-1 border-gray-300"
              />
              <p className="text-xs text-gray-500 mt-1">
                Be specific - "project management tips" is better than just "management"
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="industry" className="text-[#134e4a]">Industry</Label>
                <Select value={industry} onValueChange={setIndustry}>
                  <SelectTrigger id="industry" className="mt-1 border-gray-300">
                    <SelectValue placeholder="Select an industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="consulting">Consulting</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="audience" className="text-[#134e4a]">Target Audience</Label>
                <Select value={audience} onValueChange={setAudience}>
                  <SelectTrigger id="audience" className="mt-1 border-gray-300">
                    <SelectValue placeholder="Select an audience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professionals">Professionals</SelectItem>
                    <SelectItem value="executives">Executives</SelectItem>
                    <SelectItem value="managers">Managers</SelectItem>
                    <SelectItem value="specialists">Specialists</SelectItem>
                    <SelectItem value="entrepreneurs">Entrepreneurs</SelectItem>
                    <SelectItem value="jobseekers">Job Seekers</SelectItem>
                    <SelectItem value="students">Students</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label className="text-[#134e4a] mb-2 block">Hook Types</Label>
              <div className="flex flex-wrap gap-2">
                {(['question', 'statistic', 'story', 'challenge', 'quote'] as HookType[]).map(type => (
                  <Button
                    key={type}
                    variant={selectedHookTypes.includes(type) ? "default" : "outline"}
                    className={selectedHookTypes.includes(type) 
                      ? "bg-[#0d9488] hover:bg-[#134e4a]" 
                      : "border-gray-300 hover:bg-[#134e4a] hover:bg-opacity-10 hover:text-[#134e4a]"}
                    onClick={() => handleHookTypeChange(type)}
                  >
                    <i className={`${getIconForHookType(type)} mr-2`}></i>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </Button>
                ))}
              </div>
            </div>
            
            <Button 
              onClick={generateHooks}
              disabled={isGenerating || !topic || selectedHookTypes.length === 0}
              className="w-full bg-[#0d9488] hover:bg-[#134e4a]"
            >
              {isGenerating ? (
                <><i className="fas fa-spinner fa-spin mr-2"></i>Generating Hooks...</>
              ) : (
                <><i className="fas fa-magic mr-2"></i>Generate Attention-Grabbing Hooks</>
              )}
            </Button>
          </div>
          
          {/* Results Section */}
          {generatedHooks.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-gray-200">
              <h3 className="font-medium text-[#134e4a]">
                <i className="fas fa-star mr-2"></i>
                Generated Hooks for Your Post
              </h3>
              
              <div className="space-y-3">
                {generatedHooks.map((hook, index) => (
                  <div 
                    key={index} 
                    className="border border-gray-200 rounded-md overflow-hidden hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-center justify-between bg-gray-50 px-3 py-2 border-b border-gray-200">
                      <div className="flex items-center">
                        <i className={`${getIconForHookType(hook.type)} text-[#0d9488] mr-2`}></i>
                        <span className="text-sm font-medium text-gray-700 capitalize">{hook.type} Hook</span>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStrengthColor(hook.strength)}`}>
                        {hook.strength.charAt(0).toUpperCase() + hook.strength.slice(1)} Impact
                      </span>
                    </div>
                    <div className="p-3 bg-white">
                      <p className="text-gray-800 mb-3">{hook.text}</p>
                      <div className="flex justify-end">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => onSelectHook(hook.text)}
                          className="text-[#0d9488] border-[#0d9488] hover:bg-[#0d9488] hover:bg-opacity-10"
                        >
                          <i className="fas fa-plus-circle mr-2"></i>
                          Use This Hook
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-sm text-blue-800">
                <i className="fas fa-lightbulb text-blue-600 mr-2"></i>
                <strong>Pro Tip:</strong> Great hooks create curiosity or promise value. Choose one that makes your audience think "I need to know more about this!"
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default LinkedInHooksGenerator;