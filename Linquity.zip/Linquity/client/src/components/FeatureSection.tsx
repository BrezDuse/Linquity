import { FC } from 'react';

const FeatureSection: FC = () => {
  return (
    <div className="mt-12 bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-6 text-center">Why Linquity is Better for LinkedIn Content</h2>
      
      <div className="grid md:grid-cols-3 gap-8">
        {/* Feature 1 */}
        <div className="text-center">
          <div className="h-48 w-full rounded-lg bg-gray-100 flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-[#0a66c2]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">Professional Formatting</h3>
          <p className="text-gray-600 text-sm">Format your posts with optimal spacing, emojis, and bullet points to increase engagement.</p>
        </div>
        
        {/* Feature 2 */}
        <div className="text-center">
          <div className="h-48 w-full rounded-lg bg-gray-100 flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-[#0a66c2]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">Readability Analysis</h3>
          <p className="text-gray-600 text-sm">Get instant feedback on readability scores and sentence complexity to improve clarity.</p>
        </div>
        
        {/* Feature 3 */}
        <div className="text-center">
          <div className="h-48 w-full rounded-lg bg-gray-100 flex items-center justify-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-[#0a66c2]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">Device Preview</h3>
          <p className="text-gray-600 text-sm">See exactly how your post will look on mobile and desktop before publishing.</p>
        </div>
      </div>
    </div>
  );
};

export default FeatureSection;
