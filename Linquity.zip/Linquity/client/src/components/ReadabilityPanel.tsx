import { FC, useState } from 'react';
import { ReadabilityFeedback } from '@/types';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ReadabilityPanelProps {
  readability: ReadabilityFeedback;
}

const ReadabilityPanel: FC<ReadabilityPanelProps> = ({ readability }) => {
  const [activeTab, setActiveTab] = useState<string>('overview');
  
  // Determine score color
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-[#057642]';
    if (score >= 60) return 'text-[#0a66c2]';
    if (score >= 40) return 'text-amber-500';
    return 'text-red-500';
  };
  
  const getProgressColor = (score: number) => {
    if (score >= 80) return 'bg-[#057642]';
    if (score >= 60) return 'bg-[#0a66c2]';
    if (score >= 40) return 'bg-amber-500';
    return 'bg-red-500';
  };
  
  const getEmoji = (score: number) => {
    if (score >= 80) return '🌟';
    if (score >= 60) return '👍';
    if (score >= 40) return '⚠️';
    return '⚡';
  };
  
  const getAudienceLevel = (score: number) => {
    if (score >= 80) return 'General audience, very accessible';
    if (score >= 60) return 'Average LinkedIn user, good readability';
    if (score >= 40) return 'Professional audience, moderate complexity';
    return 'Specialized audience, consider simplifying';
  };
  
  const getIdealLength = () => {
    return {
      min: 700,
      max: 1300,
      current: readability.wordCount * 5, // approximate character count
      status: readability.wordCount > 50 && readability.wordCount < 260 ? 'optimal' : (readability.wordCount <= 50 ? 'too-short' : 'too-long')
    };
  };
  
  const lengthInfo = getIdealLength();
  
  return (
    <Card className="bg-white rounded-lg shadow-sm mb-4 overflow-hidden">
      <div className="bg-gradient-to-r from-[#0a66c2] to-[#0e76a8] p-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-sm uppercase text-white">Readability Analysis</h3>
          <Badge variant="outline" className="bg-white text-[#0a66c2]">
            {getEmoji(readability.score)} {readability.rating}
          </Badge>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="p-4">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="improvements">Improvements</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium text-gray-700">Readability Score</span>
              <span className={`text-sm font-medium ${getScoreColor(readability.score)}`}>
                {readability.score}/100
              </span>
            </div>
            <Progress 
              className="w-full bg-gray-200 h-3 rounded-full" 
              value={readability.score} 
              max={100}
              style={{
                "--progress-indicator-color": getProgressColor(readability.score).replace("bg-", "")
              } as React.CSSProperties}
            />
            <p className="text-xs text-gray-500 mt-2">
              {readability.score >= 60 
                ? "Great! Your content is easy to read and understand" 
                : "Consider simplifying your text for better engagement"}
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-xs text-gray-500 uppercase">Word Count</div>
              <div className="text-2xl font-bold text-gray-800 mt-1">{readability.wordCount}</div>
              <div className={`text-xs ${readability.wordCount > 50 && readability.wordCount < 260 ? 'text-[#057642]' : 'text-amber-500'} mt-1`}>
                {readability.wordCount > 50 && readability.wordCount < 260 
                  ? "Optimal for LinkedIn" 
                  : (readability.wordCount <= 50 ? "Consider adding more content" : "Consider shortening")}
              </div>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-xs text-gray-500 uppercase">Reading Time</div>
              <div className="text-2xl font-bold text-gray-800 mt-1">{Math.round(readability.readingTime / 60)} min</div>
              <div className="text-xs text-[#0a66c2] mt-1">
                {readability.readingTime < 60 ? "Quick read" : (readability.readingTime < 180 ? "Good length" : "Longer read")}
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="improvements" className="space-y-3">
          {readability.suggestions.length > 0 ? (
            <>
              {readability.suggestions.map((suggestion, index) => (
                <div key={index} className="p-3 bg-white rounded-md border border-gray-200">
                  <div className="flex items-start">
                    <div className="bg-[#0a66c2] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm mb-1 text-gray-800">Sentence Improvement</p>
                      <p className="text-gray-600 text-sm mb-2">
                        <span className="bg-yellow-100 px-1 rounded">{suggestion.text}</span>
                      </p>
                      <p className="text-[#0a66c2] text-sm">
                        Suggestion: <span className="bg-green-50 px-1 rounded">{suggestion.improvement}</span>
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              
              <div className="flex justify-end mt-2">
                <Button variant="outline" size="sm" className="text-xs">
                  <span className="mr-1">✓</span> Apply All Suggestions
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="text-[#0a66c2] text-4xl mb-2">🎉</div>
              <p className="text-gray-700 font-medium">No improvement suggestions</p>
              <p className="text-gray-500 text-sm mt-1">Your content looks great as it is!</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="insights" className="space-y-4">
          <div className="space-y-3">
            <div className="p-3 bg-gray-50 rounded-md">
              <div className="flex justify-between">
                <div className="text-sm font-medium text-gray-700">Target Audience</div>
                <Badge variant="outline" className="text-[#0a66c2]">
                  {readability.score >= 60 ? 'General' : 'Specialized'}
                </Badge>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                {getAudienceLevel(readability.score)}
              </p>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-md">
              <div className="flex justify-between">
                <div className="text-sm font-medium text-gray-700">Post Length</div>
                <Badge 
                  variant="outline" 
                  className={lengthInfo.status === 'optimal' ? 'bg-green-100 text-green-800' : 'text-amber-500'}
                >
                  {lengthInfo.status === 'optimal' ? 'Optimal' : (lengthInfo.status === 'too-short' ? 'Too Short' : 'Too Long')}
                </Badge>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                LinkedIn posts perform best between 700-1300 characters. Your post has approximately {lengthInfo.current} characters.
              </p>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-md">
              <div className="text-sm font-medium text-gray-700 mb-2">Engagement Prediction</div>
              <div className="flex items-center">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-[#0a66c2] h-2.5 rounded-full" 
                    style={{ width: `${Math.min(readability.score, 100)}%` }}
                  ></div>
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  {readability.score >= 80 ? 'High' : (readability.score >= 60 ? 'Good' : (readability.score >= 40 ? 'Average' : 'Low'))}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Based on readability, length, and structure
              </p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default ReadabilityPanel;
