import { FC, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface LinkedInProfileConnectProps {
  onProfileConnect?: (profile: LinkedInProfile) => void;
}

export interface LinkedInProfile {
  id: string;
  name: string;
  headline: string;
  profilePicture: string;
  isConnected: boolean;
  allowDirectPublishing: boolean;
  imageAttachment?: string; // For attached images in posts
}

const LinkedInProfileConnect: FC<LinkedInProfileConnectProps> = ({ onProfileConnect }) => {
  const [activeTab, setActiveTab] = useState<string>('connect');
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [connectionError, setConnectionError] = useState<string>('');
  const [linkedInProfile, setLinkedInProfile] = useState<LinkedInProfile | null>(null);
  const [allowDirectPublishing, setAllowDirectPublishing] = useState<boolean>(false);
  
  // In a real implementation, this would redirect to LinkedIn OAuth flow
  const handleConnectLinkedIn = () => {
    setIsConnecting(true);
    setConnectionError('');
    
    // Simulate API connection delay
    setTimeout(() => {
      // Simulate a successful connection
      const mockProfile: LinkedInProfile = {
        id: 'linkedin-123456',
        name: 'Jane Smith',
        headline: 'Marketing Director | Content Strategy | Digital Marketing',
        profilePicture: 'https://randomuser.me/api/portraits/women/42.jpg', // Example profile picture
        isConnected: true,
        allowDirectPublishing: allowDirectPublishing
      };
      
      setLinkedInProfile(mockProfile);
      setIsConnecting(false);
      
      if (onProfileConnect) {
        onProfileConnect(mockProfile);
      }
      
      // Switch to profile tab after successful connection
      setActiveTab('profile');
    }, 1500);
  };
  
  const handleDisconnect = () => {
    setLinkedInProfile(null);
    setActiveTab('connect');
  };
  
  const handleDirectPublishingToggle = (enabled: boolean) => {
    setAllowDirectPublishing(enabled);
    
    if (linkedInProfile) {
      const updatedProfile = {
        ...linkedInProfile,
        allowDirectPublishing: enabled
      };
      setLinkedInProfile(updatedProfile);
      
      if (onProfileConnect) {
        onProfileConnect(updatedProfile);
      }
    }
  };
  
  return (
    <Card className="mb-4 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="p-3 pb-0 border-b bg-[#134e4a] bg-opacity-10">
        <CardTitle className="text-sm font-medium text-[#134e4a] flex items-center">
          <span className="bg-[#0d9488] h-4 w-4 rounded-full mr-2"></span>
          LinkedIn Connection
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <Tabs defaultValue="connect" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 mb-3 bg-[#134e4a] bg-opacity-5">
            <TabsTrigger value="connect" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fab fa-linkedin mr-2"></i>
              Connect
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]" disabled={!linkedInProfile}>
              <i className="fas fa-user-circle mr-2"></i>
              Profile
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="connect" className="space-y-4">
            {!linkedInProfile ? (
              <>
                <div className="text-center py-4">
                  <div className="bg-[#0a66c2] inline-flex items-center justify-center rounded-full h-16 w-16 text-white text-2xl mb-4">
                    <i className="fab fa-linkedin-in"></i>
                  </div>
                  <h3 className="text-lg font-semibold mb-1">Connect to LinkedIn</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Connect your LinkedIn profile to display your profile picture and publish directly to LinkedIn.
                  </p>
                  
                  <div className="flex justify-center mb-4">
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="publishing" 
                        checked={allowDirectPublishing}
                        onCheckedChange={handleDirectPublishingToggle}
                      />
                      <Label htmlFor="publishing" className="text-sm">Allow direct publishing to LinkedIn</Label>
                    </div>
                  </div>
                  
                  <Button 
                    className="bg-[#0a66c2] hover:bg-[#004182] text-white"
                    onClick={handleConnectLinkedIn}
                    disabled={isConnecting}
                  >
                    {isConnecting ? 
                      <><i className="fas fa-spinner fa-spin mr-2"></i>Connecting...</> : 
                      <><i className="fab fa-linkedin mr-2"></i>Connect with LinkedIn</>
                    }
                  </Button>
                </div>
                
                {connectionError && (
                  <Alert variant="destructive" className="mt-4">
                    <AlertDescription>
                      {connectionError}
                    </AlertDescription>
                  </Alert>
                )}
              </>
            ) : (
              <div className="text-center py-4">
                <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-100">
                  <i className="fas fa-check-circle mr-1"></i> Connected
                </Badge>
                <p className="text-sm text-gray-500 mb-4">
                  Your LinkedIn profile is connected. You can view or edit your connection settings.
                </p>
                <Button 
                  variant="outline" 
                  className="text-red-500 border-red-200 hover:bg-red-50"
                  onClick={handleDisconnect}
                >
                  <i className="fas fa-unlink mr-2"></i>
                  Disconnect
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="profile" className="space-y-4">
            {linkedInProfile && (
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-20 w-20 mb-3">
                  <AvatarImage src={linkedInProfile.profilePicture} />
                  <AvatarFallback>{linkedInProfile.name.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <h3 className="text-lg font-semibold">{linkedInProfile.name}</h3>
                <p className="text-sm text-gray-500 mb-3">{linkedInProfile.headline}</p>
                
                <div className="w-full mt-4 space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <i className="fas fa-paper-plane text-[#0d9488] mr-2"></i>
                      <span className="text-sm">Direct Publishing</span>
                    </div>
                    <Switch 
                      checked={linkedInProfile.allowDirectPublishing}
                      onCheckedChange={handleDirectPublishingToggle}
                    />
                  </div>
                  
                  <Button className="w-full bg-[#0d9488] hover:bg-[#134e4a]">
                    <i className="fas fa-edit mr-2"></i>
                    Publish Current Post
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default LinkedInProfileConnect;