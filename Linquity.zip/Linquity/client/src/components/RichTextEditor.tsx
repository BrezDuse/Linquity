import { FC, useState, useEffect, useRef } from 'react';
import { calculateReadingTime } from '@/lib/textAnalysis';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  wordCount: number;
  readingTime: number;
  onImageAttach?: (imageUrl: string) => void;
}

const RichTextEditor: FC<RichTextEditorProps> = ({ 
  value, 
  onChange, 
  wordCount, 
  readingTime,
  onImageAttach = () => {} 
}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);
  
  const handleInput = () => {
    if (editorRef.current) {
      const content = editorRef.current.innerHTML;
      const plainText = editorRef.current.innerText;
      onChange(plainText);
      // This forces an immediate update
      editorRef.current.focus();
    }
  };

  const execCommand = (command: string, value: string = '') => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      editorRef.current.focus();
      const plainText = editorRef.current.innerText;
      onChange(plainText);
    }
  };

  const formatText = (format: string) => {
    execCommand(format);
  };
  
  const createStaircase = (type: 'option1' | 'option2' | 'option3' | 'option4') => {
    if (!editorRef.current) return;
    
    // Get selected text or use all text if nothing is selected
    const selection = window.getSelection();
    let text = '';
    
    if (selection && selection.toString()) {
      text = selection.toString();
    } else if (editorRef.current.innerText) {
      text = editorRef.current.innerText;
    }
    
    if (!text.trim()) return;
    
    // Split text into lines
    const lines = text.split('\n').filter(line => line.trim());
    
    // Create staircase format based on type
    let formattedText = '';
    
    switch (type) {
      case 'option1': // Left Align (first image)
        lines.forEach((line, index) => {
          formattedText += line + '\n';
        });
        break;
        
      case 'option2': // Center Align (second image)
        const maxLength2 = Math.max(...lines.map(line => line.length));
        lines.forEach((line) => {
          const padding = Math.floor((maxLength2 - line.length) / 2);
          formattedText += ' '.repeat(padding) + line + '\n';
        });
        break;
        
      case 'option3': // Mixed Align (third image)
        lines.forEach((line, index) => {
          if (index % 2 === 0) {
            // Even index - left align
            formattedText += line + '\n';
          } else {
            // Odd index - indented
            formattedText += '    ' + line + '\n';
          }
        });
        break;
        
      case 'option4': // Right Align (fourth image)
        const maxLength4 = Math.max(...lines.map(line => line.length));
        lines.forEach((line) => {
          const padding = maxLength4 - line.length;
          formattedText += ' '.repeat(padding) + line + '\n';
        });
        break;
    }
    
    // Always update the whole editor content with the formatted text
    // This ensures the staircase format is applied automatically
    editorRef.current.innerText = formattedText.trim();
    onChange(formattedText.trim());
  };
  
  return (
    <div className="mb-4">
      <label className="block text-[#134e4a] font-medium mb-2 text-sm">
        Create your LinkedIn post below
      </label>

      {/* Formatting toolbar matching AuthoredUp design */}
      <div className="bg-white border border-gray-200 rounded-t-md p-1 flex flex-wrap gap-1 shadow-sm">
        
        {/* Undo Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => document.execCommand('undo')}
            >
              <i className="fas fa-undo"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Undo
          </TooltipContent>
        </Tooltip>
        
        {/* Redo Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => document.execCommand('redo')}
            >
              <i className="fas fa-redo"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Redo
          </TooltipContent>
        </Tooltip>
        
        {/* Clear Formatting */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => document.execCommand('removeFormat')}
            >
              <i className="fas fa-remove-format"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Clear formatting
          </TooltipContent>
        </Tooltip>
        
        <Separator orientation="vertical" className="h-6 mx-1 bg-gray-200" />
        
        {/* Bold Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => formatText('bold')}
            >
              <i className="fas fa-bold"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Bold
          </TooltipContent>
        </Tooltip>
        
        {/* Italic Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => formatText('italic')}
            >
              <i className="fas fa-italic"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Italic
          </TooltipContent>
        </Tooltip>
        
        {/* Underline Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => formatText('underline')}
            >
              <i className="fas fa-underline"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Underline
          </TooltipContent>
        </Tooltip>
        
        <Separator orientation="vertical" className="h-6 mx-1 bg-gray-200" />
        
        {/* Code Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => execCommand('formatBlock', '<pre>')}
            >
              <i className="fas fa-code"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Code block
          </TooltipContent>
        </Tooltip>
        
        <Separator orientation="vertical" className="h-6 mx-1 bg-gray-200" />
        
        {/* Bullet List */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => execCommand('insertUnorderedList')}
            >
              <i className="fas fa-list-ul"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Bullet list
          </TooltipContent>
        </Tooltip>
        
        {/* Numbered List */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => execCommand('insertOrderedList')}
            >
              <i className="fas fa-list-ol"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Numbered list
          </TooltipContent>
        </Tooltip>
        
        <Separator orientation="vertical" className="h-6 mx-1 bg-gray-200" />
        
        {/* Link */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              onClick={() => {
                const url = prompt('Enter the URL:');
                if (url) execCommand('createLink', url);
              }}
            >
              <i className="fas fa-link"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
            Insert link
          </TooltipContent>
        </Tooltip>
        
        <Separator orientation="vertical" className="h-6 mx-1 bg-gray-200" />
        
        {/* Text Staircase dropdown */}
        <DropdownMenu>
          <Tooltip>
            <TooltipTrigger asChild>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0 text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                >
                  <div className="flex flex-col justify-center w-5 h-5">
                    <div className="w-3 h-0.5 bg-gray-600 mb-0.5"></div>
                    <div className="w-5 h-0.5 bg-gray-600 mb-0.5"></div>
                    <div className="w-4 h-0.5 bg-gray-600"></div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="bg-gray-900 text-white py-1 px-2 text-xs">
              Text layout options
            </TooltipContent>
          </Tooltip>
          <DropdownMenuContent className="bg-white border border-gray-200 p-1 min-w-[220px]">
            <div className="px-3 py-1 text-xs font-semibold text-gray-700 border-b border-gray-100 mb-1">
              Text Arrangement
            </div>
            
            {/* Short to Long */}
            <DropdownMenuItem 
              className="flex items-center hover:bg-gray-100 px-3 py-2 text-gray-800 cursor-pointer"
              onClick={() => {
                if (!editorRef.current) return;
                
                const lines = editorRef.current.innerText.split('\n').filter(line => line.trim());
                if (lines.length < 2) return;
                
                // Sort lines by length (short to long)
                lines.sort((a, b) => a.length - b.length);
                const formattedText = lines.join('\n');
                
                editorRef.current.innerText = formattedText;
                onChange(formattedText);
              }}
            >
              <div className="flex flex-col mr-2 items-start">
                <div className="w-2 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-4 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-6 h-0.5 bg-gray-600"></div>
              </div>
              <div>
                <span className="text-sm font-medium">Short to Long</span>
                <p className="text-xs text-gray-500 mt-0.5">Arrange lines by length (shortest first)</p>
              </div>
            </DropdownMenuItem>
            
            {/* Long to Short */}
            <DropdownMenuItem 
              className="flex items-center hover:bg-gray-100 px-3 py-2 text-gray-800 cursor-pointer"
              onClick={() => {
                if (!editorRef.current) return;
                
                const lines = editorRef.current.innerText.split('\n').filter(line => line.trim());
                if (lines.length < 2) return;
                
                // Sort lines by length (long to short)
                lines.sort((a, b) => b.length - a.length);
                const formattedText = lines.join('\n');
                
                editorRef.current.innerText = formattedText;
                onChange(formattedText);
              }}
            >
              <div className="flex flex-col mr-2 items-start">
                <div className="w-6 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-4 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-2 h-0.5 bg-gray-600"></div>
              </div>
              <div>
                <span className="text-sm font-medium">Long to Short</span>
                <p className="text-xs text-gray-500 mt-0.5">Arrange lines by length (longest first)</p>
              </div>
            </DropdownMenuItem>
            
            {/* Pyramid */}
            <DropdownMenuItem 
              className="flex items-center hover:bg-gray-100 px-3 py-2 text-gray-800 cursor-pointer"
              onClick={() => {
                if (!editorRef.current) return;
                
                const lines = editorRef.current.innerText.split('\n').filter(line => line.trim());
                if (lines.length < 3) return;
                
                // Sort lines by length (short to long)
                const sortedLines = [...lines].sort((a, b) => a.length - b.length);
                
                // Create pyramid pattern (short to long to short)
                const midpoint = Math.floor(lines.length / 2);
                const pyramidLines = [];
                
                for (let i = 0; i < midpoint; i++) {
                  pyramidLines.push(sortedLines[i]);
                }
                
                for (let i = sortedLines.length - 1; i >= midpoint; i--) {
                  pyramidLines.push(sortedLines[i]);
                }
                
                const formattedText = pyramidLines.join('\n');
                
                editorRef.current.innerText = formattedText;
                onChange(formattedText);
              }}
            >
              <div className="flex flex-col mr-2 items-center">
                <div className="w-2 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-4 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-6 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-4 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-2 h-0.5 bg-gray-600"></div>
              </div>
              <div>
                <span className="text-sm font-medium">Pyramid</span>
                <p className="text-xs text-gray-500 mt-0.5">Short-long-short pyramid pattern</p>
              </div>
            </DropdownMenuItem>
            
            {/* Chevron */}
            <DropdownMenuItem 
              className="flex items-center hover:bg-gray-100 px-3 py-2 text-gray-800 cursor-pointer"
              onClick={() => {
                if (!editorRef.current) return;
                
                const lines = editorRef.current.innerText.split('\n').filter(line => line.trim());
                if (lines.length < 2) return;
                
                // Create chevron pattern using indentation
                const formattedLines = lines.map((line, index) => {
                  const indentSize = index % 2 === 0 ? 0 : 4; // Indent every other line
                  return ' '.repeat(indentSize) + line;
                });
                
                const formattedText = formattedLines.join('\n');
                
                editorRef.current.innerText = formattedText;
                onChange(formattedText);
              }}
            >
              <div className="flex flex-col mr-2">
                <div className="w-6 h-0.5 bg-gray-600 mb-1"></div>
                <div className="ml-2 w-6 h-0.5 bg-gray-600 mb-1"></div>
                <div className="w-6 h-0.5 bg-gray-600 mb-1"></div>
                <div className="ml-2 w-6 h-0.5 bg-gray-600"></div>
              </div>
              <div>
                <span className="text-sm font-medium">Chevron</span>
                <p className="text-xs text-gray-500 mt-0.5">Alternating indentation pattern</p>
              </div>
            </DropdownMenuItem>
            

          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      
      <div
        ref={editorRef}
        className="border-2 border-t-0 border-[#134e4a] border-opacity-20 rounded-b-md p-4 min-h-[280px] focus:outline-none focus:ring-2 focus:ring-[#134e4a] focus:border-transparent bg-white shadow-md text-base text-gray-800"
        contentEditable={true}
        onInput={handleInput}
        suppressContentEditableWarning={true}
        placeholder="Start typing your LinkedIn post here..."
      />
      <div className="flex justify-between items-center mt-2">
        <div className="text-sm font-medium text-[#134e4a]">
          <i className="fas fa-glasses mr-1"></i> Readability metrics
        </div>
        <div className="text-sm text-gray-600">
          <span className="bg-[#134e4a] bg-opacity-10 px-2 py-1 rounded-md font-medium">
            <i className="fas fa-file-alt mr-1"></i> {wordCount} words
          </span>
          <span className="mx-2">•</span>
          <span className="bg-[#134e4a] bg-opacity-10 px-2 py-1 rounded-md font-medium">
            <i className="fas fa-stopwatch mr-1"></i> ~{readingTime} sec read
          </span>
        </div>
      </div>
    </div>
  );
};

export default RichTextEditor;
