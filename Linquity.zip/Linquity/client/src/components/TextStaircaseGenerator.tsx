import { FC, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TextStaircaseGeneratorProps {
  text: string;
  onTextChange: (text: string) => void;
}

const TextStaircaseGenerator: FC<TextStaircaseGeneratorProps> = ({ text, onTextChange }) => {
  const [activeTab, setActiveTab] = useState<string>('staircase');
  const [indent, setIndent] = useState<string>('  '); // Default 2 spaces
  const [prefix, setPrefix] = useState<string>('→ ');
  const [previewText, setPreviewText] = useState<string>('');
  const [selectedPattern, setSelectedPattern] = useState<string>('');
  
  // Common prefixes for easy selection
  const commonPrefixes = [
    { value: '→ ', label: '→ Arrow' },
    { value: '• ', label: '• Bullet' },
    { value: '- ', label: '- Dash' },
    { value: '✓ ', label: '✓ Checkmark' },
    { value: '🔹 ', label: '🔹 Blue Diamond' },
    { value: '💡 ', label: '💡 Lightbulb' }
  ];

  // Generate a preview of the pattern but don't apply it 
  const generatePreview = (patternType: string) => {
    // Use a sample of 3 lines for preview
    const sampleLines = text.split('\n').filter(line => line.trim()).slice(0, 3);
    if (sampleLines.length === 0) {
      // If no text, use dummy text for preview
      sampleLines.push('First line example', 'Second line example', 'Third line example');
    }
    
    setSelectedPattern(patternType);
    
    switch (patternType) {
      case 'staircase':
        const staircasePreview = sampleLines.map((line, index) => {
          return indent.repeat(index) + prefix + line;
        }).join('\n');
        setPreviewText(staircasePreview);
        break;
        
      case 'inverted':
        const invertedPreview = sampleLines.map((line, index) => {
          return indent.repeat(sampleLines.length - index - 1) + prefix + line;
        }).join('\n');
        setPreviewText(invertedPreview);
        break;
        
      case 'pyramid':
        const longestLine = Math.max(...sampleLines.map(line => line.length));
        const pyramidPreview = sampleLines.map((line, index) => {
          const spacesNeeded = Math.floor((longestLine - line.length) / 2);
          return ' '.repeat(spacesNeeded) + prefix + line;
        }).join('\n');
        setPreviewText(pyramidPreview);
        break;
        
      case 'zigzag':
        const zigzagPreview = sampleLines.map((line, index) => {
          const indentAmount = (index % 2 === 0) ? 0 : 2;
          return indent.repeat(indentAmount) + prefix + line;
        }).join('\n');
        setPreviewText(zigzagPreview);
        break;
        
      case 'wave':
        const wavePreview = sampleLines.map((line, index) => {
          const cycle = index % 6;
          const indentAmount = cycle <= 3 ? cycle : 6 - cycle;
          return indent.repeat(indentAmount) + prefix + line;
        }).join('\n');
        setPreviewText(wavePreview);
        break;
    }
  };
  
  // Create a staircase effect where each new line gets increasingly indented
  const createStaircase = () => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    const staircaseText = lines.map((line, index) => {
      return indent.repeat(index) + prefix + line;
    }).join('\n');
    onTextChange(staircaseText);
  };

  // Create an inverted staircase (starts with most indentation, reduces with each line)
  const createInvertedStaircase = () => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    const staircaseText = lines.map((line, index) => {
      return indent.repeat(lines.length - index - 1) + prefix + line;
    }).join('\n');
    onTextChange(staircaseText);
  };

  // Create a centered pyramid structure with text
  const createPyramid = () => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    const longestLine = Math.max(...lines.map(line => line.length));
    
    const pyramidText = lines.map((line, index) => {
      const spacesNeeded = Math.floor((longestLine - line.length) / 2);
      return ' '.repeat(spacesNeeded) + prefix + line;
    }).join('\n');
    
    onTextChange(pyramidText);
  };

  // Create a zigzag pattern with indentation
  const createZigzag = () => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    const zigzagText = lines.map((line, index) => {
      // Alternate between 0, 2, 0, 2, ... indentation levels
      const indentAmount = (index % 2 === 0) ? 0 : 2;
      return indent.repeat(indentAmount) + prefix + line;
    }).join('\n');
    
    onTextChange(zigzagText);
  };

  // Create a wave pattern
  const createWave = () => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    const waveText = lines.map((line, index) => {
      // Wave pattern: 0, 1, 2, 3, 2, 1, 0, 1, 2, 3, ...
      const cycle = index % 6;
      const indentAmount = cycle <= 3 ? cycle : 6 - cycle;
      return indent.repeat(indentAmount) + prefix + line;
    }).join('\n');
    
    onTextChange(waveText);
  };
  
  // Apply the currently previewed pattern
  const applySelectedPattern = () => {
    if (!selectedPattern) return;
    
    switch (selectedPattern) {
      case 'staircase': createStaircase(); break;
      case 'inverted': createInvertedStaircase(); break;
      case 'pyramid': createPyramid(); break;
      case 'zigzag': createZigzag(); break;
      case 'wave': createWave(); break;
    }
  };
  
  // Reset preview when switching tabs
  useEffect(() => {
    setPreviewText('');
    setSelectedPattern('');
  }, [activeTab]);

  return (
    <Card className="mb-4 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="p-3 pb-0 border-b bg-[#134e4a] bg-opacity-10">
        <CardTitle className="text-sm font-medium text-[#134e4a] flex items-center">
          <span className="bg-[#0d9488] h-4 w-4 rounded-full mr-2"></span>
          Text Staircase Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <Tabs defaultValue="staircase" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-3 bg-[#134e4a] bg-opacity-5">
            <TabsTrigger value="staircase" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-stairs mr-2"></i>
              Patterns
            </TabsTrigger>
            <TabsTrigger value="preview" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-eye mr-2"></i>
              Preview
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-white data-[state=active]:text-[#0d9488]">
              <i className="fas fa-cog mr-2"></i>
              Settings
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="staircase" className="space-y-2">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 w-full text-[#134e4a] border-gray-200 shadow-sm hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => generatePreview('staircase')}
              >
                <i className="fas fa-arrow-down mr-2"></i>
                <span>Staircase Down</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 w-full text-[#134e4a] border-gray-200 shadow-sm hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => generatePreview('inverted')}
              >
                <i className="fas fa-arrow-up mr-2"></i>
                <span>Staircase Up</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 w-full text-[#134e4a] border-gray-200 shadow-sm hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => generatePreview('pyramid')}
              >
                <i className="fas fa-sort mr-2"></i>
                <span>Centered</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 w-full text-[#134e4a] border-gray-200 shadow-sm hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => generatePreview('zigzag')}
              >
                <i className="fas fa-bolt mr-2"></i>
                <span>Zigzag</span>
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 w-full text-[#134e4a] border-gray-200 shadow-sm hover:bg-[#134e4a] hover:bg-opacity-10"
                onClick={() => generatePreview('wave')}
              >
                <i className="fas fa-water mr-2"></i>
                <span>Wave</span>
              </Button>
            </div>
            
            <div className="text-xs text-[#134e4a] flex items-center bg-[#134e4a] bg-opacity-5 p-2 rounded-md mt-3">
              <i className="fas fa-info-circle text-[#0d9488] mr-2 text-base"></i>
              First split your text into multiple lines, then click a pattern to see a preview and apply.
            </div>
          </TabsContent>
          
          <TabsContent value="preview" className="space-y-3">
            {previewText ? (
              <>
                <div className="bg-gray-50 p-3 rounded-md font-mono text-sm whitespace-pre-wrap border border-gray-200">
                  {previewText}
                </div>
                <Button 
                  variant="default" 
                  size="sm"
                  className="w-full bg-[#0d9488] hover:bg-[#134e4a]"
                  onClick={applySelectedPattern}
                >
                  <i className="fas fa-check mr-2"></i>
                  Apply This Pattern
                </Button>
              </>
            ) : (
              <div className="text-center py-6 text-gray-400 flex flex-col items-center">
                <i className="fas fa-eye-slash text-2xl mb-2"></i>
                <p>Select a pattern from the Patterns tab to see a preview</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="settings" className="space-y-4">
            <div>
              <Label htmlFor="indentation" className="text-[#134e4a]">Indentation Characters</Label>
              <Input 
                id="indentation" 
                value={indent} 
                onChange={(e) => setIndent(e.target.value)}
                className="mt-1 border-gray-200"
                placeholder="Spaces or characters for indentation"
              />
              <p className="text-xs text-[#134e4a] mt-1">
                Use spaces or special characters for indentation (default: two spaces)
              </p>
            </div>
            
            <div>
              <Label htmlFor="prefix" className="text-[#134e4a]">Line Prefix</Label>
              <div className="flex gap-2 mt-1">
                <Input 
                  id="prefix" 
                  value={prefix} 
                  onChange={(e) => setPrefix(e.target.value)}
                  className="border-gray-200 flex-grow"
                  placeholder="Optional prefix for each line"
                />
                <Select 
                  value={prefix} 
                  onValueChange={setPrefix}
                >
                  <SelectTrigger className="w-[180px] border-gray-200">
                    <SelectValue placeholder="Choose prefix" />
                  </SelectTrigger>
                  <SelectContent>
                    {commonPrefixes.map(item => (
                      <SelectItem key={item.value} value={item.value}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <p className="text-xs text-[#134e4a] mt-1">
                Add a special character or emoji before each line
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TextStaircaseGenerator;