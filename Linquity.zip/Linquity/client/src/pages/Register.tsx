import React, { useState } from 'react';
import { RegisterForm } from '@/components/auth/RegisterForm';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface RegisterValues {
  email: string;
  password: string;
  firstName: string;
  lastName?: string;
}

const RegisterPage: React.FC = () => {
  const { register } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleRegister = async (values: RegisterValues) => {
    setIsLoading(true);
    try {
      await register(values);
    } catch (error) {
      toast({
        title: 'Registration failed',
        description: error instanceof Error ? error.message : 'Please try again with a different email',
        variant: 'destructive',
      });
      throw error; // Re-throw so RegisterForm can handle it
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto max-w-6xl py-12 px-4">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Create an Account</h1>
        <p className="text-muted-foreground mt-2">
          Sign up to start creating professional LinkedIn content
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div>
          <RegisterForm onRegister={handleRegister} loading={isLoading} />
        </div>

        <div className="hidden md:block">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-xl">
            <h2 className="text-2xl font-bold mb-4">Benefits of Joining</h2>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>AI-powered content creation and optimization</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Save and manage multiple LinkedIn post drafts</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Access to premium templates and formatting tools</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Advanced LinkedIn SEO and content optimization</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Schedule posts for optimal engagement times</p>
              </li>
            </ul>
            
            <div className="mt-6 bg-white/50 p-4 rounded-lg border border-blue-100">
              <p className="text-sm text-slate-700">
                <strong>Note:</strong> After registering, you'll need to verify your email to access all premium features. This helps us ensure a quality experience for all users.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;