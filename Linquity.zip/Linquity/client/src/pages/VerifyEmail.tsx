import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { EmailVerificationCard } from '@/components/auth/EmailVerificationCard';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const VerifyEmailPage: React.FC = () => {
  const { user, checkEmailVerification, sendVerificationEmail, isAuthenticated, isLoading } = useAuth();
  const [isVerifying, setIsVerifying] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // If user isn't authenticated, redirect to login
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation('/login');
    }
  }, [isLoading, isAuthenticated, setLocation]);

  // Check verification status on mount
  useEffect(() => {
    const verifyEmail = async () => {
      setIsVerifying(true);
      try {
        await checkEmailVerification();
      } catch (error) {
        console.error('Error checking verification status:', error);
      } finally {
        setIsVerifying(false);
      }
    };

    if (isAuthenticated) {
      verifyEmail();
    }
  }, [isAuthenticated, checkEmailVerification]);

  // Handle sending verification email
  const handleSendVerification = async () => {
    try {
      const success = await sendVerificationEmail();
      if (success) {
        toast({
          title: "Verification email sent",
          description: "Please check your inbox and click the verification link",
        });
      } else {
        toast({
          title: "Failed to send email",
          description: "Please try again later",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send verification email",
        variant: "destructive",
      });
    }
  };

  // Handle checking verification status
  const handleCheckVerification = async () => {
    try {
      const isVerified = await checkEmailVerification();
      if (isVerified) {
        toast({
          title: "Email verified!",
          description: "Your email has been successfully verified.",
        });
      } else {
        toast({
          title: "Not verified yet",
          description: "Please check your inbox and click the verification link.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check verification status",
        variant: "destructive",
      });
    }
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto py-12 px-4">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          className="flex items-center gap-2"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
      </div>
      
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Email Verification</h1>
        <p className="text-muted-foreground mt-2">
          Verify your email to access all premium features
        </p>
      </div>
      
      <EmailVerificationCard
        email={user.email}
        isVerified={user.isVerified}
        onSendVerification={handleSendVerification}
        onCheckVerification={handleCheckVerification}
      />
      
      <div className="mt-8 bg-blue-50 rounded-lg p-6 border border-blue-100">
        <h2 className="text-xl font-semibold mb-2">Why verify your email?</h2>
        <p className="mb-4">
          Email verification helps us ensure you have access to all the premium features of the LinkedIn post editor:
        </p>
        <ul className="list-disc pl-5 space-y-2">
          <li>Save unlimited drafts of your LinkedIn posts</li>
          <li>Advanced AI-powered content optimization</li>
          <li>Schedule posts directly to LinkedIn</li>
          <li>Access premium templates and content ideas</li>
          <li>Receive performance insights on your published content</li>
        </ul>
      </div>
    </div>
  );
};

export default VerifyEmailPage;