import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { Draft } from '../../shared/schema';
import { apiRequest } from '@/lib/queryClient';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Drafts() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [draftToDelete, setDraftToDelete] = useState<number | null>(null);

  // Fetch all drafts
  const { data: drafts, isLoading, error } = useQuery({
    queryKey: ['/api/drafts'],
    retry: 1,
  });

  // Delete draft mutation
  const deleteDraftMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/drafts/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      // Invalidate the drafts query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/drafts'] });
      toast({
        title: "Draft deleted",
        description: "The draft has been successfully deleted",
      });
      setDraftToDelete(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the draft",
        variant: "destructive",
      });
    }
  });

  const handleDeleteDraft = (id: number) => {
    setDraftToDelete(id);
  };

  const confirmDeleteDraft = () => {
    if (draftToDelete) {
      deleteDraftMutation.mutate(draftToDelete);
    }
  };

  const handleEditDraft = (id: number) => {
    setLocation(`/edit/${id}`);
  };

  const handleGoBack = () => {
    setLocation('/');
  };

  // Helper function to truncate text for preview
  const truncateText = (text: string, maxLength: number = 150) => {
    return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <i className="fas fa-feather-alt text-[#0a66c2] text-xl"></i>
            <h1 className="text-xl font-semibold text-[#0a66c2]">Linquity</h1>
          </div>
          <Button 
            variant="outline" 
            className="border-[#134e4a] text-[#134e4a]"
            onClick={handleGoBack}
          >
            <i className="fas fa-arrow-left mr-2"></i> Back to Editor
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">My Drafts</h2>
          <Button 
            onClick={handleGoBack}
            className="bg-[#0a66c2] hover:bg-[#084e96] text-white"
          >
            <i className="fas fa-plus mr-2"></i> Create New Post
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-10">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0a66c2]"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 p-6 rounded-lg">
            <h3 className="text-lg font-medium text-red-800">Something went wrong</h3>
            <p className="mt-2 text-red-700">Unable to load your drafts. Please try again later.</p>
            <Button 
              variant="outline" 
              className="mt-4 border-red-500 text-red-500"
              onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/drafts'] })}
            >
              Try Again
            </Button>
          </div>
        ) : drafts?.length === 0 ? (
          <div className="bg-gray-50 p-10 rounded-lg text-center">
            <div className="text-gray-400 mb-4">
              <i className="far fa-folder-open text-5xl"></i>
            </div>
            <h3 className="text-xl font-medium text-gray-800 mb-2">No drafts yet</h3>
            <p className="text-gray-600 mb-6">Create and save your first LinkedIn post draft</p>
            <Button 
              onClick={handleGoBack}
              className="bg-[#0a66c2] hover:bg-[#084e96] text-white"
            >
              Create a Draft
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {drafts.map((draft: Draft) => (
              <Card key={draft.id} className="overflow-hidden hover:shadow-md transition-shadow duration-200">
                <CardHeader className="bg-gray-50 border-b p-4">
                  <CardTitle className="text-lg">{draft.goal} Post</CardTitle>
                  <CardDescription>
                    Tone: {draft.tone} · Created {formatDistanceToNow(new Date(draft.createdAt), { addSuffix: true })}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 h-40 overflow-hidden">
                  <p className="text-sm text-gray-600 line-clamp-5">
                    {truncateText(draft.rawText)}
                  </p>
                </CardContent>
                <CardFooter className="border-t bg-white p-4 flex justify-between">
                  <Button 
                    variant="outline" 
                    className="border-[#134e4a] text-[#134e4a]"
                    onClick={() => handleEditDraft(draft.id)}
                  >
                    <i className="far fa-edit mr-2"></i> Edit
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="border-red-500 text-red-500 hover:bg-red-50"
                        onClick={() => handleDeleteDraft(draft.id)}
                      >
                        <i className="far fa-trash-alt mr-2"></i> Delete
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete this draft. This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={confirmDeleteDraft}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}