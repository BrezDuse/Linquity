import React from 'react';
import ChromePluginFeatures from '@/components/ChromePluginFeatures';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';

export default function ChromePlugin() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="bg-[#f3f2ef] min-h-screen font-sans text-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Chrome Extension</h1>
          <Button
            variant="outline"
            onClick={() => setLocation('/')}
            className="border-[#134e4a] text-[#134e4a] hover:bg-[#134e4a] hover:text-white"
          >
            Back to Editor
          </Button>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 mb-8">
          <div className="flex flex-col md:flex-row gap-8 items-center mb-8">
            <div className="md:w-2/3">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Coming Soon: Linquity Chrome Extension</h2>
              <p className="text-gray-700 mb-6">
                Take the power of Linquity wherever you go on LinkedIn with our upcoming Chrome extension. 
                Streamline your workflow with direct LinkedIn integration, advanced content analysis, 
                and personalized insights - all accessible right from your browser.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Join the Waitlist
                </Button>
                <Button 
                  variant="outline"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50"
                >
                  Share Feedback
                </Button>
              </div>
            </div>
            <div className="md:w-1/3 flex justify-center">
              <div className="w-32 h-32 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                  <rect x="2" y="9" width="4" height="12"></rect>
                  <circle cx="4" cy="4" r="2"></circle>
                </svg>
              </div>
            </div>
          </div>
          
          <ChromePluginFeatures />
          
          <div className="mt-12 pt-8 border-t border-gray-200">
            <h3 className="text-xl font-semibold mb-4">Why use the Linquity Chrome Extension?</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                  </svg>
                </div>
                <h4 className="font-medium mb-2">Save Time</h4>
                <p className="text-sm text-gray-600">Create and optimize LinkedIn content without switching between tabs or applications.</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <line x1="18" y1="20" x2="18" y2="10"></line>
                    <line x1="12" y1="20" x2="12" y2="4"></line>
                    <line x1="6" y1="20" x2="6" y2="14"></line>
                  </svg>
                </div>
                <h4 className="font-medium mb-2">Increase Engagement</h4>
                <p className="text-sm text-gray-600">Get real-time insights and suggestions that help you create more engaging content.</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600">
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                    <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                    <line x1="12" y1="22.08" x2="12" y2="12"></line>
                  </svg>
                </div>
                <h4 className="font-medium mb-2">Streamlined Workflow</h4>
                <p className="text-sm text-gray-600">Post directly to LinkedIn, schedule content, and track performance all in one place.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-100 py-8 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm text-gray-500">
            © 2025 Linquity. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}