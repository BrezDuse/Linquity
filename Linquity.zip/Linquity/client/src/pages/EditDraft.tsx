import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import EditorPanel from '@/components/EditorPanel';
import PreviewPanel from '@/components/PreviewPanel';
import { PostContent, ReadabilityFeedback, PreviewTips } from '@/types';
import { apiRequest } from '@/lib/queryClient';
import { Draft } from '../../shared/schema';
import { calculateFleschReadingEase, countWords, calculateReadingTime, getReadabilityRating, findComplexSentences } from '@/lib/textAnalysis';
import { analyzeCreativity, CreativityScore } from '@/lib/creativityScoring';
import CreativityScorePanel from '@/components/CreativityScorePanel';
import AdvancedContentOptimization from '@/components/AdvancedContentOptimization';

export default function EditDraft() {
  const params = useParams();
  const id = parseInt(params.id, 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [content, setContent] = useState<PostContent>({
    rawText: '',
    formattedText: '',
    goal: 'educate',
    tone: 'professional'
  });

  const [readability, setReadability] = useState<ReadabilityFeedback>({
    score: 0,
    rating: '',
    wordCount: 0,
    readingTime: 0,
    suggestions: []
  });

  const [previewTips, setPreviewTips] = useState<PreviewTips>({
    hookStrength: 'moderate',
    hookMessage: 'Your opening is somewhat engaging, consider making it more compelling.',
    formattingTips: ['Consider adding more white space', 'Try using bullet points for key information']
  });
  
  // State for creativity score
  const [creativityScore, setCreativityScore] = useState<CreativityScore>(analyzeCreativity(''));

  // Fetch the draft by ID
  const { data: draft, isLoading, error } = useQuery({
    queryKey: [`/api/drafts/${id}`],
    retry: 1,
  });

  // Update draft mutation
  const updateDraftMutation = useMutation({
    mutationFn: async (updatedDraft: Partial<Draft>) => {
      await apiRequest(`/api/drafts/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updatedDraft),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/drafts/${id}`] });
      toast({
        title: "Draft updated",
        description: "Your changes have been saved",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update the draft",
        variant: "destructive",
      });
    }
  });

  // Calculate readability stats from text
  const calculateReadabilityStats = (text: string): ReadabilityFeedback => {
    const wordCount = countWords(text);
    const score = calculateFleschReadingEase(text);
    const rating = getReadabilityRating(score);
    const readingTime = calculateReadingTime(wordCount);
    const complexSentences = findComplexSentences(text);
    
    const suggestions = complexSentences.map(sentence => ({
      text: sentence,
      improvement: "Consider breaking this sentence into smaller parts or simplifying it."
    }));
    
    return {
      score,
      rating,
      wordCount,
      readingTime,
      suggestions
    };
  };

  // Effect to set initial state from the draft data
  useEffect(() => {
    if (draft) {
      setContent({
        rawText: draft.rawText,
        formattedText: draft.formattedText,
        goal: draft.goal,
        tone: draft.tone
      });
      
      // Calculate initial readability and creativity stats
      setReadability(calculateReadabilityStats(draft.rawText));
      setCreativityScore(analyzeCreativity(draft.rawText));
    }
  }, [draft]);

  const handleContentChange = (updatedContent: Partial<PostContent>) => {
    setContent(prev => {
      const newContent = { ...prev, ...updatedContent };
      
      // Update readability and creativity scores when raw text changes
      if (updatedContent.rawText) {
        setReadability(calculateReadabilityStats(updatedContent.rawText));
        setCreativityScore(analyzeCreativity(updatedContent.rawText));
      }
      
      return newContent;
    });
  };

  const handleSaveDraft = async () => {
    const updatedDraft = {
      rawText: content.rawText,
      formattedText: content.formattedText,
      goal: content.goal,
      tone: content.tone
    };
    
    await updateDraftMutation.mutateAsync(updatedDraft);
  };

  const handleEnhancePost = async () => {
    try {
      const response = await apiRequest('/api/enhance-post', {
        method: 'POST',
        body: JSON.stringify({
          text: content.rawText,
          goal: content.goal,
          tone: content.tone
        })
      });
      
      // Update content with the enhanced text
      setContent(prev => ({
        ...prev,
        formattedText: response.enhancedText
      }));
      
      // Update readability feedback and preview tips
      setReadability(response.readability);
      setPreviewTips(response.preview);
      
      toast({
        title: "Post Enhanced",
        description: "AI suggestions have been applied to your post",
      });
    } catch (error) {
      toast({
        title: "Enhancement Failed",
        description: "There was an error enhancing your post. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleGoBack = () => {
    setLocation('/drafts');
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0a66c2]"></div>
      </div>
    );
  }

  if (error || !draft) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <div className="text-red-500 text-6xl mb-4">
          <i className="fas fa-exclamation-circle"></i>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Draft Not Found</h2>
        <p className="text-gray-600 mb-6 text-center">
          The draft you're looking for couldn't be found or there was an error loading it.
        </p>
        <Button 
          onClick={() => setLocation('/drafts')}
          className="bg-[#0a66c2] hover:bg-[#084e96] text-white"
        >
          Back to Drafts
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <i className="fas fa-feather-alt text-[#0a66c2] text-xl"></i>
            <h1 className="text-xl font-semibold text-[#0a66c2]">Linquity</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              className="border-[#134e4a] text-[#134e4a]"
              onClick={handleGoBack}
            >
              <i className="fas fa-arrow-left mr-2"></i> Back to Drafts
            </Button>
            <Button 
              variant="default" 
              className="bg-[#0a66c2] hover:bg-[#084e96] text-white" 
              onClick={handleSaveDraft}
              disabled={updateDraftMutation.isPending}
            >
              {updateDraftMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Saving...
                </>
              ) : (
                <>
                  <i className="far fa-save mr-2"></i> Save Changes
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Edit Draft</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <EditorPanel 
              content={content} 
              readability={readability}
              onContentChange={handleContentChange}
              onEnhancePost={handleEnhancePost}
            />
            
            {/* Creativity Score Panel */}
            <CreativityScorePanel score={creativityScore} />
            
            {/* Advanced Content Optimization */}
            <AdvancedContentOptimization 
              text={content.rawText} 
              industry="general" 
              goal={content.goal} 
            />
          </div>
          
          <PreviewPanel 
            formattedText={content.formattedText || content.rawText} 
            activePreview="desktop"
            previewTips={previewTips}
            onPreviewChange={() => {}}
          />
        </div>
      </main>
    </div>
  );
}