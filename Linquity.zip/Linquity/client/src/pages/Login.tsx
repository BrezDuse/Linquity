import React, { useState } from 'react';
import { LoginForm } from '@/components/auth/LoginForm';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      await login(email, password);
    } catch (error) {
      toast({
        title: 'Login failed',
        description: error instanceof Error ? error.message : 'Please check your credentials and try again',
        variant: 'destructive',
      });
      throw error; // Re-throw so LoginForm can handle it
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto max-w-6xl py-12 px-4">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Welcome Back</h1>
        <p className="text-muted-foreground mt-2">
          Sign in to access your LinkedIn post editor account
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="hidden md:block">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-xl">
            <h2 className="text-2xl font-bold mb-4">Enhance Your LinkedIn Presence</h2>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Create engaging LinkedIn posts with AI-powered assistance</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Schedule posts for optimal engagement times</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Analyze content effectiveness with readability metrics</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <p>Access professional templates and content optimization tools</p>
              </li>
            </ul>
          </div>
        </div>

        <div>
          <LoginForm onLogin={handleLogin} loading={isLoading} />
        </div>
      </div>
    </div>
  );
};

export default LoginPage;