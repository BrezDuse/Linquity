import Header from "@/components/Header";
import EditorPanel from "@/components/EditorPanel";
import PreviewPanel from "@/components/PreviewPanel";
import FeatureSection from "@/components/FeatureSection";
import Footer from "@/components/Footer";
import SuggestionBox from "@/components/SuggestionBox";
import TechnicalImprovements from "@/components/TechnicalImprovements";
import { useState } from "react";
import AboutMeEditor from "@/components/AboutMeEditor";
import LinkedInProfileConnect, { LinkedInProfile } from "@/components/LinkedInProfileConnect";
import { Button } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle 
} from "@/components/ui/dialog";
import { PostContent, ReadabilityFeedback, PreviewTips } from "@/types";

export default function Home() {
  const [content, setContent] = useState<PostContent>({
    rawText: "Here's what I learned building a startup. It's hard. You have to keep pushing. There's no easy path. I failed 3 times before I got it right.",
    formattedText: "Here's what I learned building a startup 👇\n\n🔹 It's hard.\n🔹 You have to keep pushing.\n🔹 There's no easy path.\n\nI failed 3 times before I got it right — and that's okay.\n\n👉 What's one lesson you learned the hard way?",
    goal: "",
    tone: "",
  });
  
  const [readability, setReadability] = useState<ReadabilityFeedback>({
    score: 72,
    rating: "Good",
    wordCount: 42,
    readingTime: 15,
    suggestions: [
      { text: "You have to keep pushing", improvement: "You must persist through rejection and failure." }
    ]
  });
  
  const [previewTips, setPreviewTips] = useState<PreviewTips>({
    hookStrength: "Good",
    hookMessage: "The hook is strong — it will show well in mobile preview.",
    formattingTips: [
      "Add an extra line break after the first sentence for visual clarity.",
      "The emoji bullet points create good visual structure.",
      "The CTA at the end will boost engagement."
    ]
  });
  
  const [activePreview, setActivePreview] = useState<"mobile" | "desktop">("mobile");
  const [showAboutMeEditor, setShowAboutMeEditor] = useState<boolean>(false);
  const [showLinkedInConnect, setShowLinkedInConnect] = useState<boolean>(false);
  const [linkedInProfile, setLinkedInProfile] = useState<LinkedInProfile | null>(null);
  
  const handleLinkedInProfileConnect = (profile: LinkedInProfile) => {
    setLinkedInProfile(profile);
    setShowLinkedInConnect(false);
  };
  
  const handleContentChange = (newContent: Partial<PostContent>) => {
    setContent(prev => ({ ...prev, ...newContent }));
  };
  
  const handleEnhancePost = async () => {
    try {
      const response = await fetch('/api/enhance-post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: content.rawText,
          goal: content.goal,
          tone: content.tone
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to enhance post');
      }
      
      const data = await response.json();
      
      setContent(prev => ({
        ...prev,
        formattedText: data.enhancedText
      }));
      
      setReadability({
        score: data.readability.score,
        rating: data.readability.rating,
        wordCount: data.readability.wordCount,
        readingTime: data.readability.readingTime,
        suggestions: data.readability.suggestions
      });
      
      setPreviewTips({
        hookStrength: data.preview.hookStrength,
        hookMessage: data.preview.hookMessage,
        formattingTips: data.preview.formattingTips
      });
    } catch (error) {
      console.error('Error enhancing post:', error);
    }
  };
  
  const saveDraft = async () => {
    try {
      await fetch('/api/drafts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rawText: content.rawText,
          formattedText: content.formattedText,
          goal: content.goal,
          tone: content.tone
        }),
      });
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };
  
  return (
    <div className="bg-[#f3f2ef] min-h-screen font-sans text-gray-900">
      <Header onSaveDraft={saveDraft} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {linkedInProfile ? (
              <div className="flex items-center gap-2 bg-white p-2 rounded-lg shadow-sm border border-[#134e4a]">
                <img 
                  src={linkedInProfile.profilePicture} 
                  alt={linkedInProfile.name} 
                  className="w-10 h-10 rounded-full border-2 border-[#134e4a]"
                />
                <div>
                  <p className="text-sm font-semibold">{linkedInProfile.name}</p>
                  <p className="text-xs text-gray-500 truncate max-w-[200px]">{linkedInProfile.headline}</p>
                </div>
              </div>
            ) : (
              <Button 
                variant="default" 
                className="bg-[#134e4a] hover:bg-[#0d9488] text-white font-medium"
                onClick={() => setShowLinkedInConnect(true)}
              >
                <i className="fab fa-linkedin mr-2"></i>
                Connect Profile
              </Button>
            )}
          </div>
          
          <Button 
            variant="default" 
            className="bg-[#134e4a] hover:bg-[#0d9488] text-white font-medium"
            onClick={() => setShowAboutMeEditor(true)}
          >
            <i className="fas fa-user-edit mr-2"></i>
            About Me Editor
          </Button>
        </div>
        
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 space-y-6 lg:space-y-0">
          <div>
            <EditorPanel 
              content={content}
              readability={readability}
              onContentChange={handleContentChange}
              onEnhancePost={handleEnhancePost}
            />
          </div>
          
          <PreviewPanel 
            formattedText={content.formattedText}
            activePreview={activePreview}
            previewTips={previewTips}
            onPreviewChange={setActivePreview}
            linkedInProfile={linkedInProfile}
          />
        </div>
        
        <FeatureSection />
        <div className="mt-6">
          <SuggestionBox />
        </div>
        <TechnicalImprovements />
      </main>
      
      {showAboutMeEditor && (
        <AboutMeEditor onClose={() => setShowAboutMeEditor(false)} />
      )}
      
      <Dialog open={showLinkedInConnect} onOpenChange={setShowLinkedInConnect}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Connect LinkedIn Profile</DialogTitle>
            <DialogDescription>
              Link your LinkedIn profile to display your photo and publish posts directly.
            </DialogDescription>
          </DialogHeader>
          
          <LinkedInProfileConnect onProfileConnect={handleLinkedInProfileConnect} />
        </DialogContent>
      </Dialog>
      
      <Footer />
    </div>
  );
}
