import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Drafts from "@/pages/Drafts";
import EditDraft from "@/pages/EditDraft";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import VerifyEmail from "@/pages/VerifyEmail";
import ChromePlugin from "@/pages/ChromePlugin";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import PromptDownloader from "@/components/PromptDownloader";
import MobileResponsiveHelp from "@/components/MobileResponsiveHelp";
import LinkedInEducationCenter from "@/components/LinkedInEducationCenter";
import SuggestionBox from "@/components/SuggestionBox";
import { useAuth } from "@/contexts/AuthContext";

// Protected route wrapper component
function ProtectedRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, path: string }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-pulse text-lg">Loading...</div>
    </div>;
  }
  
  return isAuthenticated ? <Component {...rest} /> : <Login />;
}

// Email verification warning component
function EmailVerificationWarning() {
  const { user, isAuthenticated } = useAuth();
  
  if (!isAuthenticated || (user && user.isVerified)) {
    return null;
  }
  
  return (
    <div className="bg-amber-50 p-2 text-center text-sm border-b border-amber-200">
      <span className="text-amber-800">
        Please <a href="/verify-email" className="font-bold underline">verify your email</a> to access all premium features.
      </span>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/chrome-plugin" component={ChromePlugin} />
      <Route path="/drafts">
        {(params) => <ProtectedRoute component={Drafts} path="/drafts" />}
      </Route>
      <Route path="/edit/:id">
        {(params) => <ProtectedRoute component={EditDraft} path={`/edit/${params.id}`} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <div className="flex flex-col min-h-screen">
            <EmailVerificationWarning />
            <NavBar />
            <main className="flex-1">
              <Router />
            </main>
            <PromptDownloader />
            <MobileResponsiveHelp />
            <LinkedInEducationCenter />
          </div>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
